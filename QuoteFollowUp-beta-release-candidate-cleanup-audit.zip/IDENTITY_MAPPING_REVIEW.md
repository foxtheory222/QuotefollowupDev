# Identity Mapping Review

No beta persona mappings were created because no verified test systemuser rows exist.

Current readiness from regression:

- Active staff: 19
- Active staff with email: 1
- Active staff linked to systemuser: 1
- Active staff missing email: 18
- Active staff missing systemuser: 18
- Manager memberships: 0
- GM memberships: 0
- Admin memberships: 1

No guessed mappings were made.
