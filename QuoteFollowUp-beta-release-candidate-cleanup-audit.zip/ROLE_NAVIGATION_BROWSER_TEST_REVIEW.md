# Role Navigation Browser Test Review

Available browser validation:

- Persona: current authenticated dev/maker only
- Browser blocked: True
- Browser blocker: Microsoft sign-in blocked Workbench validation.
- Portal nav labels: Dashboard, Workbench, Quotes, Back Orders, Ready to Ship, Freight Recovery, Analytics
- Required branch nav present: True
- Removed labels absent: True

Blocked:

- Staff persona navigation.
- Manager persona navigation.
- Admin persona navigation.
- Unauthorized/no-access direct-link behavior.

Reason: separate test accounts were not found or created.
