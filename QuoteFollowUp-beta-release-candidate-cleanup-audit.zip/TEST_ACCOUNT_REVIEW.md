# Test Account Review

- Dataverse test systemusers found: 0
- Dataverse test staff rows found: 0
- Dataverse test memberships found: 0
- Entra/Graph discovery succeeded: True
- Entra QFU test users found: 0
- Accounts created: 0
- Credentials included: none

Required account setup is documented in ACCOUNT_SETUP_REQUIRED.md.
