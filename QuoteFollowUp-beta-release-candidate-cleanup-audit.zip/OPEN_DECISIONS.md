# Open Decisions

- Who will create/license QFU Test Staff, Manager, Admin, No Access, and optional GM accounts.
- Verified test mailbox for TestRecipientOnly.
- Whether to implement send-capable TestRecipientOnly flows now or after beta persona setup.
- Final approval of QFU least-privilege role matrix.
- Final branch access enforcement pattern for beta.
