# Test Run Summary

- Total test groups: 9
- Passed: 4
- Failed: 0
- Blocked: 5
- Skipped: TestRecipientOnly send
- Fix/test cycles: 1
- Final result: Not beta-ready

Passed:

- Dataverse beta readiness discovery.
- Entra/Graph sanitized discovery.
- Phase 6 dry-run/no-send regression.
- Duplicate-key and source-safety regression.

Blocked:

- Staff persona browser test.
- Manager persona browser test.
- Admin persona browser test.
- Unauthorized/no-access browser test.
- TestRecipientOnly send validation.
