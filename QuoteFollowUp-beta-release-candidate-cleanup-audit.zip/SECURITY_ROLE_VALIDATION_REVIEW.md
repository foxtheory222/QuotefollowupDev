# Security Role Validation Review

QFU roles found: 5
QFU branch teams found: 3
Role privilege rows present: True
Privileges enough for beta: False

Role privilege counts:

- QFU Staff: 9
- QFU Manager: 9
- QFU GM: 9
- QFU Admin: 9
- QFU Service Account: 9


Limitations:

- Privilege counts are not sufficient proof of least-privilege behavior.
- Staff, Manager, Admin, and No Access persona tests are blocked.
- Branch access enforcement could not be validated without separate users.
- No maker/admin lockout was observed.
