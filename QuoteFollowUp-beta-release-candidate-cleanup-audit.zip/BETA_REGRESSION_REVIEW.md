# Beta Regression Review

- Workbench/app found: True
- Key tables accessible: True
- Active work items: 38
- Queue handoff flows no-send: yes, by flow review
- Server-side rollup flow present: yes, by flow review
- Alert dry-run still works: yes
- Sent alert logs: 0
- Failed alert logs: 0
- Duplicate work item source keys: 0
- Duplicate assignment exception keys: 0
- Duplicate alert dedupe keys: 0
- Duplicate active alias keys: 0
- Source tables replaced: No evidence of replacement in this pass
