param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com",
  [string]$SolutionUniqueName = "Default",
  [string]$FiscalYear = "FY26",
  [string]$OutputJson = "results\gl060-history-actuals-seed.json"
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Add-Type -AssemblyName "Microsoft.Xrm.Sdk"
Add-Type -AssemblyName "Microsoft.Crm.Sdk.Proxy"

function New-Label {
  param([string]$Text)
  return [Microsoft.Xrm.Sdk.Label]::new($Text, 1033)
}

function New-RequiredLevel {
  param([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]$Level)
  return [Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevelManagedProperty]::new($Level)
}

function Connect-Org {
  param([string]$Url)

  $conn = Connect-CrmOnline -ServerUrl $Url -ForceOAuth -Username $Username
  if (-not $conn -or -not $conn.IsReady) {
    throw "Dataverse connection failed for $Url : $($conn.LastCrmError)"
  }

  return $conn
}

function Test-AttributeExists {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$AttributeLogicalName
  )

  try {
    $request = [Microsoft.Xrm.Sdk.Messages.RetrieveAttributeRequest]::new()
    $request.EntityLogicalName = $EntityLogicalName
    $request.LogicalName = $AttributeLogicalName
    $request.RetrieveAsIfPublished = $true
    $null = $Connection.Execute($request)
    return $true
  } catch {
    return $false
  }
}

function Publish-Entities {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string[]]$LogicalNames
  )

  $xml = "<importexportxml><entities>" + (($LogicalNames | ForEach-Object { "<entity>$_</entity>" }) -join "") + "</entities><nodes/><securityroles/><settings/><workflows/></importexportxml>"
  $request = [Microsoft.Crm.Sdk.Messages.PublishXmlRequest]::new()
  $request.ParameterXml = $xml
  $null = $Connection.Execute($request)
}

function Ensure-DecimalAttribute {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SchemaName,
    [string]$DisplayName,
    [int]$Precision = 2,
    [decimal]$MinValue = 0,
    [decimal]$MaxValue = 1000000000
  )

  if (Test-AttributeExists -Connection $Connection -EntityLogicalName $EntityLogicalName -AttributeLogicalName $SchemaName) {
    return $false
  }

  $attribute = [Microsoft.Xrm.Sdk.Metadata.DecimalAttributeMetadata]::new()
  $attribute.SchemaName = $SchemaName
  $attribute.DisplayName = New-Label $DisplayName
  $attribute.RequiredLevel = New-RequiredLevel ([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]::None)
  $attribute.Precision = $Precision
  $attribute.MinValue = $MinValue
  $attribute.MaxValue = $MaxValue

  $request = [Microsoft.Xrm.Sdk.Messages.CreateAttributeRequest]::new()
  $request.EntityName = $EntityLogicalName
  $request.Attribute = $attribute
  if ($SolutionUniqueName) {
    $request.SolutionUniqueName = $SolutionUniqueName
  }

  $null = $Connection.Execute($request)
  Publish-Entities -Connection $Connection -LogicalNames @($EntityLogicalName)
  return $true
}

function Get-BudgetArchiveRows {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$TargetFiscalYear
  )

  $fetch = @"
<fetch>
  <entity name='qfu_budgetarchive'>
    <attribute name='qfu_budgetarchiveid' />
    <attribute name='qfu_branchcode' />
    <attribute name='qfu_branchslug' />
    <attribute name='qfu_month' />
    <attribute name='qfu_monthname' />
    <attribute name='qfu_fiscalyear' />
    <attribute name='qfu_budgetgoal' />
    <attribute name='qfu_actualsales' />
    <attribute name='qfu_lastupdated' />
    <filter type='and'>
      <condition attribute='qfu_fiscalyear' operator='eq' value='$TargetFiscalYear' />
      <condition attribute='qfu_branchcode' operator='in'>
        <value>4171</value>
        <value>4172</value>
        <value>4173</value>
      </condition>
    </filter>
  </entity>
</fetch>
"@

  return @((Get-CrmRecordsByFetch -conn $Connection -Fetch $fetch).CrmRecords)
}

function Ensure-Directory {
  param([string]$Path)

  if (-not $Path) {
    return
  }

  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

$actualMatrix = @{
  "4171" = @{
    7 = 740914.32
    8 = 856595.26
    9 = 582100.41
    10 = 886779.05
    11 = 751990.34
    12 = 943711.28
    1 = 1515922.21
    2 = 690337.05
  }
  "4172" = @{
    7 = 304938.91
    8 = 363449.28
    9 = 468927.12
    10 = 425143.88
    11 = 358049.69
    12 = 381641.94
    1 = 435070.32
    2 = 423379.34
  }
  "4173" = @{
    7 = 273363.67
    8 = 294078.00
    9 = 287086.44
    10 = 299826.32
    11 = 195341.51
    12 = 192765.42
    1 = 281640.89
    2 = 225474.32
  }
}

$connection = Connect-Org -Url $TargetEnvironmentUrl
$createdAttribute = Ensure-DecimalAttribute -Connection $connection -EntityLogicalName "qfu_budgetarchive" -SchemaName "qfu_actualsales" -DisplayName "Actual Sales" -Precision 2 -MinValue 0 -MaxValue 1000000000
$rows = Get-BudgetArchiveRows -Connection $connection -TargetFiscalYear $FiscalYear

$rowIndex = @{}
foreach ($row in $rows) {
  $branchCode = [string]$row.qfu_branchcode
  $monthNumber = [int]$row.qfu_month
  if (-not $branchCode -or -not $monthNumber) {
    continue
  }
  $key = "$branchCode|$monthNumber"
  $existing = $rowIndex[$key]
  if (-not $existing) {
    $rowIndex[$key] = $row
    continue
  }

  $existingUpdated = [datetime]::MinValue
  $candidateUpdated = [datetime]::MinValue
  if ($existing.qfu_lastupdated) {
    $existingUpdated = [datetime]$existing.qfu_lastupdated
  }
  if ($row.qfu_lastupdated) {
    $candidateUpdated = [datetime]$row.qfu_lastupdated
  }
  if ($candidateUpdated -gt $existingUpdated) {
    $rowIndex[$key] = $row
  }
}

$updates = @()
$missing = @()
$seededAt = Get-Date

foreach ($branchCode in ($actualMatrix.Keys | Sort-Object)) {
  foreach ($monthNumber in ($actualMatrix[$branchCode].Keys | Sort-Object)) {
    $key = "$branchCode|$monthNumber"
    $row = $rowIndex[$key]
    if (-not $row) {
      $missing += [pscustomobject]@{
        branch_code = $branchCode
        fiscal_year = $FiscalYear
        month = [int]$monthNumber
        status = "missing_budget_archive_row"
      }
      continue
    }

    $actualValue = [decimal]$actualMatrix[$branchCode][$monthNumber]
    Set-CrmRecord -conn $connection -EntityLogicalName "qfu_budgetarchive" -Id $row.qfu_budgetarchiveid -Fields @{
      qfu_actualsales = $actualValue
      qfu_lastupdated = $seededAt
    } | Out-Null

    $updates += [pscustomobject]@{
      branch_code = $branchCode
      fiscal_year = $FiscalYear
      month = [int]$monthNumber
      month_name = [string]$row.qfu_monthname
      budget_target = [decimal]($row.qfu_budgetgoal | ForEach-Object { if ($_ -ne $null) { $_ } else { 0 } })
      actual_sales = $actualValue
      budget_archive_id = [string]$row.qfu_budgetarchiveid
      status = "updated"
    }
  }
}

$result = [ordered]@{
  target_environment = $TargetEnvironmentUrl
  fiscal_year = $FiscalYear
  created_attribute = [bool]$createdAttribute
  updated_count = $updates.Count
  missing_count = $missing.Count
  updated_rows = $updates
  missing_rows = $missing
  seeded_at = $seededAt.ToString("o")
}

$resolvedOutput = if ([System.IO.Path]::IsPathRooted($OutputJson)) { $OutputJson } else { Join-Path (Get-Location) $OutputJson }
Ensure-Directory (Split-Path -Parent $resolvedOutput)
$result | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $resolvedOutput
$result | ConvertTo-Json -Depth 6
