const fs = require("fs");
const path = require("path");

const playwrightRoot = path.resolve(__dirname, "..", "Archive", "playwright", "node_modules", "playwright");
const { chromium } = require(playwrightRoot);

async function main() {
  const [urlArg, userDataDirArg, storageStateArg] = process.argv.slice(2);

  if (!urlArg || !userDataDirArg || !storageStateArg) {
    console.error("Usage: node portal-auth-session.cjs <url> <userDataDir> <storageStatePath>");
    process.exit(2);
  }

  const url = urlArg;
  const userDataDir = path.resolve(userDataDirArg);
  const storageStatePath = path.resolve(storageStateArg);

  fs.mkdirSync(userDataDir, { recursive: true });
  fs.mkdirSync(path.dirname(storageStatePath), { recursive: true });

  const context = await chromium.launchPersistentContext(userDataDir, {
    headless: false,
    viewport: { width: 1600, height: 1000 },
  });

  const page = context.pages()[0] || (await context.newPage());
  await page.goto(url, { waitUntil: "domcontentloaded", timeout: 90_000 });

  async function saveState() {
    try {
      await context.storageState({ path: storageStatePath });
      process.stdout.write(`[portal-auth-session] storage state saved to ${storageStatePath}\n`);
    } catch (error) {
      process.stdout.write(`[portal-auth-session] storage state save failed: ${error.message}\n`);
    }
  }

  const saveTimer = setInterval(saveState, 5000);
  await saveState();

  process.stdout.write(`[portal-auth-session] Browser opened at ${url}\n`);
  process.stdout.write("[portal-auth-session] Authenticate in the browser window. Close the browser window when you are done.\n");

  const browser = context.browser();
  browser.on("disconnected", () => {
    clearInterval(saveTimer);
    process.exit(0);
  });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
