param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com",
  [string]$PdfRoot = "DATA\GL060",
  [string[]]$BranchCodes = @("4171", "4172", "4173"),
  [string]$OutputJson = "results\gl060-queue-seed-summary.json"
)

$ErrorActionPreference = "Stop"

. (Join-Path $RepoRoot "scripts\deploy-southern-alberta-pilot.ps1")

function New-QueuedGl060Record {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$BranchCode,
    [string]$BranchSlug,
    [string]$RegionSlug,
    [string]$PdfPath
  )

  $sourceId = "{0}|raw|GL060|{1}" -f $BranchCode, ([guid]::NewGuid().Guid)
  $fileName = Split-Path -Leaf $PdfPath
  $base64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($PdfPath))

  New-CrmRecord -conn $Connection -EntityLogicalName "qfu_rawdocument" -Fields @{
    qfu_name = "$BranchCode GL060 $fileName"
    qfu_sourceid = $sourceId
    qfu_branchcode = $BranchCode
    qfu_branchslug = $BranchSlug
    qfu_regionslug = $RegionSlug
    qfu_sourcefamily = "GL060"
    qfu_sourcefile = $fileName
    qfu_status = "queued"
    qfu_receivedon = [datetime]::UtcNow
    qfu_rawcontentbase64 = $base64
    qfu_processingnotes = "Queued from PDF replay helper."
  } | Out-Null

  New-CrmRecord -conn $Connection -EntityLogicalName "qfu_ingestionbatch" -Fields @{
    qfu_name = "$BranchCode GL060 Inbox Import"
    qfu_sourceid = $sourceId
    qfu_branchcode = $BranchCode
    qfu_branchslug = $BranchSlug
    qfu_regionslug = $RegionSlug
    qfu_sourcefamily = "GL060"
    qfu_sourcefilename = $fileName
    qfu_status = "queued"
    qfu_insertedcount = 0
    qfu_updatedcount = 0
    qfu_startedon = [datetime]::UtcNow
    qfu_triggerflow = "GL060 PDF Replay Helper"
    qfu_notes = "Queued from repo PDF replay helper."
  } | Out-Null

  return [pscustomobject]@{
    branch_code = $BranchCode
    source_id = $sourceId
    file_name = $fileName
  }
}

$target = Connect-Org -Url $TargetEnvironmentUrl
Write-Host "Connected target: $($target.ConnectedOrgFriendlyName)"

Ensure-MinimalSchema -Connection $target

$branchMap = @{
  "4171" = [pscustomobject]@{ BranchSlug = "4171-calgary"; RegionSlug = "southern-alberta" }
  "4172" = [pscustomobject]@{ BranchSlug = "4172-lethbridge"; RegionSlug = "southern-alberta" }
  "4173" = [pscustomobject]@{ BranchSlug = "4173-medicine-hat"; RegionSlug = "southern-alberta" }
}

$results = New-Object System.Collections.Generic.List[object]
$pdfRootFullPath = Join-Path $RepoRoot $PdfRoot
foreach ($branchCode in $BranchCodes) {
  $branch = $branchMap[$branchCode]
  if (-not $branch) {
    throw "Unsupported branch code: $branchCode"
  }

  $branchRoot = Join-Path $pdfRootFullPath $branchCode
  $pdf = Get-ChildItem -Path $branchRoot -Filter "GL060*.pdf" | Sort-Object LastWriteTime -Descending | Select-Object -First 1
  if (-not $pdf) {
    throw "No GL060 PDF found under $branchRoot"
  }

  $results.Add((New-QueuedGl060Record -Connection $target -BranchCode $branchCode -BranchSlug $branch.BranchSlug -RegionSlug $branch.RegionSlug -PdfPath $pdf.FullName)) | Out-Null
}

$result = [ordered]@{
  target_environment = $TargetEnvironmentUrl
  queued = @($results.ToArray())
}

Write-Utf8Json -Path (Join-Path $RepoRoot $OutputJson) -Object $result
Write-Output ($result | ConvertTo-Json -Depth 6)
