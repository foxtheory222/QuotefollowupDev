param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com"
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Add-Type -AssemblyName "Microsoft.Xrm.Sdk"

$permissionIds = @(
  "1b488c88-5727-41ff-a25e-c5785b72d474", # qfu_quote
  "0d108fe0-b734-4108-910b-a99477522552", # qfu_backorder
  "fb62dfc4-53df-4903-b151-0f09da10c77c", # qfu_budget
  "96585e97-fb6f-4b96-a404-72ec233f0fef", # qfu_branchdailysummary
  "2bf5fa89-11aa-4c1c-ac29-29cded41b58a", # qfu_branch
  "b11c6f19-c0e2-4312-b8bd-354bdbbdc27c", # qfu_region
  "426db1d4-eb36-4557-b1f3-2b01884ead44", # qfu_ingestionbatch
  "868fedd2-9c5d-463c-a9eb-4e5ce22c97c8"  # qfu_sourcefeed
)

$roleIds = @(
  "0d42a052-4ceb-4d02-bfb1-eea0860bcae9", # Authenticated Users
  "d1681251-ec76-4138-b394-038772b4aa90", # Administrators
  "695703dc-ec50-466e-a28c-9878fe269a7a"  # Anonymous Users
)

$conn = Connect-CrmOnline -ServerUrl $TargetEnvironmentUrl -ForceOAuth -Username $Username
if (-not $conn -or -not $conn.IsReady) {
  throw "Dataverse connection failed for $TargetEnvironmentUrl : $($conn.LastCrmError)"
}

function Add-WebRoleAssociation {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [guid]$PermissionId,
    [guid]$RoleId
  )

  $request = [Microsoft.Xrm.Sdk.Messages.AssociateRequest]::new()
  $request.Target = [Microsoft.Xrm.Sdk.EntityReference]::new("mspp_entitypermission", $PermissionId)
  $request.Relationship = [Microsoft.Xrm.Sdk.Relationship]::new("mspp_entitypermission_webrole")
  $request.RelatedEntities = [Microsoft.Xrm.Sdk.EntityReferenceCollection]::new()
  $request.RelatedEntities.Add([Microsoft.Xrm.Sdk.EntityReference]::new("mspp_webrole", $RoleId))

  try {
    $null = $Connection.Execute($request)
    Write-Host "Associated permission $PermissionId -> role $RoleId"
  } catch {
    $message = $_.Exception.Message
    if ($message -like "*matching key values already exists*" -or $message -like "*Cannot insert duplicate key*" -or $message -like "*already exists*") {
      Write-Host "Association already exists: $PermissionId -> $RoleId"
      return
    }
    throw
  }
}

foreach ($permissionId in $permissionIds) {
  foreach ($roleId in $roleIds) {
    Add-WebRoleAssociation -Connection $conn -PermissionId ([guid]$permissionId) -RoleId ([guid]$roleId)
  }
}
