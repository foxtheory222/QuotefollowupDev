from __future__ import annotations

import copy
import json
import uuid
from collections import OrderedDict
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
TARGET_FILES = [
    REPO_ROOT / "results" / "sapilotflows" / "src" / "Workflows" / "4171-Budget-Update-SA1300-6DB19FF3-C313-4DB6-9A57-F3335FE55558.json",
    REPO_ROOT / "results" / "sapilotflows" / "src" / "Workflows" / "4172-Budget-Update-SA1300-078CEA4C-84F6-4C4F-B73B-62AD838F7CAE.json",
    REPO_ROOT / "results" / "sapilotflows" / "src" / "Workflows" / "4173-Budget-Update-SA1300-3C2EBD80-35D9-4E3C-BDBE-70BE98A82AE6.json",
    REPO_ROOT / "results" / "qfu-sapilotflows-target-expanded" / "Workflows" / "4171-Budget-Update-SA1300-6DB19FF3-C313-4DB6-9A57-F3335FE55558.json",
    REPO_ROOT / "results" / "qfu-sapilotflows-target-expanded" / "Workflows" / "4172-Budget-Update-SA1300-078CEA4C-84F6-4C4F-B73B-62AD838F7CAE.json",
    REPO_ROOT / "results" / "qfu-sapilotflows-target-expanded" / "Workflows" / "4173-Budget-Update-SA1300-3C2EBD80-35D9-4E3C-BDBE-70BE98A82AE6.json",
    REPO_ROOT / "results" / "live-refresh-20260407-074015" / "solutions" / "qfu_sapilotflows" / "Workflows" / "4171-Budget-Update-SA1300-6DB19FF3-C313-4DB6-9A57-F3335FE55558.json",
    REPO_ROOT / "results" / "live-refresh-20260407-074015" / "solutions" / "qfu_sapilotflows" / "Workflows" / "4172-Budget-Update-SA1300-078CEA4C-84F6-4C4F-B73B-62AD838F7CAE.json",
    REPO_ROOT / "results" / "live-refresh-20260407-074015" / "solutions" / "qfu_sapilotflows" / "Workflows" / "4173-Budget-Update-SA1300-3C2EBD80-35D9-4E3C-BDBE-70BE98A82AE6.json",
]


CURRENT_MONTH_SOURCE_ID_EXPR = (
    "@concat(parameters('qfu_QFU_BranchCode'), '|SA1300|', "
    "formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'yyyy-MM'))"
)
CURRENT_MONTH_NAME_EXPR = (
    "@concat(parameters('qfu_QFU_BranchCode'), ' ', "
    "formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'MMMM yyyy'), ' Budget')"
)
CURRENT_MONTH_BUDGETNAME_EXPR = (
    "@concat(formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'MMMM'), ' ', "
    "formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'yyyy'), ' Budget')"
)
CURRENT_MONTH_EXPR = "@int(formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'MM'))"
CURRENT_YEAR_EXPR = "@int(formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'yyyy'))"
CURRENT_MONTHNAME_EXPR = "@formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'MMMM')"
BUDGET_GOAL_EXPR = "@first(outputs('Get_Budget_Goal_From_Archives')?['body/value'])?['qfu_budgetgoal']"
CURRENT_MONTH_LOOKUP_EXPR = "@length(outputs('Get_Current_Month_Budget_Record')?['body/value'])"
CURRENT_MONTH_RECORD_ID_EXPR = "@outputs('Get_Current_Month_Budget_Record')?['body/value']?[0]?['qfu_budgetid']"


def metadata_block() -> dict:
    return {"operationMetadataId": str(uuid.uuid4())}


def current_month_exists_expression() -> dict:
    return {"and": [{"greater": [CURRENT_MONTH_LOOKUP_EXPR, 0]}]}


def apply_current_month_budget_fields(item: dict) -> None:
    item.update(
        {
            "qfu_usdsales": "@variables('USDSales')",
            "qfu_year": CURRENT_YEAR_EXPR,
            "qfu_actualsales": "@variables('TotalSales')",
            "qfu_monthname": CURRENT_MONTHNAME_EXPR,
            "qfu_month": CURRENT_MONTH_EXPR,
            "qfu_isactive": False,
            "qfu_fiscalyear": "@parameters('qfu_QFU_ActiveFiscalYear')",
            "qfu_budgetamount": BUDGET_GOAL_EXPR,
            "qfu_customername": "@parameters('qfu_QFU_BranchName')",
            "qfu_lastupdated": "@utcNow()",
            "qfu_sourcefile": "@items('Apply_to_each_Attachment')?['name']",
            "qfu_budgetgoal": BUDGET_GOAL_EXPR,
            "qfu_cadsales": "@variables('CADSales')",
            "qfu_budgetname": CURRENT_MONTH_BUDGETNAME_EXPR,
            "qfu_name": CURRENT_MONTH_NAME_EXPR,
            "qfu_sourceid": CURRENT_MONTH_SOURCE_ID_EXPR,
            "qfu_branchcode": "@parameters('qfu_QFU_BranchCode')",
            "qfu_branchslug": "@parameters('qfu_QFU_BranchSlug')",
            "qfu_regionslug": "@parameters('qfu_QFU_RegionSlug')",
            "qfu_sourcefamily": "SA1300",
        }
    )


def ensure_create_action_fields(action: dict) -> None:
    parameters = action["inputs"]["parameters"]
    parameters["item/qfu_name"] = CURRENT_MONTH_NAME_EXPR
    parameters["item/qfu_sourceid"] = CURRENT_MONTH_SOURCE_ID_EXPR
    parameters["item/qfu_budgetname"] = CURRENT_MONTH_NAME_EXPR
    parameters["item/qfu_budgetamount"] = BUDGET_GOAL_EXPR
    parameters["item/qfu_customername"] = "@parameters('qfu_QFU_BranchName')"
    parameters["item/qfu_branchcode"] = "@parameters('qfu_QFU_BranchCode')"
    parameters["item/qfu_branchslug"] = "@parameters('qfu_QFU_BranchSlug')"
    parameters["item/qfu_regionslug"] = "@parameters('qfu_QFU_RegionSlug')"
    parameters["item/qfu_sourcefamily"] = "SA1300"
    apply_current_month_budget_fields(parameters.setdefault("item", {}))


def ensure_update_action_fields(action: dict, record_id_expr: str) -> None:
    parameters = action["inputs"]["parameters"]
    parameters["recordId"] = record_id_expr
    apply_current_month_budget_fields(parameters.setdefault("item", {}))


def build_current_month_lookup_action(template_action: dict) -> dict:
    lookup_action = copy.deepcopy(template_action)
    lookup_action["inputs"]["parameters"]["$filter"] = (
        "qfu_branchcode eq '@{parameters('qfu_QFU_BranchCode')}' "
        "and qfu_sourcefamily eq 'SA1300' "
        "and qfu_sourceid eq '@{concat(parameters('qfu_QFU_BranchCode'), '|SA1300|', "
        "formatDateTime(convertTimeZone(utcNow(), 'UTC', 'Mountain Standard Time'), 'yyyy-MM'))}'"
    )
    lookup_action["inputs"]["parameters"]["$orderby"] = "createdon desc"
    lookup_action["inputs"]["parameters"]["$top"] = 1
    lookup_action["runAfter"] = {"Get_Active_Budget": ["Succeeded"]}
    lookup_action["metadata"] = metadata_block()
    return lookup_action


def build_current_month_update_action(template_action: dict) -> dict:
    update_action = copy.deepcopy(template_action)
    ensure_update_action_fields(update_action, CURRENT_MONTH_RECORD_ID_EXPR)
    update_action["metadata"] = metadata_block()
    return update_action


def patch_file(path: Path) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    actions = (
        data["properties"]["definition"]["actions"]["Apply_to_each_Attachment"]["actions"][
            "Condition_Is_SA1300_File"
        ]["actions"]
    )

    actions["Create_Budget_Table"][
        "description"
    ] = "Create a dedicated Current Month-To-Date Sales table for the SA1300 attachment."

    actions["Get_Budget_Tables"]["runAfter"] = {"Create_Budget_Table": ["Succeeded"]}

    actions["List_Budget_Rows"][
        "description"
    ] = "List budget rows from the table created for Current Month-To-Date Sales."
    actions["List_Budget_Rows"]["inputs"]["parameters"][
        "table"
    ] = "@coalesce(body('Create_Budget_Table')?['id'], body('Create_Budget_Table')?['Id'])"
    actions["List_Budget_Rows"]["runAfter"] = {"Create_Budget_Table": ["Succeeded"]}

    actions["Filter_Budget_Rows"][
        "description"
    ] = "Keep only populated Current Month-To-Date Sales rows."

    guard_actions = actions["Guard_Budget_Row_Limit"]["actions"]
    get_active_budget = guard_actions["Get_Active_Budget"]
    get_active_budget["inputs"]["parameters"]["$filter"] = (
        "qfu_isactive eq false and qfu_branchcode eq '@{parameters('qfu_QFU_BranchCode')}' "
        "and qfu_sourcefamily eq 'SA1300'"
    )
    get_active_budget["inputs"]["parameters"]["$orderby"] = "qfu_lastupdated desc, createdon desc"
    get_active_budget["inputs"]["parameters"]["$top"] = 1

    current_month_lookup = build_current_month_lookup_action(get_active_budget)
    updated_guard_actions = OrderedDict()
    for action_name, action_value in guard_actions.items():
        if action_name == "Get_Current_Month_Budget_Record":
            continue
        updated_guard_actions[action_name] = action_value
        if action_name == "Get_Active_Budget":
            updated_guard_actions["Get_Current_Month_Budget_Record"] = current_month_lookup
    actions["Guard_Budget_Row_Limit"]["actions"] = updated_guard_actions
    guard_actions = actions["Guard_Budget_Row_Limit"]["actions"]

    month_changed_condition = guard_actions["Condition_Check_Month_Changed"]
    month_changed_condition["runAfter"] = {"Get_Current_Month_Budget_Record": ["Succeeded"]}

    month_changed_actions = month_changed_condition["actions"]
    existing_month_changed_condition = month_changed_actions.get("Condition_Current_Month_Budget_Record_Exists")
    month_change_create_action = (
        existing_month_changed_condition["else"]["actions"]["Create_New_Month_Budget_Record"]
        if existing_month_changed_condition
        else month_changed_actions["Create_New_Month_Budget_Record"]
    )
    ensure_create_action_fields(month_change_create_action)

    same_month_condition = month_changed_condition["else"]["actions"]["Condition_Budget_Exists_Same_Month"]
    same_month_condition["expression"] = current_month_exists_expression()

    update_current_action = same_month_condition["actions"]["Update_Current_Month_Budget"]
    ensure_update_action_fields(update_current_action, CURRENT_MONTH_RECORD_ID_EXPR)

    create_first_action = same_month_condition["else"]["actions"]["Create_First_Budget_Record"]
    ensure_create_action_fields(create_first_action)

    month_changed_update_current = build_current_month_update_action(update_current_action)
    create_new_action = copy.deepcopy(month_change_create_action)
    create_new_action.pop("runAfter", None)

    month_changed_actions["Condition_Current_Month_Budget_Record_Exists"] = {
        "type": "If",
        "expression": current_month_exists_expression(),
        "actions": {
            "Update_Current_Month_Budget_Record": month_changed_update_current,
        },
        "else": {
            "actions": {
                "Create_New_Month_Budget_Record": create_new_action,
            }
        },
        "runAfter": {"Deactivate_Old_Budget_Record": ["Succeeded"]},
        "metadata": metadata_block(),
    }
    month_changed_actions.pop("Create_New_Month_Budget_Record", None)

    archive_action = month_changed_actions["Archive_Previous_Month_Budget"]["inputs"]["parameters"]
    archive_action["item/qfu_sourcefamily"] = "SA1300"
    archive_action["item/qfu_sourcefile"] = "@items('Apply_to_each_Attachment')?['name']"
    archive_action["item/qfu_branchcode"] = "@parameters('qfu_QFU_BranchCode')"
    archive_action["item/qfu_branchslug"] = "@parameters('qfu_QFU_BranchSlug')"
    archive_action["item/qfu_regionslug"] = "@parameters('qfu_QFU_RegionSlug')"
    archive_action["item/qfu_lastupdated"] = "@utcNow()"

    month_changed_actions["Deactivate_Old_Budget_Record"]["inputs"]["parameters"]["item"]["qfu_isactive"] = True

    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def main() -> None:
    for path in TARGET_FILES:
        if path.exists():
            patch_file(path)
            print(f"patched {path}")
        else:
            print(f"missing {path}")


if __name__ == "__main__":
    main()
