param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$TargetEnvironmentName = "9f2e54c6-c349-e7e1-ac7c-010d3adf3c03",
  [string]$Username = "smcfarlane@applied.com",
  [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Import-Module Microsoft.PowerApps.Administration.PowerShell

$flowCatalog = @(
  [pscustomobject]@{ DisplayName = "4171-QuoteFollowUp-Import-Staging"; WorkflowEntityId = "0aff92f1-a8f0-45d7-b05c-3afe5ade9ed1"; Action = "toggle" },
  [pscustomobject]@{ DisplayName = "4171-BackOrder-Update-ZBO"; WorkflowEntityId = "94ae1bae-fe22-455e-bf63-24ba92644dc0"; Action = "enable" },
  [pscustomobject]@{ DisplayName = "4171-Budget-Update-SA1300"; WorkflowEntityId = "6db19ff3-c313-4db6-9a57-f3335fe55558"; Action = "enable" },
  [pscustomobject]@{ DisplayName = "4171-GL060-Inbox-Ingress"; WorkflowEntityId = "fd1ec8dc-56ca-4af7-ab8d-49465802b52a"; Action = "toggle" },
  [pscustomobject]@{ DisplayName = "4172-QuoteFollowUp-Import-Staging"; WorkflowEntityId = "3520a9d9-f40d-430b-aec8-56b9f4c5d96c"; Action = "toggle" },
  [pscustomobject]@{ DisplayName = "4172-BackOrder-Update-ZBO"; WorkflowEntityId = "a5a911cc-1d2d-4e5a-b0ab-da6f52def8b0"; Action = "enable" },
  [pscustomobject]@{ DisplayName = "4172-Budget-Update-SA1300"; WorkflowEntityId = "078cea4c-84f6-4c4f-b73b-62ad838f7cae"; Action = "enable" },
  [pscustomobject]@{ DisplayName = "4172-GL060-Inbox-Ingress"; WorkflowEntityId = "7447f66d-93d0-44dd-9bf4-449e320190e7"; Action = "toggle" },
  [pscustomobject]@{ DisplayName = "4173-QuoteFollowUp-Import-Staging"; WorkflowEntityId = "490e1685-4623-461e-ba1c-6c0907a60e33"; Action = "toggle" },
  [pscustomobject]@{ DisplayName = "4173-BackOrder-Update-ZBO"; WorkflowEntityId = "3277dd8e-14f6-4e7b-b627-ebc923ba86ef"; Action = "enable" },
  [pscustomobject]@{ DisplayName = "4173-Budget-Update-SA1300"; WorkflowEntityId = "3c2ebd80-35d9-4e3c-bdbe-70be98a82ae6"; Action = "enable" },
  [pscustomobject]@{ DisplayName = "4173-GL060-Inbox-Ingress"; WorkflowEntityId = "cb327979-b304-4b7f-9a42-44c01c959666"; Action = "toggle" }
)

function Ensure-Directory {
  param([string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Write-Utf8Json {
  param(
    [string]$Path,
    [object]$Object
  )

  $directory = Split-Path -Parent $Path
  if ($directory) {
    Ensure-Directory -Path $directory
  }

  $json = $Object | ConvertTo-Json -Depth 20
  [System.IO.File]::WriteAllText($Path, $json, [System.Text.UTF8Encoding]::new($false))
}

function Connect-Org {
  param([string]$Url)

  $conn = Connect-CrmOnline -ServerUrl $Url -ForceOAuth -Username $Username
  if (-not $conn -or -not $conn.IsReady) {
    throw "Dataverse connection failed for $Url : $($conn.LastCrmError)"
  }

  return $conn
}

function Get-WorkflowSnapshot {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$WorkflowEntityId
  )

  $row = Get-CrmRecord -conn $Connection -EntityLogicalName workflow -Id $WorkflowEntityId -Fields name, statecode, statuscode, modifiedon
  return [pscustomobject]@{
    workflow_name = $row.name
    workflow_statecode = $row.statecode
    workflow_statuscode = $row.statuscode
    workflow_modifiedon = $row.modifiedon
  }
}

function Get-AdminFlowMap {
  param([string]$EnvironmentName)

  $map = @{}
  foreach ($flow in @(Get-AdminFlow -EnvironmentName $EnvironmentName | Where-Object { $_.WorkflowEntityId -in $flowCatalog.WorkflowEntityId })) {
    $map[[string]$flow.WorkflowEntityId] = $flow
  }

  return $map
}

function Get-AdminSnapshot {
  param([hashtable]$FlowMap, [string]$WorkflowEntityId)

  $flow = $FlowMap[[string]$WorkflowEntityId]
  if (-not $flow) {
    return $null
  }

  return [pscustomobject]@{
    flow_name = $flow.FlowName
    enabled = [bool]$flow.Enabled
    state = $flow.State
    last_modified_time = $flow.LastModifiedTime
  }
}

function Ensure-WorkflowActivated {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$WorkflowEntityId
  )

  Set-CrmRecordState -conn $Connection -EntityLogicalName workflow -Id $WorkflowEntityId -StateCode Activated -StatusCode Activated | Out-Null
}

function Enable-FlowWithRetry {
  param(
    [string]$EnvironmentName,
    [string]$FlowName
  )

  Enable-AdminFlow -EnvironmentName $EnvironmentName -FlowName $FlowName | Out-Null
  Start-Sleep -Seconds 3
}

function Toggle-FlowSubscription {
  param(
    [string]$EnvironmentName,
    [string]$FlowName
  )

  Disable-AdminFlow -EnvironmentName $EnvironmentName -FlowName $FlowName | Out-Null
  Start-Sleep -Seconds 3
  Enable-AdminFlow -EnvironmentName $EnvironmentName -FlowName $FlowName | Out-Null
  Start-Sleep -Seconds 3
}

function Repair-IfNotEnabled {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EnvironmentName,
    [string]$WorkflowEntityId,
    [string]$FlowName
  )

  $adminMap = Get-AdminFlowMap -EnvironmentName $EnvironmentName
  $admin = Get-AdminSnapshot -FlowMap $adminMap -WorkflowEntityId $WorkflowEntityId
  $workflow = Get-WorkflowSnapshot -Connection $Connection -WorkflowEntityId $WorkflowEntityId

  if ($admin -and $admin.enabled -and $workflow.workflow_statecode -eq "Activated") {
    return
  }

  Ensure-WorkflowActivated -Connection $Connection -WorkflowEntityId $WorkflowEntityId
  Enable-FlowWithRetry -EnvironmentName $EnvironmentName -FlowName $FlowName
}

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
  $OutputPath = Join-Path (Join-Path (Get-Location) "results") "southern-alberta-mailbox-flow-reactivation-$stamp.json"
}

$connection = Connect-Org -Url $TargetEnvironmentUrl
Add-PowerAppsAccount -Endpoint prod -Username $Username | Out-Null

$beforeAdminMap = Get-AdminFlowMap -EnvironmentName $TargetEnvironmentName
$rows = New-Object System.Collections.Generic.List[object]

foreach ($target in $flowCatalog) {
  $beforeWorkflow = Get-WorkflowSnapshot -Connection $connection -WorkflowEntityId $target.WorkflowEntityId
  $beforeAdmin = Get-AdminSnapshot -FlowMap $beforeAdminMap -WorkflowEntityId $target.WorkflowEntityId
  if (-not $beforeAdmin) {
    throw "Admin flow not found for $($target.DisplayName) [$($target.WorkflowEntityId)]"
  }

  Ensure-WorkflowActivated -Connection $connection -WorkflowEntityId $target.WorkflowEntityId

  if ($target.Action -eq "toggle") {
    Toggle-FlowSubscription -EnvironmentName $TargetEnvironmentName -FlowName $beforeAdmin.flow_name
  } else {
    Enable-FlowWithRetry -EnvironmentName $TargetEnvironmentName -FlowName $beforeAdmin.flow_name
  }

  Repair-IfNotEnabled -Connection $connection -EnvironmentName $TargetEnvironmentName -WorkflowEntityId $target.WorkflowEntityId -FlowName $beforeAdmin.flow_name

  $afterWorkflow = Get-WorkflowSnapshot -Connection $connection -WorkflowEntityId $target.WorkflowEntityId
  $afterAdminMap = Get-AdminFlowMap -EnvironmentName $TargetEnvironmentName
  $afterAdmin = Get-AdminSnapshot -FlowMap $afterAdminMap -WorkflowEntityId $target.WorkflowEntityId

  $rows.Add([pscustomobject]@{
    display_name = $target.DisplayName
    workflow_entity_id = $target.WorkflowEntityId
    action = $target.Action
    before_workflow = $beforeWorkflow
    before_admin = $beforeAdmin
    after_workflow = $afterWorkflow
    after_admin = $afterAdmin
  }) | Out-Null
}

$report = [pscustomobject]@{
  captured_at = (Get-Date).ToUniversalTime().ToString("o")
  target_environment_url = $TargetEnvironmentUrl
  target_environment_name = $TargetEnvironmentName
  rows = @($rows.ToArray())
}

Write-Utf8Json -Path $OutputPath -Object $report

$rows |
  Select-Object display_name, action,
    @{ Name = "workflow_state_before"; Expression = { $_.before_workflow.workflow_statecode } },
    @{ Name = "workflow_state_after"; Expression = { $_.after_workflow.workflow_statecode } },
    @{ Name = "flow_enabled_before"; Expression = { $_.before_admin.enabled } },
    @{ Name = "flow_enabled_after"; Expression = { $_.after_admin.enabled } } |
  Format-Table -AutoSize

Write-Host "OUTPUT_PATH=$OutputPath"
