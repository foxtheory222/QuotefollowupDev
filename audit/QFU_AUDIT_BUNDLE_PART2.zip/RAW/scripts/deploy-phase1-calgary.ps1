param(
  [string]$SourceEnvironmentUrl = "https://orgad610d2c.crm3.dynamics.com",
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com",
  [string]$SolutionUniqueName = "Default",
  [string]$OutputJson = "results\\phase1-calgary-sync-summary.json",
  [int]$GraceDays = 3
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Add-Type -AssemblyName "Microsoft.Xrm.Sdk"
Add-Type -AssemblyName "Microsoft.Crm.Sdk.Proxy"

function New-Label {
  param([string]$Text)
  return [Microsoft.Xrm.Sdk.Label]::new($Text, 1033)
}

function New-RequiredLevel {
  param([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]$Level)
  return [Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevelManagedProperty]::new($Level)
}

function Ensure-Directory {
  param([string]$Path)
  if (-not (Test-Path $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Write-Utf8Json {
  param(
    [string]$Path,
    [object]$Object
  )

  $parent = Split-Path -Parent $Path
  if ($parent) {
    Ensure-Directory $parent
  }

  $json = $Object | ConvertTo-Json -Depth 10
  [System.IO.File]::WriteAllText($Path, $json, (New-Object System.Text.UTF8Encoding($false)))
}

function Connect-Org {
  param([string]$Url)

  $conn = Connect-CrmOnline -ServerUrl $Url -ForceOAuth -Username $Username
  if (-not $conn -or -not $conn.IsReady) {
    throw "Dataverse connection failed for $Url : $($conn.LastCrmError)"
  }

  return $conn
}

function Test-EntityExists {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$LogicalName
  )

  try {
    $request = [Microsoft.Xrm.Sdk.Messages.RetrieveEntityRequest]::new()
    $request.LogicalName = $LogicalName
    $request.EntityFilters = [Microsoft.Xrm.Sdk.Metadata.EntityFilters]::Entity
    $request.RetrieveAsIfPublished = $true
    $null = $Connection.Execute($request)
    return $true
  } catch {
    return $false
  }
}

function Test-AttributeExists {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$AttributeLogicalName
  )

  try {
    $request = [Microsoft.Xrm.Sdk.Messages.RetrieveAttributeRequest]::new()
    $request.EntityLogicalName = $EntityLogicalName
    $request.LogicalName = $AttributeLogicalName
    $request.RetrieveAsIfPublished = $true
    $null = $Connection.Execute($request)
    return $true
  } catch {
    return $false
  }
}

function Publish-Entities {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string[]]$LogicalNames
  )

  $xml = "<importexportxml><entities>" + (($LogicalNames | ForEach-Object { "<entity>$_</entity>" }) -join "") + "</entities><nodes/><securityroles/><settings/><workflows/></importexportxml>"
  $request = [Microsoft.Crm.Sdk.Messages.PublishXmlRequest]::new()
  $request.ParameterXml = $xml
  $null = $Connection.Execute($request)
}

function Ensure-Entity {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$SchemaName,
    [string]$DisplayName,
    [string]$DisplayCollectionName,
    [string]$Description,
    [string]$PrimaryNameSchema,
    [string]$PrimaryNameDisplay,
    [int]$PrimaryNameLength = 200
  )

  if (Test-EntityExists -Connection $Connection -LogicalName $SchemaName) {
    Write-Host "Entity exists: $SchemaName"
    return
  }

  $entity = [Microsoft.Xrm.Sdk.Metadata.EntityMetadata]::new()
  $entity.SchemaName = $SchemaName
  $entity.DisplayName = New-Label $DisplayName
  $entity.DisplayCollectionName = New-Label $DisplayCollectionName
  $entity.Description = New-Label $Description
  $entity.OwnershipType = [Microsoft.Xrm.Sdk.Metadata.OwnershipTypes]::OrganizationOwned
  $entity.IsActivity = $false

  $primary = [Microsoft.Xrm.Sdk.Metadata.StringAttributeMetadata]::new()
  $primary.SchemaName = $PrimaryNameSchema
  $primary.DisplayName = New-Label $PrimaryNameDisplay
  $primary.RequiredLevel = New-RequiredLevel ([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]::ApplicationRequired)
  $primary.MaxLength = $PrimaryNameLength

  $request = [Microsoft.Xrm.Sdk.Messages.CreateEntityRequest]::new()
  $request.Entity = $entity
  $request.PrimaryAttribute = $primary
  $request.HasActivities = $false
  $request.HasFeedback = $false
  $request.HasNotes = $false
  if ($SolutionUniqueName) {
    $request.SolutionUniqueName = $SolutionUniqueName
  }
  $null = $Connection.Execute($request)

  Write-Host "Created entity: $SchemaName"
}

function Ensure-StringAttribute {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SchemaName,
    [string]$DisplayName,
    [int]$MaxLength = 200,
    [string]$Description = ""
  )

  if (Test-AttributeExists -Connection $Connection -EntityLogicalName $EntityLogicalName -AttributeLogicalName $SchemaName) {
    Write-Host "Attribute exists: $EntityLogicalName.$SchemaName"
    return
  }

  $attribute = [Microsoft.Xrm.Sdk.Metadata.StringAttributeMetadata]::new()
  $attribute.SchemaName = $SchemaName
  $attribute.DisplayName = New-Label $DisplayName
  $attribute.Description = New-Label $Description
  $attribute.RequiredLevel = New-RequiredLevel ([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]::None)
  $attribute.MaxLength = $MaxLength

  $request = [Microsoft.Xrm.Sdk.Messages.CreateAttributeRequest]::new()
  $request.EntityName = $EntityLogicalName
  $request.Attribute = $attribute
  if ($SolutionUniqueName) {
    $request.SolutionUniqueName = $SolutionUniqueName
  }
  $null = $Connection.Execute($request)

  Write-Host "Created string attribute: $EntityLogicalName.$SchemaName"
}

function Ensure-MemoAttribute {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SchemaName,
    [string]$DisplayName,
    [int]$MaxLength = 2000,
    [string]$Description = ""
  )

  if (Test-AttributeExists -Connection $Connection -EntityLogicalName $EntityLogicalName -AttributeLogicalName $SchemaName) {
    Write-Host "Attribute exists: $EntityLogicalName.$SchemaName"
    return
  }

  $attribute = [Microsoft.Xrm.Sdk.Metadata.MemoAttributeMetadata]::new()
  $attribute.SchemaName = $SchemaName
  $attribute.DisplayName = New-Label $DisplayName
  $attribute.Description = New-Label $Description
  $attribute.RequiredLevel = New-RequiredLevel ([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]::None)
  $attribute.MaxLength = $MaxLength

  $request = [Microsoft.Xrm.Sdk.Messages.CreateAttributeRequest]::new()
  $request.EntityName = $EntityLogicalName
  $request.Attribute = $attribute
  if ($SolutionUniqueName) {
    $request.SolutionUniqueName = $SolutionUniqueName
  }
  $null = $Connection.Execute($request)

  Write-Host "Created memo attribute: $EntityLogicalName.$SchemaName"
}

function Ensure-IntegerAttribute {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SchemaName,
    [string]$DisplayName,
    [int]$MinValue = -2147483648,
    [int]$MaxValue = 2147483647,
    [string]$Description = ""
  )

  if (Test-AttributeExists -Connection $Connection -EntityLogicalName $EntityLogicalName -AttributeLogicalName $SchemaName) {
    Write-Host "Attribute exists: $EntityLogicalName.$SchemaName"
    return
  }

  $attribute = [Microsoft.Xrm.Sdk.Metadata.IntegerAttributeMetadata]::new()
  $attribute.SchemaName = $SchemaName
  $attribute.DisplayName = New-Label $DisplayName
  $attribute.Description = New-Label $Description
  $attribute.RequiredLevel = New-RequiredLevel ([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]::None)
  $attribute.MinValue = $MinValue
  $attribute.MaxValue = $MaxValue

  $request = [Microsoft.Xrm.Sdk.Messages.CreateAttributeRequest]::new()
  $request.EntityName = $EntityLogicalName
  $request.Attribute = $attribute
  if ($SolutionUniqueName) {
    $request.SolutionUniqueName = $SolutionUniqueName
  }
  $null = $Connection.Execute($request)

  Write-Host "Created integer attribute: $EntityLogicalName.$SchemaName"
}

function Ensure-DecimalAttribute {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SchemaName,
    [string]$DisplayName,
    [int]$Precision = 2,
    [decimal]$MinValue = 0,
    [decimal]$MaxValue = 1000000000,
    [string]$Description = ""
  )

  if (Test-AttributeExists -Connection $Connection -EntityLogicalName $EntityLogicalName -AttributeLogicalName $SchemaName) {
    Write-Host "Attribute exists: $EntityLogicalName.$SchemaName"
    return
  }

  $attribute = [Microsoft.Xrm.Sdk.Metadata.DecimalAttributeMetadata]::new()
  $attribute.SchemaName = $SchemaName
  $attribute.DisplayName = New-Label $DisplayName
  $attribute.Description = New-Label $Description
  $attribute.RequiredLevel = New-RequiredLevel ([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]::None)
  $attribute.Precision = $Precision
  $attribute.MinValue = $MinValue
  $attribute.MaxValue = $MaxValue

  $request = [Microsoft.Xrm.Sdk.Messages.CreateAttributeRequest]::new()
  $request.EntityName = $EntityLogicalName
  $request.Attribute = $attribute
  if ($SolutionUniqueName) {
    $request.SolutionUniqueName = $SolutionUniqueName
  }
  $null = $Connection.Execute($request)

  Write-Host "Created decimal attribute: $EntityLogicalName.$SchemaName"
}

function Ensure-DateTimeAttribute {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SchemaName,
    [string]$DisplayName,
    [Microsoft.Xrm.Sdk.Metadata.DateTimeFormat]$Format = [Microsoft.Xrm.Sdk.Metadata.DateTimeFormat]::DateAndTime,
    [string]$Description = ""
  )

  if (Test-AttributeExists -Connection $Connection -EntityLogicalName $EntityLogicalName -AttributeLogicalName $SchemaName) {
    Write-Host "Attribute exists: $EntityLogicalName.$SchemaName"
    return
  }

  $attribute = [Microsoft.Xrm.Sdk.Metadata.DateTimeAttributeMetadata]::new()
  $attribute.SchemaName = $SchemaName
  $attribute.DisplayName = New-Label $DisplayName
  $attribute.Description = New-Label $Description
  $attribute.RequiredLevel = New-RequiredLevel ([Microsoft.Xrm.Sdk.Metadata.AttributeRequiredLevel]::None)
  $attribute.Format = $Format

  $request = [Microsoft.Xrm.Sdk.Messages.CreateAttributeRequest]::new()
  $request.EntityName = $EntityLogicalName
  $request.Attribute = $attribute
  if ($SolutionUniqueName) {
    $request.SolutionUniqueName = $SolutionUniqueName
  }
  $null = $Connection.Execute($request)

  Write-Host "Created datetime attribute: $EntityLogicalName.$SchemaName"
}

function Ensure-MinimalSchema {
  param([Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection)

  Ensure-Entity -Connection $Connection -SchemaName "qfu_quote" -DisplayName "QFU Quote" -DisplayCollectionName "QFU Quotes" -Description "Calgary Phase 1 quote headers synced from the legacy QFU source." -PrimaryNameSchema "qfu_name" -PrimaryNameDisplay "Name"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_sourceid" -DisplayName "Source Id" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_quotenumber" -DisplayName "Quote Number" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_customername" -DisplayName "Customer Name" -MaxLength 200
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_amount" -DisplayName "Amount" -Precision 2 -MinValue 0
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_assignedto" -DisplayName "Assigned To" -MaxLength 150
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_cssrname" -DisplayName "CSSR Name" -MaxLength 150
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_nextfollowup" -DisplayName "Next Follow Up"
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_overduesince" -DisplayName "Overdue Since"
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_lasttouchedon" -DisplayName "Last Touched On"
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_lastfollowupupdatedon" -DisplayName "Last Follow Up Updated On"
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_priorityscore" -DisplayName "Priority Score"
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_actionstate" -DisplayName "Action State"
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_status" -DisplayName "Status"
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_sourcedate" -DisplayName "Source Created On"
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_quote" -SchemaName "qfu_sourceupdatedon" -DisplayName "Source Updated On"

  Ensure-Entity -Connection $Connection -SchemaName "qfu_backorder" -DisplayName "QFU Backorder" -DisplayCollectionName "QFU Backorders" -Description "Calgary Phase 1 backorders synced from the legacy QFU source." -PrimaryNameSchema "qfu_name" -PrimaryNameDisplay "Name"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_sourceid" -DisplayName "Source Id" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_customername" -DisplayName "Customer Name" -MaxLength 200
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_totalvalue" -DisplayName "Total Value" -Precision 2 -MinValue 0
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_ontimedate" -DisplayName "On Time Date" -Format ([Microsoft.Xrm.Sdk.Metadata.DateTimeFormat]::DateOnly)
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_cssrname" -DisplayName "CSSR Name" -MaxLength 150
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_daysoverdue" -DisplayName "Days Overdue"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_salesdocnumber" -DisplayName "Sales Document Number" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_material" -DisplayName "Material" -MaxLength 100
  Ensure-MemoAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_description" -DisplayName "Description" -MaxLength 2000
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_backorder" -SchemaName "qfu_quantity" -DisplayName "Quantity" -Precision 2 -MinValue 0

  Ensure-Entity -Connection $Connection -SchemaName "qfu_budget" -DisplayName "QFU Budget" -DisplayCollectionName "QFU Budgets" -Description "Calgary Phase 1 budgets synced from the legacy QFU source." -PrimaryNameSchema "qfu_name" -PrimaryNameDisplay "Name"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_sourceid" -DisplayName "Source Id" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_budgetname" -DisplayName "Budget Name" -MaxLength 200
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_actualsales" -DisplayName "Actual Sales" -Precision 2 -MinValue 0
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_budgetgoal" -DisplayName "Budget Goal" -Precision 2 -MinValue 0
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_percentachieved" -DisplayName "Percent Achieved" -Precision 2 -MinValue 0 -MaxValue 1000
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_lastupdated" -DisplayName "Last Updated"
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_cadsales" -DisplayName "CAD Sales" -Precision 2 -MinValue 0
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_usdsales" -DisplayName "USD Sales" -Precision 2 -MinValue 0
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_month" -DisplayName "Month" -MinValue 1 -MaxValue 12
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_monthname" -DisplayName "Month Name" -MaxLength 50
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_year" -DisplayName "Year" -MinValue 2000 -MaxValue 2100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_budget" -SchemaName "qfu_sourcefile" -DisplayName "Source File" -MaxLength 250

  Publish-Entities -Connection $Connection -LogicalNames @("qfu_quote", "qfu_backorder", "qfu_budget")
}

function Convert-OptionalDate {
  param($Value)
  if ($null -eq $Value -or [string]::IsNullOrWhiteSpace("$Value")) {
    return $null
  }
  return [datetime]$Value
}

function Convert-OptionalDecimal {
  param($Value)
  if ($null -eq $Value -or [string]::IsNullOrWhiteSpace("$Value")) {
    return $null
  }
  return [decimal]$Value
}

function Convert-OptionalInt {
  param($Value)
  if ($null -eq $Value -or [string]::IsNullOrWhiteSpace("$Value")) {
    return $null
  }
  try {
    return [int]$Value
  } catch {
    return $null
  }
}

function Convert-OptionalText {
  param($Value)
  if ($null -eq $Value) {
    return $null
  }
  $text = "$Value".Trim()
  if ($text -eq "") {
    return $null
  }
  return $text
}

function Get-SingleRecord {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$FilterAttribute,
    [string]$FilterValue,
    [string[]]$Fields
  )

  return (Get-CrmRecords -conn $Connection -EntityLogicalName $EntityLogicalName -FilterAttribute $FilterAttribute -FilterOperator eq -FilterValue $FilterValue -Fields $Fields -TopCount 1).CrmRecords | Select-Object -First 1
}

function Upsert-RecordBySourceId {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SourceId,
    [hashtable]$Fields
  )

  $existing = Get-SingleRecord -Connection $Connection -EntityLogicalName $EntityLogicalName -FilterAttribute "qfu_sourceid" -FilterValue $SourceId -Fields @("${EntityLogicalName}id", "qfu_sourceid")
  if ($existing) {
    Update-CrmRecord -conn $Connection -EntityLogicalName $EntityLogicalName -Id $existing."${EntityLogicalName}id" -Fields $Fields | Out-Null
    return "updated"
  }

  $null = New-CrmRecord -conn $Connection -EntityLogicalName $EntityLogicalName -Fields $Fields
  return "created"
}

function Get-QuoteSourceRows {
  param([Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection)

  $fetch = @"
<fetch version='1.0' mapping='logical' count='5000'>
  <entity name='qfu_quote'>
    <attribute name='qfu_quoteid' />
    <attribute name='qfu_quotenumber' />
    <attribute name='qfu_customername' />
    <attribute name='qfu_amount' />
    <attribute name='qfu_assignedto' />
    <attribute name='qfu_cssrname' />
    <attribute name='qfu_nextfollowup' />
    <attribute name='qfu_overduesince' />
    <attribute name='qfu_lasttouchedon' />
    <attribute name='qfu_lastfollowupupdatedon' />
    <attribute name='qfu_priorityscore' />
    <attribute name='qfu_actionstate' />
    <attribute name='qfu_status' />
    <attribute name='createdon' />
    <attribute name='modifiedon' />
    <order attribute='qfu_priorityscore' descending='true' />
    <order attribute='qfu_quotenumber' descending='false' />
  </entity>
</fetch>
"@

  return @((Get-CrmRecordsByFetch -conn $Connection -Fetch $fetch).CrmRecords)
}

function Get-BackorderSourceRows {
  param([Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection)

  $fetch = @"
<fetch version='1.0' mapping='logical' count='5000'>
  <entity name='qfu_backorder'>
    <attribute name='qfu_backorderid' />
    <attribute name='qfu_name' />
    <attribute name='qfu_customername' />
    <attribute name='qfu_totalvalue' />
    <attribute name='qfu_ontimedate' />
    <attribute name='qfu_cssrname' />
    <attribute name='qfu_daysoverdue' />
    <attribute name='qfu_salesdocnumber' />
    <attribute name='qfu_material' />
    <attribute name='qfu_description' />
    <attribute name='qfu_quantity' />
    <order attribute='qfu_daysoverdue' descending='true' />
    <order attribute='qfu_ontimedate' descending='false' />
  </entity>
</fetch>
"@

  return @((Get-CrmRecordsByFetch -conn $Connection -Fetch $fetch).CrmRecords)
}

function Get-BudgetSourceRows {
  param([Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection)

  $fetch = @"
<fetch version='1.0' mapping='logical' count='500'>
  <entity name='qfu_budget'>
    <attribute name='qfu_budgetid' />
    <attribute name='qfu_budgetname' />
    <attribute name='qfu_actualsales' />
    <attribute name='qfu_budgetgoal' />
    <attribute name='qfu_percentachieved' />
    <attribute name='qfu_lastupdated' />
    <attribute name='qfu_cadsales' />
    <attribute name='qfu_usdsales' />
    <attribute name='qfu_month' />
    <attribute name='qfu_monthname' />
    <attribute name='qfu_year' />
    <attribute name='qfu_sourcefile' />
    <order attribute='qfu_year' descending='true' />
    <order attribute='qfu_month' descending='true' />
  </entity>
</fetch>
"@

  return @((Get-CrmRecordsByFetch -conn $Connection -Fetch $fetch).CrmRecords)
}

function Sync-Quotes {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$SourceConnection,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$TargetConnection
  )

  $created = 0
  $updated = 0
  $rows = Get-QuoteSourceRows -Connection $SourceConnection

  foreach ($row in $rows) {
    $sourceId = "$($row.qfu_quoteid)"
    $quoteNumber = Convert-OptionalText $row.qfu_quotenumber
    $customer = Convert-OptionalText $row.qfu_customername
    $name = @($quoteNumber, $customer) -join " - "
    if ([string]::IsNullOrWhiteSpace($name.Trim('- '))) {
      $name = $sourceId
    }

    $result = Upsert-RecordBySourceId -Connection $TargetConnection -EntityLogicalName "qfu_quote" -SourceId $sourceId -Fields @{
      qfu_name = $name
      qfu_sourceid = $sourceId
      qfu_quotenumber = $quoteNumber
      qfu_customername = $customer
      qfu_amount = Convert-OptionalDecimal $row.qfu_amount
      qfu_assignedto = (Convert-OptionalText $row.qfu_assignedto)
      qfu_cssrname = (Convert-OptionalText $row.qfu_cssrname)
      qfu_nextfollowup = Convert-OptionalDate $row.qfu_nextfollowup
      qfu_overduesince = Convert-OptionalDate $row.qfu_overduesince
      qfu_lasttouchedon = Convert-OptionalDate $row.qfu_lasttouchedon
      qfu_lastfollowupupdatedon = Convert-OptionalDate $row.qfu_lastfollowupupdatedon
      qfu_priorityscore = Convert-OptionalInt $row.qfu_priorityscore
      qfu_actionstate = Convert-OptionalInt $row.qfu_actionstate
      qfu_status = Convert-OptionalInt $row.qfu_status
      qfu_sourcedate = Convert-OptionalDate $row.createdon
      qfu_sourceupdatedon = Convert-OptionalDate $row.modifiedon
    }

    if ($result -eq "created") {
      $created += 1
    } else {
      $updated += 1
    }
  }

  return [pscustomobject]@{
    count = $rows.Count
    created = $created
    updated = $updated
  }
}

function Sync-Backorders {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$SourceConnection,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$TargetConnection
  )

  $created = 0
  $updated = 0
  $rows = Get-BackorderSourceRows -Connection $SourceConnection

  foreach ($row in $rows) {
    $sourceId = "$($row.qfu_backorderid)"
    $name = Convert-OptionalText $row.qfu_name
    if (-not $name) {
      $name = @((Convert-OptionalText $row.qfu_salesdocnumber), (Convert-OptionalText $row.qfu_material)) -join " - "
    }

    $result = Upsert-RecordBySourceId -Connection $TargetConnection -EntityLogicalName "qfu_backorder" -SourceId $sourceId -Fields @{
      qfu_name = $name
      qfu_sourceid = $sourceId
      qfu_customername = (Convert-OptionalText $row.qfu_customername)
      qfu_totalvalue = Convert-OptionalDecimal $row.qfu_totalvalue
      qfu_ontimedate = Convert-OptionalDate $row.qfu_ontimedate
      qfu_cssrname = (Convert-OptionalText $row.qfu_cssrname)
      qfu_daysoverdue = Convert-OptionalInt $row.qfu_daysoverdue
      qfu_salesdocnumber = (Convert-OptionalText $row.qfu_salesdocnumber)
      qfu_material = (Convert-OptionalText $row.qfu_material)
      qfu_description = (Convert-OptionalText $row.qfu_description)
      qfu_quantity = Convert-OptionalDecimal $row.qfu_quantity
    }

    if ($result -eq "created") {
      $created += 1
    } else {
      $updated += 1
    }
  }

  return [pscustomobject]@{
    count = $rows.Count
    created = $created
    updated = $updated
  }
}

function Sync-Budgets {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$SourceConnection,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$TargetConnection
  )

  $created = 0
  $updated = 0
  $rows = Get-BudgetSourceRows -Connection $SourceConnection

  foreach ($row in $rows) {
    $sourceId = "$($row.qfu_budgetid)"
    $name = Convert-OptionalText $row.qfu_budgetname
    if (-not $name) {
      $name = @((Convert-OptionalText $row.qfu_monthname), (Convert-OptionalInt $row.qfu_year)) -join " "
    }

    $result = Upsert-RecordBySourceId -Connection $TargetConnection -EntityLogicalName "qfu_budget" -SourceId $sourceId -Fields @{
      qfu_name = $name
      qfu_sourceid = $sourceId
      qfu_budgetname = $name
      qfu_actualsales = Convert-OptionalDecimal $row.qfu_actualsales
      qfu_budgetgoal = Convert-OptionalDecimal $row.qfu_budgetgoal
      qfu_percentachieved = Convert-OptionalDecimal $row.qfu_percentachieved
      qfu_lastupdated = Convert-OptionalDate $row.qfu_lastupdated
      qfu_cadsales = Convert-OptionalDecimal $row.qfu_cadsales
      qfu_usdsales = Convert-OptionalDecimal $row.qfu_usdsales
      qfu_month = Convert-OptionalInt $row.qfu_month
      qfu_monthname = (Convert-OptionalText $row.qfu_monthname)
      qfu_year = Convert-OptionalInt $row.qfu_year
      qfu_sourcefile = (Convert-OptionalText $row.qfu_sourcefile)
    }

    if ($result -eq "created") {
      $created += 1
    } else {
      $updated += 1
    }
  }

  return [pscustomobject]@{
    count = $rows.Count
    created = $created
    updated = $updated
  }
}

function Get-TargetRows {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$Fetch
  )

  return @((Get-CrmRecordsByFetch -conn $Connection -Fetch $Fetch).CrmRecords)
}

function Get-VerificationSummary {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [int]$GraceDaysValue
  )

  $quotesFetch = @"
<fetch version='1.0' mapping='logical' count='5000'>
  <entity name='qfu_quote'>
    <attribute name='qfu_quoteid' />
    <attribute name='qfu_quotenumber' />
    <attribute name='qfu_customername' />
    <attribute name='qfu_amount' />
    <attribute name='qfu_assignedto' />
    <attribute name='qfu_cssrname' />
    <attribute name='qfu_nextfollowup' />
    <attribute name='qfu_overduesince' />
    <attribute name='qfu_lasttouchedon' />
    <attribute name='qfu_priorityscore' />
    <attribute name='qfu_status' />
    <attribute name='qfu_sourcedate' />
    <order attribute='qfu_priorityscore' descending='true' />
    <order attribute='qfu_quotenumber' descending='false' />
  </entity>
</fetch>
"@
  $backordersFetch = @"
<fetch version='1.0' mapping='logical' count='5000'>
  <entity name='qfu_backorder'>
    <attribute name='qfu_backorderid' />
    <attribute name='qfu_customername' />
    <attribute name='qfu_totalvalue' />
    <attribute name='qfu_ontimedate' />
    <attribute name='qfu_cssrname' />
    <attribute name='qfu_daysoverdue' />
    <attribute name='qfu_salesdocnumber' />
    <attribute name='qfu_material' />
    <attribute name='qfu_description' />
    <attribute name='qfu_quantity' />
  </entity>
</fetch>
"@
  $budgetsFetch = @"
<fetch version='1.0' mapping='logical' count='500'>
  <entity name='qfu_budget'>
    <attribute name='qfu_budgetid' />
    <attribute name='qfu_budgetname' />
    <attribute name='qfu_actualsales' />
    <attribute name='qfu_budgetgoal' />
    <attribute name='qfu_percentachieved' />
    <attribute name='qfu_lastupdated' />
    <attribute name='qfu_cadsales' />
    <attribute name='qfu_usdsales' />
    <attribute name='qfu_month' />
    <attribute name='qfu_monthname' />
    <attribute name='qfu_year' />
    <order attribute='qfu_year' descending='true' />
    <order attribute='qfu_month' descending='true' />
  </entity>
</fetch>
"@

  $quotes = Get-TargetRows -Connection $Connection -Fetch $quotesFetch
  $backorders = Get-TargetRows -Connection $Connection -Fetch $backordersFetch
  $budgets = Get-TargetRows -Connection $Connection -Fetch $budgetsFetch

  $today = (Get-Date).Date
  $tomorrow = $today.AddDays(1)
  $graceCutoff = $today.AddDays(-1 * [Math]::Max(0, $GraceDaysValue - 1))
  $monthStart = Get-Date -Year $today.Year -Month $today.Month -Day 1
  $nextMonthStart = $monthStart.AddMonths(1)
  $last30Cutoff = $today.AddDays(-30)

  $openQuotes = @($quotes | Where-Object {
      $status = Convert-OptionalInt $_.qfu_status
      $status -notin @(2, 3, 4)
    })

  $dueToday = @($openQuotes | Where-Object {
      $next = Convert-OptionalDate $_.qfu_nextfollowup
      $next -and $next.Date -ge $today -and $next.Date -lt $tomorrow
    })
  $overdueQuotes = @($openQuotes | Where-Object {
      $next = Convert-OptionalDate $_.qfu_nextfollowup
      $next -and $next.Date -lt $today
    })
  $unscheduledOld = @($openQuotes | Where-Object {
      $next = Convert-OptionalDate $_.qfu_nextfollowup
      $sourceDate = Convert-OptionalDate $_.qfu_sourcedate
      (-not $next) -and $sourceDate -and $sourceDate.Date -lt $graceCutoff
    })
  $quotes30 = @($quotes | Where-Object {
      $sourceDate = Convert-OptionalDate $_.qfu_sourcedate
      $sourceDate -and $sourceDate -ge $last30Cutoff
    })

  $quotesWon = @($quotes30 | Where-Object { (Convert-OptionalInt $_.qfu_status) -eq 2 }).Count
  $quotesLost = @($quotes30 | Where-Object { (Convert-OptionalInt $_.qfu_status) -in @(3, 4) }).Count
  $quotesOpen30 = [Math]::Max(0, $quotes30.Count - $quotesWon - $quotesLost)
  $avgQuoteValue = if ($quotes30.Count -gt 0) {
    (($quotes30 | Measure-Object -Property qfu_amount -Sum).Sum / $quotes30.Count)
  } else {
    0
  }

  $currentMonthBackorders = @($backorders | Where-Object {
      $onTime = Convert-OptionalDate $_.qfu_ontimedate
      $onTime -and $onTime.Date -ge $monthStart -and $onTime.Date -lt $nextMonthStart
    })
  $currentMonthLate = @($currentMonthBackorders | Where-Object {
      $onTime = Convert-OptionalDate $_.qfu_ontimedate
      $days = Convert-OptionalInt $_.qfu_daysoverdue
      ($days -gt 0) -or ($onTime -and $onTime.Date -lt $today)
    })
  $allLateBackorders = @($backorders | Where-Object {
      $onTime = Convert-OptionalDate $_.qfu_ontimedate
      $days = Convert-OptionalInt $_.qfu_daysoverdue
      ($days -gt 0) -or ($onTime -and $onTime.Date -lt $today)
    })

  $latestBudget = $budgets | Sort-Object @{Expression = { Convert-OptionalInt $_.qfu_year }; Descending = $true }, @{Expression = { Convert-OptionalInt $_.qfu_month }; Descending = $true }, @{Expression = { Convert-OptionalDate $_.qfu_lastupdated }; Descending = $true } | Select-Object -First 1
  $openQuoteValue = (($openQuotes | Measure-Object -Property qfu_amount -Sum).Sum)

  return [ordered]@{
    synced_on = (Get-Date).ToString("o")
    quote_metrics = [ordered]@{
      total = $quotes.Count
      open = $openQuotes.Count
      due_today = $dueToday.Count
      overdue = $overdueQuotes.Count
      unscheduled_old = $unscheduledOld.Count
      open_value = if ($null -ne $openQuoteValue) { [decimal]$openQuoteValue } else { [decimal]0 }
      last_30_days_total = $quotes30.Count
      last_30_days_won = $quotesWon
      last_30_days_lost = $quotesLost
      last_30_days_open = $quotesOpen30
      last_30_days_avg_value = [decimal]$avgQuoteValue
    }
    backorder_metrics = [ordered]@{
      total = $backorders.Count
      current_month = $currentMonthBackorders.Count
      overdue_total = $allLateBackorders.Count
      current_month_forecast_value = [decimal](($currentMonthBackorders | Measure-Object -Property qfu_totalvalue -Sum).Sum)
      current_month_late_value = [decimal](($currentMonthLate | Measure-Object -Property qfu_totalvalue -Sum).Sum)
      all_backorders_value = [decimal](($backorders | Measure-Object -Property qfu_totalvalue -Sum).Sum)
      all_late_backorders_value = [decimal](($allLateBackorders | Measure-Object -Property qfu_totalvalue -Sum).Sum)
    }
    budget_latest = if ($latestBudget) {
      [ordered]@{
        name = $latestBudget.qfu_budgetname
        month = $latestBudget.qfu_month
        month_name = $latestBudget.qfu_monthname
        year = $latestBudget.qfu_year
        actual_sales = $latestBudget.qfu_actualsales
        budget_goal = $latestBudget.qfu_budgetgoal
        percent_achieved = $latestBudget.qfu_percentachieved
        last_updated = if ($latestBudget.qfu_lastupdated) { ([datetime]$latestBudget.qfu_lastupdated).ToString("o") } else { $null }
        cad_sales = $latestBudget.qfu_cadsales
        usd_sales = $latestBudget.qfu_usdsales
      }
    } else {
      $null
    }
    samples = [ordered]@{
      quotes = @($openQuotes | Select-Object -First 10 | ForEach-Object {
          [ordered]@{
            qfu_quotenumber = $_.qfu_quotenumber
            qfu_customername = $_.qfu_customername
            qfu_amount = $_.qfu_amount
            qfu_assignedto = $_.qfu_assignedto
            qfu_cssrname = $_.qfu_cssrname
            qfu_nextfollowup = if ($_.qfu_nextfollowup) { ([datetime]$_.qfu_nextfollowup).ToString("o") } else { $null }
            qfu_overduesince = if ($_.qfu_overduesince) { ([datetime]$_.qfu_overduesince).ToString("o") } else { $null }
            qfu_lasttouchedon = if ($_.qfu_lasttouchedon) { ([datetime]$_.qfu_lasttouchedon).ToString("o") } else { $null }
            qfu_priorityscore = $_.qfu_priorityscore
            qfu_status = $_.qfu_status
            qfu_sourcedate = if ($_.qfu_sourcedate) { ([datetime]$_.qfu_sourcedate).ToString("o") } else { $null }
          }
        })
      backorders = @($allLateBackorders | Sort-Object @{Expression = { Convert-OptionalInt $_.qfu_daysoverdue }; Descending = $true } | Select-Object -First 10 | ForEach-Object {
          [ordered]@{
            qfu_customername = $_.qfu_customername
            qfu_salesdocnumber = $_.qfu_salesdocnumber
            qfu_material = $_.qfu_material
            qfu_description = $_.qfu_description
            qfu_totalvalue = $_.qfu_totalvalue
            qfu_cssrname = $_.qfu_cssrname
            qfu_daysoverdue = $_.qfu_daysoverdue
            qfu_ontimedate = if ($_.qfu_ontimedate) { ([datetime]$_.qfu_ontimedate).ToString("o") } else { $null }
          }
        })
    }
  }
}

$source = Connect-Org -Url $SourceEnvironmentUrl
$target = Connect-Org -Url $TargetEnvironmentUrl

Write-Host "Connected source: $($source.ConnectedOrgFriendlyName)"
Write-Host "Connected target: $($target.ConnectedOrgFriendlyName)"

Ensure-MinimalSchema -Connection $target

$quoteSync = Sync-Quotes -SourceConnection $source -TargetConnection $target
$backorderSync = Sync-Backorders -SourceConnection $source -TargetConnection $target
$budgetSync = Sync-Budgets -SourceConnection $source -TargetConnection $target
$summary = Get-VerificationSummary -Connection $target -GraceDaysValue $GraceDays

$result = [ordered]@{
  source_environment = $SourceEnvironmentUrl
  target_environment = $TargetEnvironmentUrl
  sync = [ordered]@{
    quotes = $quoteSync
    backorders = $backorderSync
    budgets = $budgetSync
  }
  verification = $summary
}

Write-Utf8Json -Path $OutputJson -Object $result
Write-Output ($result | ConvertTo-Json -Depth 10)
