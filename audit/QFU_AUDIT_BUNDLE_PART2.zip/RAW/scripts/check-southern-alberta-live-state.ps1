param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com",
  [string]$OutputPath = ""
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell

$branchCodes = @("4171", "4172", "4173")

function Get-TargetConnection {
  param(
    [string]$Url,
    [string]$User
  )

  $conn = Connect-CrmOnline -ServerUrl $Url -ForceOAuth -Username $User
  if (-not $conn -or -not $conn.IsReady) {
    throw "Dataverse connection failed for $Url : $($conn.LastCrmError)"
  }

  return $conn
}

function Get-RecordsByBranch {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$BranchCode,
    [string[]]$Fields
  )

  return @((Get-CrmRecords -conn $Connection -EntityLogicalName $EntityLogicalName -FilterAttribute "qfu_branchcode" -FilterOperator eq -FilterValue $BranchCode -Fields $Fields -TopCount 5000).CrmRecords)
}

function Get-DuplicateSummary {
  param(
    [object[]]$Records,
    [string]$FieldName
  )

  $values = @(
    $Records |
      ForEach-Object { $_.$FieldName } |
      Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) }
  )

  $groups = @($values | Group-Object | Where-Object { $_.Count -gt 1 } | Sort-Object Count -Descending)

  return [pscustomobject]@{
    duplicate_group_count = $groups.Count
    duplicate_row_count = @($groups | Measure-Object -Property Count -Sum).Sum
    top_duplicates = @(
      $groups |
        Select-Object -First 10 |
        ForEach-Object {
          [pscustomobject]@{
            value = $_.Name
            count = $_.Count
          }
        }
    )
  }
}

function New-BranchSummary {
  param(
    [string]$BranchCode,
    [object[]]$Quotes,
    [object[]]$QuoteLines,
    [object[]]$Backorders,
    [object[]]$Budgets,
    [object[]]$Summaries
  )

  return [pscustomobject]@{
    branch_code = $BranchCode
    counts = [pscustomobject]@{
      qfu_quote = @($Quotes).Count
      qfu_quoteline = @($QuoteLines).Count
      qfu_backorder = @($Backorders).Count
      qfu_budget = @($Budgets).Count
      qfu_branchdailysummary = @($Summaries).Count
    }
    duplicates = [pscustomobject]@{
      qfu_quote_sourceid = Get-DuplicateSummary -Records $Quotes -FieldName "qfu_sourceid"
      qfu_quoteline_uniquekey = Get-DuplicateSummary -Records $QuoteLines -FieldName "qfu_uniquekey"
      qfu_backorder_sourceid = Get-DuplicateSummary -Records $Backorders -FieldName "qfu_sourceid"
      qfu_budget_sourceid = Get-DuplicateSummary -Records $Budgets -FieldName "qfu_sourceid"
    }
    recent = [pscustomobject]@{
      quotes = @($Quotes | Sort-Object createdon -Descending | Select-Object -First 5 qfu_sourceid, qfu_quotenumber, createdon)
      quote_lines = @($QuoteLines | Sort-Object createdon -Descending | Select-Object -First 5 qfu_uniquekey, qfu_quotenumber, qfu_linenumber, createdon)
      backorders = @($Backorders | Sort-Object createdon -Descending | Select-Object -First 5 qfu_sourceid, qfu_salesdocnumber, createdon)
      budgets = @($Budgets | Sort-Object createdon -Descending | Select-Object -First 3 qfu_sourceid, qfu_budgetname, createdon)
    }
  }
}

$connection = Get-TargetConnection -Url $TargetEnvironmentUrl -User $Username

$branchSummaries = @()
foreach ($branchCode in $branchCodes) {
  $quotes = Get-RecordsByBranch -Connection $connection -EntityLogicalName "qfu_quote" -BranchCode $branchCode -Fields @("qfu_sourceid", "qfu_quotenumber", "createdon")
  $quoteLines = Get-RecordsByBranch -Connection $connection -EntityLogicalName "qfu_quoteline" -BranchCode $branchCode -Fields @("qfu_uniquekey", "qfu_quotenumber", "qfu_linenumber", "createdon")
  $backorders = Get-RecordsByBranch -Connection $connection -EntityLogicalName "qfu_backorder" -BranchCode $branchCode -Fields @("qfu_sourceid", "qfu_salesdocnumber", "createdon")
  $budgets = Get-RecordsByBranch -Connection $connection -EntityLogicalName "qfu_budget" -BranchCode $branchCode -Fields @("qfu_sourceid", "qfu_budgetname", "createdon")
  $summaries = Get-RecordsByBranch -Connection $connection -EntityLogicalName "qfu_branchdailysummary" -BranchCode $branchCode -Fields @("qfu_sourceid", "createdon")

  $branchSummaries += New-BranchSummary -BranchCode $branchCode -Quotes $quotes -QuoteLines $quoteLines -Backorders $backorders -Budgets $budgets -Summaries $summaries
}

$report = [pscustomobject]@{
  captured_at = (Get-Date).ToUniversalTime().ToString("o")
  environment_url = $TargetEnvironmentUrl
  branch_codes = $branchCodes
  branches = $branchSummaries
}

if ([string]::IsNullOrWhiteSpace($OutputPath)) {
  $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
  $OutputPath = Join-Path (Join-Path (Get-Location) "results") "southern-alberta-live-state-$stamp.json"
}

$directory = Split-Path -Parent $OutputPath
if ($directory -and -not (Test-Path -LiteralPath $directory)) {
  New-Item -ItemType Directory -Path $directory -Force | Out-Null
}

$json = $report | ConvertTo-Json -Depth 20
[System.IO.File]::WriteAllText($OutputPath, $json, (New-Object System.Text.UTF8Encoding($false)))

$report.branches | Select-Object branch_code,
  @{ Name = "quotes"; Expression = { $_.counts.qfu_quote } },
  @{ Name = "quote_lines"; Expression = { $_.counts.qfu_quoteline } },
  @{ Name = "backorders"; Expression = { $_.counts.qfu_backorder } },
  @{ Name = "budgets"; Expression = { $_.counts.qfu_budget } },
  @{ Name = "dup_quote_sourceid"; Expression = { $_.duplicates.qfu_quote_sourceid.duplicate_group_count } },
  @{ Name = "dup_line_uniquekey"; Expression = { $_.duplicates.qfu_quoteline_uniquekey.duplicate_group_count } },
  @{ Name = "dup_backorder_sourceid"; Expression = { $_.duplicates.qfu_backorder_sourceid.duplicate_group_count } } |
  Format-Table -AutoSize

Write-Host "OUTPUT_PATH=$OutputPath"
