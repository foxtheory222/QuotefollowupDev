param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com"
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Add-Type -AssemblyName "Microsoft.Xrm.Sdk"

$conn = Connect-CrmOnline -ServerUrl $TargetEnvironmentUrl -ForceOAuth -Username $Username
if (-not $conn -or -not $conn.IsReady) {
  throw "Dataverse connection failed for $TargetEnvironmentUrl : $($conn.LastCrmError)"
}

function Get-FetchResult {
  param([string]$Fetch)
  return (Get-CrmRecordsByFetch -conn $conn -Fetch $Fetch).CrmRecords
}

$entityPermissions = Get-FetchResult @"
<fetch>
  <entity name='mspp_entitypermission'>
    <all-attributes />
  </entity>
</fetch>
"@

$rolePermissionLinks = Get-FetchResult @"
<fetch>
  <entity name='mspp_entitypermission'>
    <all-attributes />
    <link-entity name='mspp_entitypermission_webrole' from='mspp_entitypermissionid' to='mspp_entitypermissionid' alias='link' intersect='true'>
      <attribute name='mspp_webroleid' />
    </link-entity>
  </entity>
</fetch>
"@

$contactRoleLinks = Get-FetchResult @"
<fetch>
  <entity name='powerpagecomponent_mspp_webrole_contact'>
    <attribute name='powerpagecomponent_mspp_webrole_contactid' />
    <attribute name='contactid' />
    <attribute name='powerpagecomponentid' />
  </entity>
</fetch>
"@

$permissionRoleLinksRaw = Get-FetchResult @"
<fetch>
  <entity name='mspp_entitypermission_webrole'>
    <all-attributes />
  </entity>
</fetch>
"@

$contacts = Get-FetchResult @"
<fetch>
  <entity name='contact'>
    <attribute name='contactid' />
    <attribute name='fullname' />
    <attribute name='emailaddress1' />
    <attribute name='adx_identity_username' />
  </entity>
</fetch>
"@

$payload = [ordered]@{
  entityPermissions = $entityPermissions |
    Where-Object { $_.adx_entitylogicalname -like 'qfu_*' -or $_.mspp_entitylogicalname -like 'qfu_*' } |
    Select-Object mspp_entitypermissionid, adx_entityname, adx_entitylogicalname, adx_scope, adx_read, adx_write, adx_create, adx_append, adx_appendto, adx_delete, mspp_entitylogicalname, mspp_scope, mspp_read, mspp_write, mspp_create, mspp_append, mspp_appendto, mspp_delete
  rolePermissionLinks = $rolePermissionLinks |
    Where-Object { $_.adx_entitylogicalname -like 'qfu_*' -or $_.mspp_entitylogicalname -like 'qfu_*' } |
    Select-Object mspp_entitypermissionid, adx_entityname, adx_entitylogicalname, mspp_entitylogicalname, 'link.mspp_webroleid'
  permissionRoleLinksRaw = $permissionRoleLinksRaw
  contactRoleLinks = $contactRoleLinks | Select-Object powerpagecomponent_mspp_webrole_contactid, contactid, powerpagecomponentid
  contacts = $contacts | Select-Object contactid, fullname, emailaddress1, adx_identity_username
}

$payload | ConvertTo-Json -Depth 8
