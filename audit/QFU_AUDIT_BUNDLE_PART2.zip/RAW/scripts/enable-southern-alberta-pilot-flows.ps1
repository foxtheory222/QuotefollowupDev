param(
  [string]$EnvironmentName = "9f2e54c6-c349-e7e1-ac7c-010d3adf3c03",
  [string]$Username = "smcfarlane@applied.com"
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.PowerApps.Administration.PowerShell

$targetFlows = @(
  [pscustomobject]@{ DisplayName = "4171-QuoteFollowUp-Import-Staging"; WorkflowEntityId = "0aff92f1-a8f0-45d7-b05c-3afe5ade9ed1" },
  [pscustomobject]@{ DisplayName = "4171-BackOrder-Update-ZBO"; WorkflowEntityId = "94ae1bae-fe22-455e-bf63-24ba92644dc0" },
  [pscustomobject]@{ DisplayName = "4171-Budget-Update-SA1300"; WorkflowEntityId = "6db19ff3-c313-4db6-9a57-f3335fe55558" },
  [pscustomobject]@{ DisplayName = "4172-QuoteFollowUp-Import-Staging"; WorkflowEntityId = "3520a9d9-f40d-430b-aec8-56b9f4c5d96c" },
  [pscustomobject]@{ DisplayName = "4172-BackOrder-Update-ZBO"; WorkflowEntityId = "a5a911cc-1d2d-4e5a-b0ab-da6f52def8b0" },
  [pscustomobject]@{ DisplayName = "4172-Budget-Update-SA1300"; WorkflowEntityId = "078cea4c-84f6-4c4f-b73b-62ad838f7cae" },
  [pscustomobject]@{ DisplayName = "4173-QuoteFollowUp-Import-Staging"; WorkflowEntityId = "490e1685-4623-461e-ba1c-6c0907a60e33" },
  [pscustomobject]@{ DisplayName = "4173-BackOrder-Update-ZBO"; WorkflowEntityId = "3277dd8e-14f6-4e7b-b627-ebc923ba86ef" },
  [pscustomobject]@{ DisplayName = "4173-Budget-Update-SA1300"; WorkflowEntityId = "3c2ebd80-35d9-4e3c-bdbe-70be98a82ae6" }
)

Add-PowerAppsAccount -Endpoint prod -Username $Username | Out-Null

$flows = @(Get-AdminFlow -EnvironmentName $EnvironmentName)
$resolvedFlows = @(
  foreach ($target in $targetFlows) {
    $match = $flows | Where-Object { $_.WorkflowEntityId -eq $target.WorkflowEntityId } | Select-Object -First 1
    if (-not $match) {
      throw "Canonical flow missing: $($target.DisplayName) [$($target.WorkflowEntityId)]"
    }
    $match
  }
)

foreach ($flow in $resolvedFlows) {
  if (-not $flow.Enabled) {
    Enable-AdminFlow -EnvironmentName $EnvironmentName -FlowName $flow.FlowName | Out-Null
  }
}

$canonicalIds = @($targetFlows.WorkflowEntityId)
$refreshed = @(Get-AdminFlow -EnvironmentName $EnvironmentName | Where-Object { $_.WorkflowEntityId -in $canonicalIds } | Sort-Object DisplayName)
$refreshed | Select-Object DisplayName, Enabled, FlowName, LastModifiedTime | Format-Table -AutoSize
