param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$ParsedDashboardJson = "results\dashboard-spine.json",
  [string]$ParserScriptPath = "scripts\parse-southern-alberta-dashboard-spine.py",
  [string]$Sa1300Root = "Latest",
  [string]$Gl060Root = "DATA\GL060",
  [string]$OutputJson = "results\southern-alberta-dashboard-spine-sync.json"
)

$ErrorActionPreference = "Stop"

. (Join-Path $RepoRoot "scripts\deploy-southern-alberta-pilot.ps1")

function Ensure-ParsedDashboardData {
  param(
    [string]$JsonPath,
    [string]$ParserPath,
    [string]$Sa1300RootPath,
    [string]$Gl060RootPath
  )

  $python = Get-Command python -ErrorAction SilentlyContinue
  if (-not $python) {
    throw "python is required to generate $JsonPath"
  }

  Ensure-Directory (Split-Path -Parent $JsonPath)
  $arguments = @($ParserPath, "--example-root", "example")
  if ($Sa1300RootPath) {
    $arguments += @("--sa1300-root", $Sa1300RootPath)
  }
  if ($Gl060RootPath) {
    $arguments += @("--gl060-root", $Gl060RootPath)
  }
  $arguments += @("--output", $JsonPath)
  & $python.Source @arguments
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $JsonPath)) {
    throw "Failed to generate parsed dashboard JSON: $JsonPath"
  }
}

function Get-ParsedDashboardData {
  param([string]$JsonPath)
  return (Get-Content -LiteralPath $JsonPath -Raw | ConvertFrom-Json)
}

function Ensure-SignedDecimalRange {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$SchemaName,
    [int]$Precision = 2
  )

  $request = [Microsoft.Xrm.Sdk.Messages.RetrieveAttributeRequest]::new()
  $request.EntityLogicalName = $EntityLogicalName
  $request.LogicalName = $SchemaName
  $request.RetrieveAsIfPublished = $true
  $response = $Connection.Execute($request)
  $attribute = [Microsoft.Xrm.Sdk.Metadata.DecimalAttributeMetadata]$response.AttributeMetadata
  if ($null -eq $attribute) {
    return
  }

  $needsUpdate = ($attribute.MinValue -gt -1000000000) -or ($attribute.MaxValue -lt 1000000000) -or ($attribute.Precision -ne $Precision)
  if (-not $needsUpdate) {
    return
  }

  $attribute.MinValue = -1000000000
  $attribute.MaxValue = 1000000000
  $attribute.Precision = $Precision

  $update = [Microsoft.Xrm.Sdk.Messages.UpdateAttributeRequest]::new()
  $update.EntityName = $EntityLogicalName
  $update.Attribute = $attribute
  if ($SolutionUniqueName) {
    $update.SolutionUniqueName = $SolutionUniqueName
  }

  $Connection.Execute($update) | Out-Null
  Write-Host "Updated decimal range: $EntityLogicalName.$SchemaName"
}

function Ensure-DashboardSchema {
  param([Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection)

  Ensure-Entity -Connection $Connection -SchemaName "qfu_financesnapshot" -DisplayName "QFU Finance Snapshot" -DisplayCollectionName "QFU Finance Snapshots" -Description "Closed-month GL060 finance snapshot rows for the regional dashboard." -PrimaryNameSchema "qfu_name" -PrimaryNameDisplay "Name"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_sourceid" -DisplayName "Source Id" -MaxLength 200
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_branchcode" -DisplayName "Branch Code" -MaxLength 10
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_branchslug" -DisplayName "Branch Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_regionslug" -DisplayName "Region Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_sourcefamily" -DisplayName "Source Family" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_sourcefile" -DisplayName "Source File" -MaxLength 250
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_monthlabel" -DisplayName "Month Label" -MaxLength 50
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_month" -DisplayName "Month" -MinValue 1 -MaxValue 12
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_year" -DisplayName "Year" -MinValue 2000 -MaxValue 2100
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName "qfu_lastupdated" -DisplayName "Last Updated"
  foreach ($field in @(
      "qfu_currentmonthsalesactual","qfu_currentmonthsalesplan",
      "qfu_currentmonthgrossprofitactual","qfu_currentmonthgrossprofitplan",
      "qfu_currentmonthgrossprofitpctactual","qfu_currentmonthgrossprofitpctplan",
      "qfu_currentmonthopexpctactual","qfu_currentmonthopexpctplan",
      "qfu_currentmonthgapactual","qfu_currentmonthgapplan",
      "qfu_currentmonthoperatingprofitactual","qfu_currentmonthoperatingprofitplan",
      "qfu_ytdsalesactual","qfu_ytdsalesplan",
      "qfu_ytdgrossprofitactual","qfu_ytdgrossprofitplan",
      "qfu_ytdoperatingprofitactual","qfu_ytdoperatingprofitplan"
    )) {
    Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName $field -DisplayName ($field -replace "^qfu_", "" -replace "([a-z])([A-Z])", '$1 $2') -Precision 4
    Ensure-SignedDecimalRange -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -SchemaName $field -Precision 4
  }

  Ensure-Entity -Connection $Connection -SchemaName "qfu_financevariance" -DisplayName "QFU Finance Variance" -DisplayCollectionName "QFU Finance Variances" -Description "Closed-month GL060 variance rows used by the branch variance module." -PrimaryNameSchema "qfu_name" -PrimaryNameDisplay "Name"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_sourceid" -DisplayName "Source Id" -MaxLength 250
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_branchcode" -DisplayName "Branch Code" -MaxLength 10
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_branchslug" -DisplayName "Branch Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_regionslug" -DisplayName "Region Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_sourcefamily" -DisplayName "Source Family" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_sourcefile" -DisplayName "Source File" -MaxLength 250
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_monthlabel" -DisplayName "Month Label" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_variancelabel" -DisplayName "Variance Label" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_varianceslug" -DisplayName "Variance Slug" -MaxLength 100
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_month" -DisplayName "Month" -MinValue 1 -MaxValue 12
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_year" -DisplayName "Year" -MinValue 2000 -MaxValue 2100
  Ensure-IntegerAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_sortorder" -DisplayName "Sort Order" -MinValue 0
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName "qfu_lastupdated" -DisplayName "Last Updated"
  foreach ($field in @("qfu_currentmonthactual","qfu_currentmonthplan","qfu_currentmonthvariance","qfu_ytdactual","qfu_ytdplan","qfu_ytdvariance")) {
    Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName $field -DisplayName ($field -replace "^qfu_", "" -replace "([a-z])([A-Z])", '$1 $2') -Precision 2
    Ensure-SignedDecimalRange -Connection $Connection -EntityLogicalName "qfu_financevariance" -SchemaName $field -Precision 2
  }

  Ensure-Entity -Connection $Connection -SchemaName "qfu_marginexception" -DisplayName "QFU Margin Exception" -DisplayCollectionName "QFU Margin Exceptions" -Description "Daily SA1300 abnormal margin snapshot rows." -PrimaryNameSchema "qfu_name" -PrimaryNameDisplay "Name"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_sourceid" -DisplayName "Source Id" -MaxLength 250
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_branchcode" -DisplayName "Branch Code" -MaxLength 10
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_branchslug" -DisplayName "Branch Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_regionslug" -DisplayName "Region Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_sourcefamily" -DisplayName "Source Family" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_sourcefile" -DisplayName "Source File" -MaxLength 250
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_snapshotdate" -DisplayName "Snapshot Date" -Format ([Microsoft.Xrm.Sdk.Metadata.DateTimeFormat]::DateOnly)
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_billingdate" -DisplayName "Billing Date" -Format ([Microsoft.Xrm.Sdk.Metadata.DateTimeFormat]::DateOnly)
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_reviewtype" -DisplayName "Review Type" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_currencytype" -DisplayName "Currency Type" -MaxLength 20
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_cssr" -DisplayName "CSSR" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_cssrname" -DisplayName "CSSR Name" -MaxLength 150
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_customername" -DisplayName "Customer Name" -MaxLength 200
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_billingdocumentnumber" -DisplayName "Billing Document Number" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_billingdocumenttype" -DisplayName "Billing Document Type" -MaxLength 20
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_sales" -DisplayName "Sales" -Precision 2
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_cogs" -DisplayName "COGS" -Precision 2
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName "qfu_gp" -DisplayName "GP" -Precision 2
  foreach ($field in @("qfu_sales","qfu_cogs","qfu_gp")) {
    Ensure-SignedDecimalRange -Connection $Connection -EntityLogicalName "qfu_marginexception" -SchemaName $field -Precision 2
  }

  Ensure-Entity -Connection $Connection -SchemaName "qfu_lateorderexception" -DisplayName "QFU Late Order Exception" -DisplayCollectionName "QFU Late Order Exceptions" -Description "Daily SA1300 late order snapshot rows." -PrimaryNameSchema "qfu_name" -PrimaryNameDisplay "Name"
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_sourceid" -DisplayName "Source Id" -MaxLength 250
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_branchcode" -DisplayName "Branch Code" -MaxLength 10
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_branchslug" -DisplayName "Branch Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_regionslug" -DisplayName "Region Slug" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_sourcefamily" -DisplayName "Source Family" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_sourcefile" -DisplayName "Source File" -MaxLength 250
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_snapshotdate" -DisplayName "Snapshot Date" -Format ([Microsoft.Xrm.Sdk.Metadata.DateTimeFormat]::DateOnly)
  Ensure-DateTimeAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_billingdate" -DisplayName "Billing Date" -Format ([Microsoft.Xrm.Sdk.Metadata.DateTimeFormat]::DateOnly)
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_cssr" -DisplayName "CSSR" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_cssrname" -DisplayName "CSSR Name" -MaxLength 150
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_soldtocustomername" -DisplayName "Sold-To Customer Name" -MaxLength 200
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_shiptocustomername" -DisplayName "Ship-To Customer Name" -MaxLength 200
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_billingdocumentnumber" -DisplayName "Billing Document Number" -MaxLength 50
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_materialgroup" -DisplayName "Material Group" -MaxLength 100
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_itemcategory" -DisplayName "Item Category" -MaxLength 20
  Ensure-StringAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_itemcategorydescription" -DisplayName "Item Category Description" -MaxLength 100
  Ensure-DecimalAttribute -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_sales" -DisplayName "Sales" -Precision 2
  Ensure-SignedDecimalRange -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -SchemaName "qfu_sales" -Precision 2
}

function Get-DashboardSeedPayload {
  param([object]$ParsedData)

  $snapshots = @()
  $variances = @()
  $marginRows = @()
  $lateRows = @()
  $batches = @()
  $sourceFeeds = @()

  foreach ($branchData in @($ParsedData.branches)) {
    $branch = $branchData.branch
    $snapshots += @($branchData.finance.record)
    $variances += @($branchData.finance.variances)
    $marginRows += @($branchData.abnormal_margin.records)
    $lateRows += @($branchData.late_orders.records)
    $batches += @($branchData.batches)
    $sourceFeeds += [pscustomobject]@{
      qfu_name = "$($branch.branch_code) GL060 Feed"
      qfu_sourceid = "$($branch.branch_code)|feed|GL060"
      qfu_branchcode = $branch.branch_code
      qfu_branchslug = $branch.branch_slug
      qfu_regionslug = $branch.region_slug
      qfu_sourcefamily = "GL060"
      qfu_mailboxaddress = $branch.mailbox_address
      qfu_folderid = "Inbox"
      qfu_subjectfilter = $null
      qfu_filenamepattern = "GL060 Report - Profit Center*.pdf"
      qfu_enabled = $true
    }
  }

  return [ordered]@{
    qfu_financesnapshot = $snapshots
    qfu_financevariance = $variances
    qfu_marginexception = $marginRows
    qfu_lateorderexception = $lateRows
    qfu_ingestionbatch = $batches
    qfu_sourcefeed = $sourceFeeds
  }
}

function Remove-SeedRowsBySourceFamilies {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string[]]$BranchCodes,
    [string[]]$SourceFamilies
  )

  $idFieldName = "${EntityLogicalName}id"
  $deleted = 0

  foreach ($sourceFamily in $SourceFamilies) {
    $rows = @((Get-CrmRecords -conn $Connection -EntityLogicalName $EntityLogicalName -FilterAttribute "qfu_sourcefamily" -FilterOperator eq -FilterValue $sourceFamily -Fields @($idFieldName, "qfu_branchcode") -TopCount 5000).CrmRecords)
    foreach ($row in @($rows | Where-Object { $_.qfu_branchcode -in $BranchCodes })) {
      $recordId = $row.$idFieldName
      if ($recordId) {
        $Connection.Delete($EntityLogicalName, [guid]$recordId)
        $deleted += 1
      }
    }
  }

  return $deleted
}

function Upsert-SourceFeeds {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object[]]$Records
  )

  $result = [ordered]@{
    created = 0
    updated = 0
  }

  foreach ($record in @($Records)) {
    $fields = Convert-RecordToFields -EntityLogicalName "qfu_sourcefeed" -Record $record
    $existing = @(Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_sourcefeed" -FilterAttribute "qfu_sourceid" -FilterOperator eq -FilterValue $record.qfu_sourceid -Fields @("qfu_sourcefeedid") -TopCount 1).CrmRecords | Select-Object -First 1
    if ($existing) {
      Set-CrmRecord -conn $Connection -EntityLogicalName "qfu_sourcefeed" -Id $existing.qfu_sourcefeedid -Fields $fields | Out-Null
      $result.updated += 1
    } else {
      New-CrmRecord -conn $Connection -EntityLogicalName "qfu_sourcefeed" -Fields $fields | Out-Null
      $result.created += 1
    }
  }

  return $result
}

function Get-DashboardVerificationSummary {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$ParsedData
  )

  $branchCodes = @($ParsedData.branches | ForEach-Object { $_.branch.branch_code })
  return [ordered]@{
    verified_on = (Get-Date).ToString("o")
    expected = [ordered]@{
      qfu_financesnapshot = @($ParsedData.branches).Count
      qfu_financevariance = @($ParsedData.branches | ForEach-Object { @($_.finance.variances).Count } | Measure-Object -Sum).Sum
      qfu_marginexception = @($ParsedData.branches | ForEach-Object { @($_.abnormal_margin.records).Count } | Measure-Object -Sum).Sum
      qfu_lateorderexception = @($ParsedData.branches | ForEach-Object { @($_.late_orders.records).Count } | Measure-Object -Sum).Sum
    }
    target_counts = [ordered]@{
      qfu_financesnapshot = Get-EntityCountsByBranch -Connection $Connection -EntityLogicalName "qfu_financesnapshot" -BranchCodes $branchCodes
      qfu_financevariance = Get-EntityCountsByBranch -Connection $Connection -EntityLogicalName "qfu_financevariance" -BranchCodes $branchCodes
      qfu_marginexception = Get-EntityCountsByBranch -Connection $Connection -EntityLogicalName "qfu_marginexception" -BranchCodes $branchCodes
      qfu_lateorderexception = Get-EntityCountsByBranch -Connection $Connection -EntityLogicalName "qfu_lateorderexception" -BranchCodes $branchCodes
    }
  }
}

$dashboardJsonPath = Join-Path $RepoRoot $ParsedDashboardJson
$parserFullPath = Join-Path $RepoRoot $ParserScriptPath
$sa1300RootFullPath = if ($Sa1300Root) { Join-Path $RepoRoot $Sa1300Root } else { $null }
$gl060RootFullPath = if ($Gl060Root) { Join-Path $RepoRoot $Gl060Root } else { $null }
$outputFullPath = Join-Path $RepoRoot $OutputJson

Ensure-ParsedDashboardData -JsonPath $dashboardJsonPath -ParserPath $parserFullPath -Sa1300RootPath $sa1300RootFullPath -Gl060RootPath $gl060RootFullPath
$parsedData = Get-ParsedDashboardData -JsonPath $dashboardJsonPath
$branchCodes = @($parsedData.branches | ForEach-Object { $_.branch.branch_code })
$seedPayload = Get-DashboardSeedPayload -ParsedData $parsedData

$target = Connect-Org -Url $TargetEnvironmentUrl
Write-Host "Connected target: $($target.ConnectedOrgFriendlyName)"

Ensure-DashboardSchema -Connection $target

$deletedCounts = [ordered]@{
  qfu_financevariance = Remove-SeedRowsForBranches -Connection $target -EntityLogicalName "qfu_financevariance" -BranchCodes $branchCodes
  qfu_financesnapshot = Remove-SeedRowsForBranches -Connection $target -EntityLogicalName "qfu_financesnapshot" -BranchCodes $branchCodes
  qfu_marginexception = Remove-SeedRowsForBranches -Connection $target -EntityLogicalName "qfu_marginexception" -BranchCodes $branchCodes
  qfu_lateorderexception = Remove-SeedRowsForBranches -Connection $target -EntityLogicalName "qfu_lateorderexception" -BranchCodes $branchCodes
  qfu_ingestionbatch = Remove-SeedRowsBySourceFamilies -Connection $target -EntityLogicalName "qfu_ingestionbatch" -BranchCodes $branchCodes -SourceFamilies @("GL060", "SA1300-ABNORMALMARGIN", "SA1300-LATEORDER")
}

$insertedCounts = [ordered]@{
  qfu_financesnapshot = Import-SeedRecords -Connection $target -EntityLogicalName "qfu_financesnapshot" -Records @($seedPayload.qfu_financesnapshot)
  qfu_financevariance = Import-SeedRecords -Connection $target -EntityLogicalName "qfu_financevariance" -Records @($seedPayload.qfu_financevariance)
  qfu_marginexception = Import-SeedRecords -Connection $target -EntityLogicalName "qfu_marginexception" -Records @($seedPayload.qfu_marginexception)
  qfu_lateorderexception = Import-SeedRecords -Connection $target -EntityLogicalName "qfu_lateorderexception" -Records @($seedPayload.qfu_lateorderexception)
  qfu_ingestionbatch = Import-SeedRecords -Connection $target -EntityLogicalName "qfu_ingestionbatch" -Records @($seedPayload.qfu_ingestionbatch)
}
$sourceFeedResult = Upsert-SourceFeeds -Connection $target -Records @($seedPayload.qfu_sourcefeed)

$result = [ordered]@{
  target_environment = $TargetEnvironmentUrl
  parsed_dashboard_json = $dashboardJsonPath
  deleted = $deletedCounts
  inserted = $insertedCounts
  sourcefeed = $sourceFeedResult
  verification = Get-DashboardVerificationSummary -Connection $target -ParsedData $parsedData
}

Write-Utf8Json -Path $outputFullPath -Object $result
Write-Output ($result | ConvertTo-Json -Depth 10)
