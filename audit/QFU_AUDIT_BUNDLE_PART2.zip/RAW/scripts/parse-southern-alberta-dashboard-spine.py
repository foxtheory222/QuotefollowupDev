#!/usr/bin/env python3

import argparse
import json
import re
from datetime import date, datetime
from pathlib import Path

import pdfplumber
from openpyxl import load_workbook


BRANCHES = {
    "4171": {
        "branch_code": "4171",
        "branch_slug": "4171-calgary",
        "branch_name": "Calgary",
        "region_slug": "southern-alberta",
        "region_name": "Southern Alberta",
        "mailbox_address": "4171@applied.com",
        "sort_order": 10,
    },
    "4172": {
        "branch_code": "4172",
        "branch_slug": "4172-lethbridge",
        "branch_name": "Lethbridge",
        "region_slug": "southern-alberta",
        "region_name": "Southern Alberta",
        "mailbox_address": "4172@applied.com",
        "sort_order": 20,
    },
    "4173": {
        "branch_code": "4173",
        "branch_slug": "4173-medicine-hat",
        "branch_name": "Medicine Hat",
        "region_slug": "southern-alberta",
        "region_name": "Southern Alberta",
        "mailbox_address": "4173@applied.com",
        "sort_order": 30,
    },
}

FINANCE_METRICS = {
    "Service Center Sales": "sales",
    "Service Center Gross Profit": "grossprofit",
    "Service Center Gross Profit %": "grossprofitpct",
    "Service Center Operating Expense %": "opexpct",
    "Service Center GAP": "gap",
    "OPERATING PROFIT": "operatingprofit",
}

VARIANCE_LABELS = {
    "Compensation & Benefits": "compensation-benefits",
    "Occupancy Expenses": "occupancy-expenses",
    "Shop Expenses": "shop-expenses",
    "Selling Expense": "selling-expense",
    "Administrative Expense": "administrative-expense",
    "Office Expense": "office-expense",
    "Other SD&A (Income)/ Expense": "other-sda-expense",
}

TOKEN_PATTERN = re.compile(r"\(?\$?-?[0-9,]+(?:\.\d+)?%?\)?|#DIV/0")
WHITESPACE_PATTERN = re.compile(r"\s+")
MONTH_LABEL_PATTERN = re.compile(r"For the Month of ([A-Za-z]+ \d{4})")


def as_text(value):
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.startswith("#"):
        return None
    return text


def slugify(text):
    return re.sub(r"[^a-z0-9]+", "-", (text or "").strip().lower()).strip("-")


def as_float(value):
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text or text.startswith("#") or text == "#DIV/0":
        return 0.0
    negative = text.startswith("(") and text.endswith(")")
    cleaned = text.replace("$", "").replace(",", "").replace("%", "").replace("(", "").replace(")", "")
    if not cleaned:
        return 0.0
    try:
        number = float(cleaned)
        return -number if negative else number
    except ValueError:
        return 0.0


def as_date(value):
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = as_text(value)
    if text is None:
        return None
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y/%m/%d", "%d-%b-%Y"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            continue
    return None


def iso_date(value):
    if value is None:
        return None
    return value.isoformat()


def normalize_line(value):
    return WHITESPACE_PATTERN.sub(" ", str(value or "").strip())


def tokenize_values(text):
    return TOKEN_PATTERN.findall(text or "")


def parse_metric_line(line, label):
    normalized = normalize_line(line)
    if label not in normalized:
        return None
    left, right = normalized.split(label, 1)
    left_tokens = tokenize_values(left)
    right_tokens = tokenize_values(right)
    if len(left_tokens) < 3 or len(right_tokens) < 3:
        return None
    return {
        "current_month_actual": as_float(left_tokens[0]),
        "prior_year_month_actual": as_float(left_tokens[1]),
        "current_month_plan": as_float(left_tokens[2]),
        "current_ytd_actual": as_float(right_tokens[0]),
        "prior_ytd_actual": as_float(right_tokens[1]),
        "current_ytd_plan": as_float(right_tokens[2]),
    }


def parse_month_label(lines):
    for line in lines:
        match = MONTH_LABEL_PATTERN.search(normalize_line(line))
        if match:
            return match.group(1)
    raise ValueError("GL060 month label could not be proven from the PDF.")


def parse_finance_pdf(path, branch):
    all_lines = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            all_lines.extend(text.splitlines())

    month_label = parse_month_label(all_lines)
    period = datetime.strptime(month_label, "%B %Y")
    metric_rows = {}

    for label, key in FINANCE_METRICS.items():
        match = None
        for line in all_lines:
            if label not in normalize_line(line):
                continue
            candidate = parse_metric_line(line, label)
            if candidate is not None:
                match = candidate
                break
        if match is None:
            raise ValueError(f"GL060 metric '{label}' could not be proven from {path.name}.")
        metric_rows[key] = match

    snapshot = {
        "qfu_name": f"{branch['branch_code']} GL060 {month_label}",
        "qfu_sourceid": f"{branch['branch_code']}|GL060|{period.year}-{period.month:02d}",
        "qfu_branchcode": branch["branch_code"],
        "qfu_branchslug": branch["branch_slug"],
        "qfu_regionslug": branch["region_slug"],
        "qfu_sourcefamily": "GL060",
        "qfu_sourcefile": path.name,
        "qfu_monthlabel": month_label,
        "qfu_month": period.month,
        "qfu_year": period.year,
        "qfu_lastupdated": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
        "qfu_currentmonthsalesactual": round(metric_rows["sales"]["current_month_actual"], 2),
        "qfu_currentmonthsalesplan": round(metric_rows["sales"]["current_month_plan"], 2),
        "qfu_currentmonthgrossprofitactual": round(metric_rows["grossprofit"]["current_month_actual"], 2),
        "qfu_currentmonthgrossprofitplan": round(metric_rows["grossprofit"]["current_month_plan"], 2),
        "qfu_currentmonthgrossprofitpctactual": round(metric_rows["grossprofitpct"]["current_month_actual"], 4),
        "qfu_currentmonthgrossprofitpctplan": round(metric_rows["grossprofitpct"]["current_month_plan"], 4),
        "qfu_currentmonthopexpctactual": round(metric_rows["opexpct"]["current_month_actual"], 4),
        "qfu_currentmonthopexpctplan": round(metric_rows["opexpct"]["current_month_plan"], 4),
        "qfu_currentmonthgapactual": round(metric_rows["gap"]["current_month_actual"], 4),
        "qfu_currentmonthgapplan": round(metric_rows["gap"]["current_month_plan"], 4),
        "qfu_currentmonthoperatingprofitactual": round(metric_rows["operatingprofit"]["current_month_actual"], 2),
        "qfu_currentmonthoperatingprofitplan": round(metric_rows["operatingprofit"]["current_month_plan"], 2),
        "qfu_ytdsalesactual": round(metric_rows["sales"]["current_ytd_actual"], 2),
        "qfu_ytdsalesplan": round(metric_rows["sales"]["current_ytd_plan"], 2),
        "qfu_ytdgrossprofitactual": round(metric_rows["grossprofit"]["current_ytd_actual"], 2),
        "qfu_ytdgrossprofitplan": round(metric_rows["grossprofit"]["current_ytd_plan"], 2),
        "qfu_ytdoperatingprofitactual": round(metric_rows["operatingprofit"]["current_ytd_actual"], 2),
        "qfu_ytdoperatingprofitplan": round(metric_rows["operatingprofit"]["current_ytd_plan"], 2),
    }

    variances = []
    for sort_order, (label, variance_slug) in enumerate(VARIANCE_LABELS.items(), start=1):
        match = None
        for line in all_lines:
            if label not in normalize_line(line):
                continue
            candidate = parse_metric_line(line, label)
            if candidate is not None:
                match = candidate
                break
        if match is None:
            continue
        variances.append(
            {
                "qfu_name": f"{branch['branch_code']} {month_label} {label}",
                "qfu_sourceid": f"{branch['branch_code']}|GL060VAR|{period.year}-{period.month:02d}|{variance_slug}",
                "qfu_branchcode": branch["branch_code"],
                "qfu_branchslug": branch["branch_slug"],
                "qfu_regionslug": branch["region_slug"],
                "qfu_sourcefamily": "GL060",
                "qfu_sourcefile": path.name,
                "qfu_monthlabel": month_label,
                "qfu_month": period.month,
                "qfu_year": period.year,
                "qfu_variancelabel": label,
                "qfu_varianceslug": variance_slug,
                "qfu_sortorder": sort_order,
                "qfu_currentmonthactual": round(match["current_month_actual"], 2),
                "qfu_currentmonthplan": round(match["current_month_plan"], 2),
                "qfu_currentmonthvariance": round(match["current_month_actual"] - match["current_month_plan"], 2),
                "qfu_ytdactual": round(match["current_ytd_actual"], 2),
                "qfu_ytdplan": round(match["current_ytd_plan"], 2),
                "qfu_ytdvariance": round(match["current_ytd_actual"] - match["current_ytd_plan"], 2),
                "qfu_lastupdated": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
            }
        )

    return snapshot, variances


def parse_abnormal_margin(path, branch):
    workbook = load_workbook(path, data_only=True, read_only=True)
    sheet = workbook["Abnormal Margin Review"]
    snapshot_date = datetime.fromtimestamp(path.stat().st_mtime).date()
    records = []

    for row in sheet.iter_rows(min_row=3, values_only=True):
        location = as_text(row[3]) if len(row) > 3 else None
        billing_doc = as_text(row[11]) if len(row) > 11 else None
        review_type = as_text(row[6]) if len(row) > 6 else None
        if location != branch["branch_code"] or billing_doc is None or review_type is None:
            continue

        billing_date = as_date(row[5]) if len(row) > 5 else None
        records.append(
            {
                "qfu_name": f"{branch['branch_code']} Margin {billing_doc}",
                "qfu_sourceid": f"{branch['branch_code']}|SA1300-MARGIN|{snapshot_date.isoformat()}|{billing_doc}|{slugify(review_type)}",
                "qfu_branchcode": branch["branch_code"],
                "qfu_branchslug": branch["branch_slug"],
                "qfu_regionslug": branch["region_slug"],
                "qfu_sourcefamily": "SA1300-ABNORMALMARGIN",
                "qfu_sourcefile": path.name,
                "qfu_snapshotdate": snapshot_date.isoformat(),
                "qfu_billingdate": iso_date(billing_date),
                "qfu_reviewtype": review_type,
                "qfu_currencytype": as_text(row[7]) if len(row) > 7 else None,
                "qfu_cssr": as_text(row[8]) if len(row) > 8 else None,
                "qfu_cssrname": as_text(row[9]) if len(row) > 9 else None,
                "qfu_customername": as_text(row[10]) if len(row) > 10 else None,
                "qfu_billingdocumentnumber": billing_doc,
                "qfu_billingdocumenttype": as_text(row[12]) if len(row) > 12 else None,
                "qfu_sales": round(as_float(row[13]) if len(row) > 13 else 0.0, 2),
                "qfu_cogs": round(as_float(row[14]) if len(row) > 14 else 0.0, 2),
                "qfu_gp": round(as_float(row[15]) if len(row) > 15 else 0.0, 2),
            }
        )

    return {
        "file_name": path.name,
        "captured_on": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
        "snapshot_date": snapshot_date.isoformat(),
        "records": records,
    }


def parse_late_orders(path, branch):
    workbook = load_workbook(path, data_only=True, read_only=True)
    sheet_name = next(name for name in workbook.sheetnames if name.strip() == "On-Time_ Late Order Review")
    sheet = workbook[sheet_name]
    snapshot_date = datetime.fromtimestamp(path.stat().st_mtime).date()
    records = []

    for row in sheet.iter_rows(min_row=3, values_only=True):
        location = as_text(row[4]) if len(row) > 4 else None
        billing_doc = as_text(row[11]) if len(row) > 11 else None
        if location != branch["branch_code"] or billing_doc is None:
            continue

        billing_date = as_date(row[10]) if len(row) > 10 else None
        item_category = as_text(row[13]) if len(row) > 13 else None
        records.append(
            {
                "qfu_name": f"{branch['branch_code']} Late Order {billing_doc}",
                "qfu_sourceid": f"{branch['branch_code']}|SA1300-LATEORDER|{snapshot_date.isoformat()}|{billing_doc}|{slugify(item_category or 'line')}",
                "qfu_branchcode": branch["branch_code"],
                "qfu_branchslug": branch["branch_slug"],
                "qfu_regionslug": branch["region_slug"],
                "qfu_sourcefamily": "SA1300-LATEORDER",
                "qfu_sourcefile": path.name,
                "qfu_snapshotdate": snapshot_date.isoformat(),
                "qfu_billingdate": iso_date(billing_date),
                "qfu_cssr": as_text(row[6]) if len(row) > 6 else None,
                "qfu_cssrname": as_text(row[7]) if len(row) > 7 else None,
                "qfu_soldtocustomername": as_text(row[8]) if len(row) > 8 else None,
                "qfu_shiptocustomername": as_text(row[9]) if len(row) > 9 else None,
                "qfu_billingdocumentnumber": billing_doc,
                "qfu_materialgroup": as_text(row[12]) if len(row) > 12 else None,
                "qfu_itemcategory": item_category,
                "qfu_itemcategorydescription": as_text(row[14]) if len(row) > 14 else None,
                "qfu_sales": round(as_float(row[15]) if len(row) > 15 else 0.0, 2),
            }
        )

    return {
        "file_name": path.name,
        "captured_on": datetime.fromtimestamp(path.stat().st_mtime).isoformat(),
        "snapshot_date": snapshot_date.isoformat(),
        "records": records,
    }


def build_batches(branch, finance, abnormal_margin, late_orders):
    return [
        {
            "qfu_name": f"{branch['branch_code']} GL060 Import",
            "qfu_sourceid": f"{branch['branch_code']}|batch|GL060|{finance['record']['qfu_year']}-{finance['record']['qfu_month']:02d}",
            "qfu_branchcode": branch["branch_code"],
            "qfu_branchslug": branch["branch_slug"],
            "qfu_regionslug": branch["region_slug"],
            "qfu_sourcefamily": "GL060",
            "qfu_sourcefilename": finance["file_name"],
            "qfu_status": "ready",
            "qfu_insertedcount": 1 + len(finance["variances"]),
            "qfu_updatedcount": 0,
            "qfu_startedon": finance["captured_on"],
            "qfu_completedon": finance["captured_on"],
            "qfu_triggerflow": "Controlled PDF seed",
            "qfu_notes": f"Seeded from {finance['file_name']} for {branch['branch_code']}.",
        },
        {
            "qfu_name": f"{branch['branch_code']} SA1300 Abnormal Margin Snapshot",
            "qfu_sourceid": f"{branch['branch_code']}|batch|SA1300-ABNORMALMARGIN|{abnormal_margin['snapshot_date']}",
            "qfu_branchcode": branch["branch_code"],
            "qfu_branchslug": branch["branch_slug"],
            "qfu_regionslug": branch["region_slug"],
            "qfu_sourcefamily": "SA1300-ABNORMALMARGIN",
            "qfu_sourcefilename": abnormal_margin["file_name"],
            "qfu_status": "ready",
            "qfu_insertedcount": len(abnormal_margin["records"]),
            "qfu_updatedcount": 0,
            "qfu_startedon": abnormal_margin["captured_on"],
            "qfu_completedon": abnormal_margin["captured_on"],
            "qfu_triggerflow": "Controlled workbook seed",
            "qfu_notes": f"Seeded abnormal margin snapshot from {abnormal_margin['file_name']} for {branch['branch_code']}.",
        },
        {
            "qfu_name": f"{branch['branch_code']} SA1300 Late Order Snapshot",
            "qfu_sourceid": f"{branch['branch_code']}|batch|SA1300-LATEORDER|{late_orders['snapshot_date']}",
            "qfu_branchcode": branch["branch_code"],
            "qfu_branchslug": branch["branch_slug"],
            "qfu_regionslug": branch["region_slug"],
            "qfu_sourcefamily": "SA1300-LATEORDER",
            "qfu_sourcefilename": late_orders["file_name"],
            "qfu_status": "ready",
            "qfu_insertedcount": len(late_orders["records"]),
            "qfu_updatedcount": 0,
            "qfu_startedon": late_orders["captured_on"],
            "qfu_completedon": late_orders["captured_on"],
            "qfu_triggerflow": "Controlled workbook seed",
            "qfu_notes": f"Seeded late order snapshot from {late_orders['file_name']} for {branch['branch_code']}.",
        },
    ]


def parse_branch(root, branch_code, sa1300_root=None, gl060_root=None):
    branch = BRANCHES[branch_code]
    branch_root = Path(root, branch_code)
    sa1300_branch_root = Path(sa1300_root, branch_code) if sa1300_root else branch_root
    gl060_branch_root = Path(gl060_root, branch_code) if gl060_root else branch_root
    sa1300_path = next(sa1300_branch_root.glob("SA1300*.xlsx"))
    gl060_path = next(gl060_branch_root.glob("GL060*.pdf"))

    finance_snapshot, finance_variances = parse_finance_pdf(gl060_path, branch)
    abnormal_margin = parse_abnormal_margin(sa1300_path, branch)
    late_orders = parse_late_orders(sa1300_path, branch)

    return {
        "branch": branch,
        "finance": {
            "file_name": gl060_path.name,
            "captured_on": datetime.fromtimestamp(gl060_path.stat().st_mtime).isoformat(),
            "record": finance_snapshot,
            "variances": finance_variances,
        },
        "abnormal_margin": abnormal_margin,
        "late_orders": late_orders,
        "batches": build_batches(branch, {"file_name": gl060_path.name, "captured_on": datetime.fromtimestamp(gl060_path.stat().st_mtime).isoformat(), "record": finance_snapshot, "variances": finance_variances}, abnormal_margin, late_orders),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--example-root", default="example")
    parser.add_argument("--sa1300-root")
    parser.add_argument("--gl060-root")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    branches = [
        parse_branch(args.example_root, code, sa1300_root=args.sa1300_root, gl060_root=args.gl060_root)
        for code in sorted(BRANCHES.keys())
    ]
    payload = {
        "generated_on": datetime.now().isoformat(),
        "region": {
            "region_slug": "southern-alberta",
            "region_name": "Southern Alberta",
        },
        "branches": branches,
    }

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
