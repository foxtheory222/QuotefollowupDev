param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com"
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell

$conn = Connect-CrmOnline -ServerUrl $TargetEnvironmentUrl -ForceOAuth -Username $Username
if (-not $conn -or -not $conn.IsReady) {
  throw "Dataverse connection failed for $TargetEnvironmentUrl : $($conn.LastCrmError)"
}

$permissions = (Get-CrmRecordsByFetch -conn $conn -Fetch @"
<fetch>
  <entity name='mspp_entitypermission'>
    <all-attributes />
  </entity>
</fetch>
"@).CrmRecords |
  Where-Object { $_.mspp_entitylogicalname -like 'qfu_*' } |
  Select-Object mspp_entitypermissionid, mspp_entitylogicalname

$rawLinks = (Get-CrmRecordsByFetch -conn $conn -Fetch @"
<fetch>
  <entity name='mspp_entitypermission_webrole'>
    <all-attributes />
  </entity>
</fetch>
"@).CrmRecords |
  Select-Object mspp_entitypermissionid, mspp_webroleid

$roleMap = @{
  '0d42a052-4ceb-4d02-bfb1-eea0860bcae9' = 'Authenticated Users'
  'd1681251-ec76-4138-b394-038772b4aa90' = 'Administrators'
  '695703dc-ec50-466e-a28c-9878fe269a7a' = 'Anonymous Users'
}

$summary = foreach ($permission in $permissions) {
  $links = $rawLinks | Where-Object { $_.mspp_entitypermissionid -eq $permission.mspp_entitypermissionid }
  [pscustomobject]@{
    permissionId = $permission.mspp_entitypermissionid
    table = $permission.mspp_entitylogicalname
    roleIds = @($links | ForEach-Object { $_.mspp_webroleid } | Sort-Object -Unique)
    roles = @($links | ForEach-Object {
      if ($roleMap.ContainsKey($_.mspp_webroleid)) { $roleMap[$_.mspp_webroleid] } else { $_.mspp_webroleid }
    } | Sort-Object -Unique)
    linkCount = @($links).Count
  }
}

$summary | Sort-Object table | ConvertTo-Json -Depth 5
