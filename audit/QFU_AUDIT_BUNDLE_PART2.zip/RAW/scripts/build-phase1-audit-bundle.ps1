param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$OutputZip = "phase1_audit_bundle.zip"
)

$ErrorActionPreference = "Stop"

$bundleName = "phase1_audit_bundle"
$bundleRoot = Join-Path $RepoRoot $bundleName
$zipPath = Join-Path $RepoRoot $OutputZip
$verifyRoot = Join-Path $RepoRoot ".phase1_audit_verify"

$targetEnvironmentName = "Applied Canada Operations Hub"
$targetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com/"
$targetSiteUrl = "https://operationhub.powerappsportals.com/"
$sourceUxEnvironmentUrl = "https://orgd3e6cd10.crm3.dynamics.com/"
$sourceUxSiteUrl = "https://quoteoperations.powerappsportals.com/"
$sourceFlowEnvironmentName = "Branch Operations Dashboard"
$sourceFlowEnvironmentUrl = "https://orgad610d2c.crm3.dynamics.com/"
$sourceFlowPowerAutomateUrl = "https://make.powerautomate.com/environments/2edaee07-0e98-e29d-a642-c9134bae64f3/flows"

$targetSiteExportRoot = Join-Path $RepoRoot ".live-site-download\phase1-verify\operations-hub---operationhub"
$sourceSolutionZip = Join-Path $RepoRoot "results\QuoteFollowUpSystemUnmanaged_source4171.zip"
$sourceSolutionRoot = Join-Path $RepoRoot "results\source4171-solution-unpacked"
$sourceSettingsPath = Join-Path $RepoRoot "QFUAUDIT\01_solution\QuoteFollowUpSystemUnmanaged.settings.json"
$syncSummaryPath = Join-Path $RepoRoot "results\phase1-calgary-sync-summary.json"
$canonicalPatternPath = Join-Path $RepoRoot "docs\pages\CANONICAL_BRANCH_PATTERN.md"
$prototypeSyncScriptPath = Join-Path $RepoRoot "scripts\deploy-phase1-calgary.ps1"

$nodeExe = Join-Path $RepoRoot "Archive\.tools\node-v24.14.0-win-x64\node.exe"
$captureScript = Join-Path $RepoRoot "scripts\capture-portal-screenshot.cjs"
$probeScript = Join-Path $RepoRoot "Archive\playwright\scripts\probe-portal-api.js"
$probeWorkdir = Join-Path $RepoRoot "Archive\playwright"
$storageStatePath = Join-Path $RepoRoot ".playwright-auth\operationhub-dev-state.json"

$screenshotRoot = Join-Path $bundleRoot "SCREENSHOTS"
$targetSiteExportBundleRoot = Join-Path $bundleRoot "TARGET_SITE_EXPORT"
$sourceFlowExportRoot = Join-Path $bundleRoot "SOURCE_FLOW_EXPORT"
$targetDataReferenceRoot = Join-Path $bundleRoot "TARGET_DATA_REFERENCE"
$logsRoot = Join-Path $bundleRoot "OPTIONAL_LOGS"

function Ensure-Directory {
  param([string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Remove-IfExists {
  param([string]$Path)

  if (Test-Path -LiteralPath $Path) {
    Remove-Item -LiteralPath $Path -Recurse -Force
  }
}

function Write-Utf8File {
  param(
    [string]$Path,
    [string]$Content
  )

  $parent = Split-Path -Parent $Path
  if ($parent) {
    Ensure-Directory $parent
  }

  [System.IO.File]::WriteAllText($Path, $Content, (New-Object System.Text.UTF8Encoding($false)))
}

function Read-JsonFile {
  param([string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) {
    throw "Required JSON file not found: $Path"
  }

  return (Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json -Depth 100)
}

function Join-Lines {
  param([string[]]$Lines)

  return (($Lines -join [Environment]::NewLine) + [Environment]::NewLine)
}

function Capture-LiveScreenshot {
  param(
    [string]$Url,
    [string]$OutFile
  )

  if (-not (Test-Path -LiteralPath $nodeExe)) {
    throw "Node runtime not found: $nodeExe"
  }
  if (-not (Test-Path -LiteralPath $captureScript)) {
    throw "Capture script not found: $captureScript"
  }
  if (-not (Test-Path -LiteralPath $storageStatePath)) {
    throw "Playwright storage state not found: $storageStatePath"
  }

  $captureRaw = & $nodeExe $captureScript $Url $OutFile $storageStatePath "3000" | Out-String
  if ($LASTEXITCODE -ne 0) {
    throw "Screenshot capture failed for $Url"
  }

  if (-not (Test-Path -LiteralPath $OutFile)) {
    throw "Screenshot output missing: $OutFile"
  }

  $payload = $captureRaw | ConvertFrom-Json
  $requestedHost = ([System.Uri]$Url).Host
  $finalHost = if ($payload.finalUrl) { ([System.Uri]$payload.finalUrl).Host } else { "" }
  $bodyStart = if ($payload.bodyStart) { [string]$payload.bodyStart } else { "" }
  $title = if ($payload.title) { [string]$payload.title } else { "" }
  $signInMarkers = @("Sign in", "Stay signed in", "Pick an account", "Use another account")

  if ($finalHost -ne $requestedHost) {
    throw "Screenshot redirected away from target host. Requested $requestedHost, got $finalHost."
  }

  foreach ($marker in $signInMarkers) {
    if ($title -like "*$marker*" -or $bodyStart -like "*$marker*") {
      throw "Screenshot for $Url appears to be on an auth page: $marker"
    }
  }

  return $payload
}

function Invoke-PortalApiProbe {
  param([string[]]$Paths)

  if (-not (Test-Path -LiteralPath $nodeExe)) {
    throw "Node runtime not found: $nodeExe"
  }
  if (-not (Test-Path -LiteralPath $probeScript)) {
    throw "Probe script not found: $probeScript"
  }

  $previousBaseUrl = $env:PLAYWRIGHT_BASE_URL
  $previousStorageState = $env:PLAYWRIGHT_STORAGE_STATE
  $previousApiPaths = $env:PLAYWRIGHT_API_PATHS
  $previousHeadless = $env:PLAYWRIGHT_HEADLESS

  try {
    $env:PLAYWRIGHT_BASE_URL = $targetSiteUrl.TrimEnd("/")
    $env:PLAYWRIGHT_STORAGE_STATE = $storageStatePath
    $env:PLAYWRIGHT_API_PATHS = ($Paths -join "|")
    $env:PLAYWRIGHT_HEADLESS = "1"

    Push-Location $probeWorkdir
    try {
      $probeRaw = & $nodeExe $probeScript | Out-String
      if ($LASTEXITCODE -ne 0) {
        throw "Portal API probe failed."
      }
    } finally {
      Pop-Location
    }
  } finally {
    $env:PLAYWRIGHT_BASE_URL = $previousBaseUrl
    $env:PLAYWRIGHT_STORAGE_STATE = $previousStorageState
    $env:PLAYWRIGHT_API_PATHS = $previousApiPaths
    $env:PLAYWRIGHT_HEADLESS = $previousHeadless
  }

  return ($probeRaw | ConvertFrom-Json -Depth 100)
}

function Get-WorkflowJson {
  param([string]$Pattern)

  $match = Get-ChildItem -LiteralPath (Join-Path $sourceSolutionRoot "Workflows") -Filter $Pattern | Where-Object { $_.Name -notlike "*.data.xml" } | Select-Object -First 1
  if (-not $match) {
    throw "Workflow file not found for pattern: $Pattern"
  }

  return [pscustomobject]@{
    Path = $match.FullName
    Json = (Get-Content -LiteralPath $match.FullName -Raw | ConvertFrom-Json -Depth 100)
  }
}

function Get-ParameterDefaultMap {
  param([object]$WorkflowJson)

  $result = @{}
  $paramsNode = $WorkflowJson.properties.definition.parameters
  if ($null -eq $paramsNode) {
    return $result
  }

  foreach ($prop in $paramsNode.PSObject.Properties) {
    $defaultValue = $null
    if ($null -ne $prop.Value -and $null -ne $prop.Value.defaultValue) {
      $defaultValue = $prop.Value.defaultValue
    }
    $result[$prop.Name] = $defaultValue
  }

  return $result
}

$flowMappings = @(
  [pscustomobject]@{
    SourceName = "QuoteFollow-UpImport-Staging_DEV"
    SourcePattern = "QuoteFollow-UpImport-Staging_DEV-*.json"
    TargetName = "4171-QuoteFollowUp-Import-Staging"
    Status = "not migrated"
    MigrationType = "recreate"
    Purpose = "Import SP830CA quote follow-up rows into target Dataverse staging/operational tables."
    Notes = @(
      "Source trigger filters email subject for SP830CA.",
      "Source flow embeds OneDrive drive id, OneDrive folder path, Outlook folder id, and Office Script id defaults.",
      "Target replacement must use target-environment connection references and environment variables."
    )
  },
  [pscustomobject]@{
    SourceName = "BackOrder_Update_From_CA_ZBO_DEV"
    SourcePattern = "BackOrder_Update_From_CA_ZBO_DEV-*.json"
    TargetName = "4171-BackOrder-Update-ZBO"
    Status = "not migrated"
    MigrationType = "recreate"
    Purpose = "Import Calgary ZBO backorder source into target Dataverse."
    Notes = @(
      "Source trigger filters email subject for Daily Backorder Report.",
      "Source flow embeds OneDrive drive id, OneDrive folder path, Outlook folder id, and Office Script id defaults.",
      "Target replacement must use target-environment connection references and environment variables."
    )
  },
  [pscustomobject]@{
    SourceName = "Budget_Update_From_SA1300_Unmanaged_DEV"
    SourcePattern = "Budget_Update_From_SA1300_Unmanaged_DEV-*.json"
    TargetName = "4171-Budget-Update-SA1300"
    Status = "not migrated"
    MigrationType = "recreate"
    Purpose = "Import Calgary SA1300 budget and sales metrics into target Dataverse."
    Notes = @(
      "Source flow embeds OneDrive drive id, OneDrive folder path, active fiscal year, Outlook folder id, and Office Script id defaults.",
      "Source flow hardcodes Calgary Branch and SA1300.xlsx inside action payloads.",
      "Target replacement must externalize branch/source identifiers and file references."
    )
  },
  [pscustomobject]@{
    SourceName = "QFU-RecalculateQueueState_DEV"
    SourcePattern = "QFU-RecalculateQueueState_DEV-*.json"
    TargetName = "4171-QFU-RecalculateQueueState"
    Status = "not migrated"
    MigrationType = "recreate"
    Purpose = "Recalculate quote queue states, overdue logic, and follow-up cadence."
    Notes = @(
      "Source flow embeds overdue, expiring soon, expire, and default next follow-up thresholds.",
      "Target replacement should move thresholds into target config/environment variables."
    )
  },
  [pscustomobject]@{
    SourceName = "QFU-BackfillHeaderFollow-Up_DEV"
    SourcePattern = "QFU-BackfillHeaderFollow-Up_DEV-*.json"
    TargetName = "4171-QFU-BackfillHeaderFollowUp"
    Status = "not migrated"
    MigrationType = "recreate"
    Purpose = "Backfill follow-up summary fields onto quote headers."
    Notes = @(
      "Target flow is required only after the target quote/quote line schema is verified.",
      "No target solution-aware implementation was found."
    )
  },
  [pscustomobject]@{
    SourceName = "QFU-CloseQuoteWhenAnyLineWon_DEV"
    SourcePattern = "QFU-CloseQuoteWhenAnyLineWon_DEV-*.json"
    TargetName = "4171-QFU-CloseQuoteWhenAnyLineWon"
    Status = "not migrated"
    MigrationType = "recreate"
    Purpose = "Close quote headers when any line is won."
    Notes = @(
      "No target solution-aware implementation was found."
    )
  },
  [pscustomobject]@{
    SourceName = "QFU-Debug-SendTestEmails_DEV"
    SourcePattern = "QFU-Debug-SendTestEmails_DEV-*.json"
    TargetName = ""
    Status = "excluded"
    MigrationType = "excluded"
    Purpose = "Debug/test-only flow."
    Notes = @(
      "Explicitly excluded from the production Calgary Phase 1 path."
    )
  }
)

$portalProbePaths = @(
  "/_api/qfu_quotes?`$top=1&`$select=qfu_quoteid",
  "/_api/qfu_backorders?`$top=1&`$select=qfu_backorderid",
  "/_api/qfu_budgets?`$top=1&`$select=qfu_budgetid"
)

$screenshotTargets = @(
  [pscustomobject]@{ Name = "01_hub.png"; Url = $targetSiteUrl },
  [pscustomobject]@{ Name = "02_region_southern_alberta.png"; Url = ($targetSiteUrl + "southern-alberta") },
  [pscustomobject]@{ Name = "03_branch_4171_calgary_home.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary") },
  [pscustomobject]@{ Name = "04_branch_4171_calgary_followup_queue.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=follow-up-queue") },
  [pscustomobject]@{ Name = "05_branch_4171_calgary_quotes.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=quotes") },
  [pscustomobject]@{ Name = "06_branch_4171_calgary_overdue_quotes.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=overdue-quotes") },
  [pscustomobject]@{ Name = "07_branch_4171_calgary_overdue_backorders.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=overdue-backorders") },
  [pscustomobject]@{ Name = "08_branch_4171_calgary_team_progress_locked.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=team-progress") },
  [pscustomobject]@{ Name = "09_branch_4171_calgary_workload_locked.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=workload") },
  [pscustomobject]@{ Name = "10_branch_4171_calgary_analytics_locked.png"; Url = ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=analytics") },
  [pscustomobject]@{ Name = "11_branch_4172_lethbridge_locked.png"; Url = ($targetSiteUrl + "southern-alberta/4172-lethbridge") },
  [pscustomobject]@{ Name = "12_branch_4173_medicine_hat_locked.png"; Url = ($targetSiteUrl + "southern-alberta/4173-medicine-hat") }
)

$requiredRootFiles = @(
  "README_PHASE1_REVIEW.md",
  "FLOW_MIGRATION_SUMMARY.md",
  "SOURCE_FLOW_REFERENCE.md",
  "TARGET_FLOW_MAP.md",
  "NAMING_STANDARD.md",
  "CONNECTIONS_AND_VARIABLES.md",
  "DATAVERSE_BINDING_MAP.md",
  "CONFIG_AND_SEED_DATA.md",
  "CUTOVER_AND_TRIGGER_STATE.md",
  "LIVE_VS_LOCKED_MATRIX.md",
  "NO_UI_REDESIGN_NOTE.md"
)

if (-not (Test-Path -LiteralPath $targetSiteExportRoot)) {
  throw "Target site export not found: $targetSiteExportRoot"
}
if (-not (Test-Path -LiteralPath $sourceSolutionZip)) {
  throw "Source solution zip not found: $sourceSolutionZip"
}
if (-not (Test-Path -LiteralPath $sourceSolutionRoot)) {
  throw "Source solution unpack folder not found: $sourceSolutionRoot"
}
if (-not (Test-Path -LiteralPath $sourceSettingsPath)) {
  throw "Source solution settings not found: $sourceSettingsPath"
}
if (-not (Test-Path -LiteralPath $syncSummaryPath)) {
  throw "Sync summary not found: $syncSummaryPath"
}
if (-not (Test-Path -LiteralPath $canonicalPatternPath)) {
  throw "Canonical pattern note not found: $canonicalPatternPath"
}

Remove-IfExists $bundleRoot
Remove-IfExists $zipPath
Remove-IfExists $verifyRoot

Ensure-Directory $bundleRoot
Ensure-Directory $screenshotRoot
Ensure-Directory $targetSiteExportBundleRoot
Ensure-Directory $sourceFlowExportRoot
Ensure-Directory $targetDataReferenceRoot
Ensure-Directory $logsRoot

Copy-Item -LiteralPath $targetSiteExportRoot -Destination (Join-Path $targetSiteExportBundleRoot "operations-hub---operationhub") -Recurse -Force
Copy-Item -LiteralPath $sourceSolutionZip -Destination (Join-Path $sourceFlowExportRoot "QuoteFollowUpSystemUnmanaged_source4171.zip") -Force
Copy-Item -LiteralPath $sourceSolutionRoot -Destination (Join-Path $sourceFlowExportRoot "source4171-solution-unpacked") -Recurse -Force
Copy-Item -LiteralPath $syncSummaryPath -Destination (Join-Path $targetDataReferenceRoot "phase1-calgary-sync-summary.json") -Force
Copy-Item -LiteralPath $canonicalPatternPath -Destination (Join-Path $targetDataReferenceRoot "CANONICAL_BRANCH_PATTERN.md") -Force
Copy-Item -LiteralPath $prototypeSyncScriptPath -Destination (Join-Path $targetDataReferenceRoot "deploy-phase1-calgary.ps1") -Force

$sourceSettings = Read-JsonFile -Path $sourceSettingsPath
$syncSummary = Read-JsonFile -Path $syncSummaryPath

$inspectedFlowDetails = @()
foreach ($mapping in $flowMappings) {
  $detail = [ordered]@{
    SourceName = $mapping.SourceName
    TargetName = $mapping.TargetName
    Status = $mapping.Status
    MigrationType = $mapping.MigrationType
    Purpose = $mapping.Purpose
    Notes = $mapping.Notes
    SourceFile = $null
    SourceConnectionReferences = @()
    SourceParameters = @{}
    TriggerSummary = @()
  }

  $workflow = Get-WorkflowJson -Pattern $mapping.SourcePattern
  $detail.SourceFile = $workflow.Path
  $detail.SourceParameters = Get-ParameterDefaultMap -WorkflowJson $workflow.Json
  $detail.SourceConnectionReferences = @(
    $workflow.Json.properties.connectionReferences.PSObject.Properties |
      ForEach-Object {
        $logicalName = $_.Value.connection.connectionReferenceLogicalName
        if ($logicalName) { $logicalName }
      } |
      Sort-Object -Unique
  )
  $detail.TriggerSummary = @(
    $workflow.Json.properties.definition.triggers.PSObject.Properties |
      ForEach-Object {
        $triggerName = $_.Name
        $subjectFilter = $_.Value.inputs.parameters.subjectFilter
        $folderPath = $_.Value.inputs.parameters.folderPath
        if ($subjectFilter) {
          "${triggerName}: subjectFilter=$subjectFilter; folderPath=$folderPath"
        } else {
          "$triggerName"
        }
      }
  )

  $inspectedFlowDetails += [pscustomobject]$detail
}

$targetSolutionListText = (& pac solution list --environment $targetEnvironmentUrl | Out-String).Trim()
if ($LASTEXITCODE -ne 0) {
  throw "Failed to list target environment solutions."
}

$sourceSolutionListText = (& pac solution list --environment $sourceFlowEnvironmentUrl | Out-String).Trim()
if ($LASTEXITCODE -ne 0) {
  throw "Failed to list source flow environment solutions."
}

Write-Utf8File -Path (Join-Path $logsRoot "target_solution_list.txt") -Content ($targetSolutionListText + [Environment]::NewLine)
Write-Utf8File -Path (Join-Path $logsRoot "source_flow_solution_list.txt") -Content ($sourceSolutionListText + [Environment]::NewLine)

$probePayload = Invoke-PortalApiProbe -Paths $portalProbePaths
Write-Utf8File -Path (Join-Path $logsRoot "portal_api_probe.json") -Content (($probePayload | ConvertTo-Json -Depth 100) + [Environment]::NewLine)

$probeSummaryLines = @()
foreach ($result in $probePayload.results) {
  $probeSummaryLines += "- $($result.path) -> $($result.status) $($result.statusText)"
}

$screenshotEvidence = @()
foreach ($shot in $screenshotTargets) {
  $outFile = Join-Path $screenshotRoot $shot.Name
  $payload = Capture-LiveScreenshot -Url $shot.Url -OutFile $outFile
  $screenshotEvidence += [pscustomobject]@{
    Name = $shot.Name
    Url = $shot.Url
    FinalUrl = $payload.finalUrl
    Title = $payload.title
    Status = $payload.status
  }
}

$liveItems = @()
$lockedItems = @(
  "4171 Calgary Home",
  "4171 Calgary Follow-up Queue",
  "4171 Calgary Quotes",
  "4171 Calgary Overdue Quotes",
  "4171 Calgary Overdue Backorders",
  "4171 Calgary Team Progress",
  "4171 Calgary Workload",
  "4171 Calgary Analytics",
  "4172 Lethbridge",
  "4173 Medicine Hat",
  "Northern Alberta",
  "Saskatchewan",
  "Ops/Admin"
)

$partialItems = @(
  "Target site shell exported from operationhub.powerappsportals.com",
  "Prototype Dataverse data present in qfu_quote, qfu_backorder, and qfu_budget through direct sync summary only",
  "Target site export includes qfu_quote, qfu_backorder, and qfu_budget table-permission artifacts, but the effective portal API still returns 403 for the authenticated user"
)

$sourceConnectionReferences = @($sourceSettings.ConnectionReferences | Sort-Object LogicalName)
$sourceEnvironmentVariables = @($sourceSettings.EnvironmentVariables | Sort-Object SchemaName)
$nonExcludedFlowDetails = @($inspectedFlowDetails | Where-Object { $_.Status -ne "excluded" })
$excludedFlowDetails = @($inspectedFlowDetails | Where-Object { $_.Status -eq "excluded" })

$targetReplacementMap = @(
  [pscustomobject]@{ OldAsset = "qfu_shared_commondataserviceforapps"; TargetAsset = "4171-Dataverse"; Status = "not created"; Notes = "Required target Dataverse connection reference for solution-aware Calgary flows." },
  [pscustomobject]@{ OldAsset = "qfu_shared_office365"; TargetAsset = "4171-Office365"; Status = "not created"; Notes = "Required target Office 365 connection reference for controlled mail/manual replay path." },
  [pscustomobject]@{ OldAsset = "qfu_shared_onedriveforbusiness"; TargetAsset = "4171-OneDrive"; Status = "not created"; Notes = "Required only if the migrated design still stages files in OneDrive." },
  [pscustomobject]@{ OldAsset = "qfu_shared_excelonlinebusiness"; TargetAsset = "4171-ExcelOnlineBusiness"; Status = "not created"; Notes = "Required only if Excel-script parsing is retained." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_EnvironmentId"; TargetAsset = "4171-QFU-EnvironmentId"; Status = "not created"; Notes = "Must point to the target environment only." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_OrgUrl"; TargetAsset = "4171-QFU-OrgUrl"; Status = "not created"; Notes = "Must point to regionaloperationshub only." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_ReportsFolderName"; TargetAsset = "4171-QFU-ReportsFolderName"; Status = "not created"; Notes = "Target reporting/archive folder label not yet verified." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_SP830CA_FilePattern"; TargetAsset = "4171-QFU-SP830CA-AttachmentPattern"; Status = "not created"; Notes = "Required if attachment filtering remains pattern-driven." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_SA1300_FilePattern"; TargetAsset = "4171-QFU-SA1300-AttachmentPattern"; Status = "not created"; Notes = "Required if budget attachment filtering remains pattern-driven." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_Backorder_FilePattern"; TargetAsset = "4171-QFU-Backorder-AttachmentPattern"; Status = "not created"; Notes = "Required if backorder attachment filtering remains pattern-driven." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_OutlookFolderId"; TargetAsset = "4171-QFU-OutlookFolderSelector"; Status = "not created"; Notes = "Source folder ids must not be reused or hardcoded." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_OneDriveDriveId"; TargetAsset = "4171-QFU-OneDriveDriveId"; Status = "not created"; Notes = "Embedded source flow parameter, not yet externalized in target." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_OneDriveFolderPath"; TargetAsset = "4171-QFU-OneDriveFolderPath"; Status = "not created"; Notes = "Embedded source flow parameter, not yet externalized in target." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_OfficeScriptId"; TargetAsset = "4171-QFU-OfficeScriptId"; Status = "not created"; Notes = "Embedded source flow parameter, not yet externalized in target." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_ActiveFiscalYear"; TargetAsset = "4171-QFU-ActiveFiscalYear"; Status = "not created"; Notes = "Embedded budget flow parameter, not yet externalized in target." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_OverdueDays"; TargetAsset = "4171-QFU-OverdueDays"; Status = "not created"; Notes = "Embedded queue-state threshold, should move to config." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_ExpiringSoonDays"; TargetAsset = "4171-QFU-ExpiringSoonDays"; Status = "not created"; Notes = "Embedded queue-state threshold, should move to config." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_ExpireDays"; TargetAsset = "4171-QFU-ExpireDays"; Status = "not created"; Notes = "Embedded queue-state threshold, should move to config." },
  [pscustomobject]@{ OldAsset = "qfu_QFU_DefaultNextFollowupDays"; TargetAsset = "4171-QFU-DefaultNextFollowupDays"; Status = "not created"; Notes = "Embedded queue-state threshold, should move to config." }
)

$readmeLines = @(
  "# Phase 1 Review Bundle",
  "",
  "- Project name: Quote Follow Up Regional Rollout",
  "- Phase objective: Make Calgary / 4171 genuinely functional in the new environment without redesigning the approved Phase 0 shell.",
  "- Target environment URL: $targetEnvironmentUrl",
  "- Target site URL: $targetSiteUrl",
  "- Source UX environment URL: $sourceUxEnvironmentUrl",
  "- Source UX site URL: $sourceUxSiteUrl",
  "- Source flow environment URL (read-only): $sourceFlowEnvironmentUrl",
  "- Source flow Power Automate URL (read-only): $sourceFlowPowerAutomateUrl",
  "",
  "## What Became Live",
  "",
  "- No Calgary user-facing widget or route is honestly live in the target site as of March 31, 2026.",
  "- Prototype Calgary data exists in target Dataverse tables (qfu_quote, qfu_backorder, qfu_budget) through a direct sync reference path only.",
  "- That prototype data path is not the required solution-aware Calgary flow backbone and is not being represented as completed Phase 1 functionality.",
  "",
  "## What Remains Locked",
  "",
  "- 4171 Calgary Home remains locked because the target portal API cannot read the target QFU tables for the authenticated user.",
  "- 4171 Follow-up Queue, Quotes, Overdue Quotes, and Overdue Backorders remain locked because no verified target 4171-* solution-aware flow family is deployed.",
  "- Team Progress, Workload, and Analytics remain locked by design in this phase.",
  "- 4172 Lethbridge, 4173 Medicine Hat, Northern Alberta, Saskatchewan, and Ops/Admin remain locked.",
  "",
  "## Functional Conclusion",
  "",
  "- Calgary is not yet truly functional in the target environment.",
  "- The approved Phase 0 UI structure was not redesigned during this review build.",
  "- This bundle is an honest fail-state Phase 1 audit snapshot, not a claim of migration completion."
)
Write-Utf8File -Path (Join-Path $bundleRoot "README_PHASE1_REVIEW.md") -Content (Join-Lines $readmeLines)

$flowSummaryLines = @(
  "# Flow Migration Summary",
  "",
  "## Source Calgary Flows Inspected",
  ""
)
foreach ($flow in $inspectedFlowDetails) {
  $flowSummaryLines += "- $($flow.SourceName): $($flow.Purpose)"
}
$flowSummaryLines += @(
  "",
  "## Migrated/Recreated Target Flows Verified",
  "",
  "- None. pac solution list in the target environment still returns only the default solutions, and no 4171-prefixed target flow family was verified.",
  "",
  "## Child Flows Created",
  "",
  "- None verified in the target environment.",
  "",
  "## Excluded Old Flows",
  ""
)
foreach ($flow in $excludedFlowDetails) {
  $flowSummaryLines += "- $($flow.SourceName): $($flow.Notes[0])"
}
$flowSummaryLines += @(
  "",
  "## Conclusion",
  "",
  "- Calgary flow migration into a new target solution has not yet been completed.",
  "- The target environment therefore does not satisfy the Phase 1 requirement for solution-aware parent/child Calgary flows."
)
Write-Utf8File -Path (Join-Path $bundleRoot "FLOW_MIGRATION_SUMMARY.md") -Content (Join-Lines $flowSummaryLines)

$sourceFlowLines = @(
  "# Source Flow Reference",
  "",
  "- Source flow environment: $sourceFlowEnvironmentName",
  "- Source flow environment URL: $sourceFlowEnvironmentUrl",
  "- Source flow Power Automate URL: $sourceFlowPowerAutomateUrl",
  "- Read-only rule observed: yes",
  "- Source environment actions taken: inspect, pac solution list, pac solution export, pac solution unpack, local workflow JSON analysis",
  "- Source environment actions not taken: no edits, no renames, no disables, no connection changes, no environment variable changes, no trigger repointing",
  "",
  "## Inspected Calgary Flow Set",
  ""
)
foreach ($flow in $inspectedFlowDetails) {
  $sourceFlowLines += "- $($flow.SourceName)"
  $sourceFlowLines += "  Purpose: $($flow.Purpose)"
  $sourceFlowLines += "  Source file: $($flow.SourceFile)"
  foreach ($trigger in $flow.TriggerSummary) {
    $sourceFlowLines += "  Trigger: $trigger"
  }
}
Write-Utf8File -Path (Join-Path $bundleRoot "SOURCE_FLOW_REFERENCE.md") -Content (Join-Lines $sourceFlowLines)

$targetFlowMapLines = @(
  "# Target Flow Map",
  "",
  "| Source flow | Target flow | Status | Mode | Reason |",
  "| --- | --- | --- | --- | --- |"
)
foreach ($flow in $inspectedFlowDetails) {
  $targetName = if ($flow.TargetName) { $flow.TargetName } else { "(excluded)" }
  $reason = if ($flow.Status -eq "excluded") {
    "Debug/test-only flow excluded from production Calgary path."
  } else {
    "No target QFU solution or 4171-prefixed flow was verified in $targetEnvironmentUrl."
  }
  $targetFlowMapLines += "| $($flow.SourceName) | $targetName | $($flow.Status) | $($flow.MigrationType) | $reason |"
}
Write-Utf8File -Path (Join-Path $bundleRoot "TARGET_FLOW_MAP.md") -Content (Join-Lines $targetFlowMapLines)

$namingLines = @(
  "# Naming Standard",
  "",
  "## Required Pattern",
  "",
  "- Flows: 4171-<FunctionalName>",
  "- Future branches: 4172-<FunctionalName>, 4173-<FunctionalName>",
  "- The same branch-prefix discipline should be used for child flows, environment variable display names, connection reference display names, config labels, and audit/runbook assets where practical.",
  "",
  "## Planned Calgary Flow Names",
  ""
)
foreach ($flow in $nonExcludedFlowDetails) {
  $namingLines += "- $($flow.TargetName)"
}
$namingLines += @(
  "",
  "## 4171-Prefixed Assets Verified In Target Environment",
  "",
  "- None. No 4171-prefixed target flow, environment variable, or connection reference was verified in the target environment during this audit."
)
Write-Utf8File -Path (Join-Path $bundleRoot "NAMING_STANDARD.md") -Content (Join-Lines $namingLines)

$connectionsLines = @(
  "# Connections And Variables",
  "",
  "## Source Connection References",
  "",
  "| Logical name | Connector id |",
  "| --- | --- |"
)
foreach ($item in $sourceConnectionReferences) {
  $connectionsLines += "| $($item.LogicalName) | $($item.ConnectorId) |"
}
$connectionsLines += @(
  "",
  "## Source Environment Variables",
  "",
  "| Schema name | Default value |",
  "| --- | --- |"
)
foreach ($item in $sourceEnvironmentVariables) {
  $defaultValue = if ($null -eq $item.DefaultValue -or $item.DefaultValue -eq "") { "(blank)" } else { [string]$item.DefaultValue }
  $connectionsLines += "| $($item.SchemaName) | $defaultValue |"
}
$connectionsLines += @(
  "",
  "## Old-To-New Dependency Map",
  "",
  "| Source dependency | Required target replacement | Status | Notes |",
  "| --- | --- | --- | --- |"
)
foreach ($item in $targetReplacementMap) {
  $connectionsLines += "| $($item.OldAsset) | $($item.TargetAsset) | $($item.Status) | $($item.Notes) |"
}
Write-Utf8File -Path (Join-Path $bundleRoot "CONNECTIONS_AND_VARIABLES.md") -Content (Join-Lines $connectionsLines)

$bindingLines = @(
  "# Dataverse Binding Map",
  "",
  "- There are no honestly live Calgary widgets or routes in the target site as of March 31, 2026.",
  "- The matrix below shows the intended Calgary Phase 1 bindings and the current locked state.",
  "",
  "| Surface | Intended target table(s) | Intended target flow(s) | Current state | Current truth |",
  "| --- | --- | --- | --- | --- |",
  "| 4171 Home / Quote workbench table | qfu_quote | 4171-QuoteFollowUp-Import-Staging, 4171-QFU-RecalculateQueueState | locked | Target portal API returns 403 for qfu_quote; no target 4171 flow family verified. |",
  "| 4171 Home / Budget progress | qfu_budget | 4171-Budget-Update-SA1300 | locked | Prototype budget rows exist, but the target site cannot read qfu_budget and no target flow migration was verified. |",
  "| 4171 Home / Quotes last 30 days | qfu_quote | 4171-QuoteFollowUp-Import-Staging, 4171-QFU-RecalculateQueueState | locked | Same blocker as quote workbench table. |",
  "| 4171 Home / Forecast this month | qfu_backorder | 4171-BackOrder-Update-ZBO | locked | Target portal API returns 403 for qfu_backorder; no target 4171 flow family verified. |",
  "| 4171 Home / Late this month | qfu_backorder | 4171-BackOrder-Update-ZBO | locked | Same blocker as forecast module. |",
  "| 4171 Home / Backorder summary | qfu_backorder | 4171-BackOrder-Update-ZBO | locked | Same blocker as forecast module. |",
  "| 4171 Follow-up Queue route | qfu_quote | 4171-QuoteFollowUp-Import-Staging, 4171-QFU-RecalculateQueueState | locked | Detail route not unlocked because the data source is not live. |",
  "| 4171 Quotes route | qfu_quote | 4171-QuoteFollowUp-Import-Staging, 4171-QFU-BackfillHeaderFollowUp, 4171-QFU-CloseQuoteWhenAnyLineWon | locked | Detail route not unlocked because the data source is not live. |",
  "| 4171 Overdue Quotes route | qfu_quote | 4171-QuoteFollowUp-Import-Staging, 4171-QFU-RecalculateQueueState | locked | Detail route not unlocked because the data source is not live. |",
  "| 4171 Overdue Backorders route | qfu_backorder | 4171-BackOrder-Update-ZBO | locked | Detail route not unlocked because the data source is not live. |",
  "| 4171 Team Progress | none verified | none verified | locked | Explicitly out of live scope for this phase. |",
  "| 4171 Workload | none verified | none verified | locked | Explicitly out of live scope for this phase. |",
  "| 4171 Analytics | none verified | none verified | locked | Explicitly out of live scope for this phase. |"
)
Write-Utf8File -Path (Join-Path $bundleRoot "DATAVERSE_BINDING_MAP.md") -Content (Join-Lines $bindingLines)

$configLines = @(
  "# Config And Seed Data",
  "",
  "## Required Config / Seed Scope",
  "",
  "- Calgary branch to Southern Alberta region mapping in target Dataverse",
  "- Branch-scoped threshold/config records for queue aging and follow-up cadence",
  "- Source family mapping for SP830CA, ZBO, and SA1300",
  "- Any target Power Pages role/table-permission wiring needed for live read access",
  "- Connection reference and environment variable values for target flows",
  "",
  "## What Was Created / Verified",
  "",
  "- Prototype target rows were synced into qfu_quote, qfu_backorder, and qfu_budget as recorded in TARGET_DATA_REFERENCE/phase1-calgary-sync-summary.json.",
  "- The sync summary currently reports 609 quotes, 531 backorders, and 3 budget rows in the target environment.",
  "- The target site export includes table-permission artifacts for qfu_quote, qfu_backorder, and qfu_budget.",
  "",
  "## What Remains Manual / Unverified",
  "",
  "- No target QFU solution was verified.",
  "- No target Calgary flow family was verified.",
  "- No target environment-variable values were verified.",
  "- No target connection references were verified.",
  "- No explicit target branch/region config row for Calgary was verified.",
  "- The target portal API still returns 403 for the target QFU tables, so the effective read path is not complete.",
  "",
  "## Calgary Branch / Region Mapping",
  "",
  "- UX mapping is present: Southern Alberta -> 4171 Calgary.",
  "- Dataverse/config mapping is not yet proven in the target environment."
)
Write-Utf8File -Path (Join-Path $bundleRoot "CONFIG_AND_SEED_DATA.md") -Content (Join-Lines $configLines)

$cutoverLines = @(
  "# Cutover And Trigger State",
  "",
  "## Trigger State",
  "",
  "- Target Calgary live triggers verified: none",
  "- Target Calgary live triggers enabled: none",
  "- Source Calgary live path status: still exists only in the read-only source environment",
  "",
  "## Duplicate-Processing Prevention",
  "",
  "- The source mailboxes are shared between old and new paths.",
  "- No target mailbox-triggered Calgary flow family was created or enabled in this audit state.",
  "- Prototype target data was loaded through a direct sync/reference script only, which avoids turning on uncontrolled duplicate live ingestion in the target environment.",
  "- The source flow environment was not modified.",
  "",
  "## Exact Current Cutover Position",
  "",
  "1. Source flow family inspected and exported from the read-only source environment.",
  "2. Prototype Calgary data synced into target Dataverse for reference only.",
  "3. Target site export and live screenshots collected.",
  "4. Portal API probe still fails with 403 on target QFU tables.",
  "5. Because safe dedupe and live target flow migration are not yet proven, Calgary remains locked.",
  "",
  "## Required Safe Cutover Path Still Outstanding",
  "",
  "1. Create a target QFU solution.",
  "2. Recreate/import the Calgary flow family in-solution with 4171-prefixed names.",
  "3. Replace old dependencies with target connection references and environment variables.",
  "4. Verify target Dataverse schema and config rows.",
  "5. Validate via manual/sample runs while target triggers stay off.",
  "6. Prove target portal read path works.",
  "7. Only then enable live Calgary triggers in the target environment."
)
Write-Utf8File -Path (Join-Path $bundleRoot "CUTOVER_AND_TRIGGER_STATE.md") -Content (Join-Lines $cutoverLines)

$matrixLines = @(
  "# Live Vs Locked Matrix",
  "",
  "| Surface | Status | Evidence |",
  "| --- | --- | --- |",
  "| Southern Alberta region | partial | Region shell is live on the target site, but Calgary and the other branches are not truly functional. |",
  "| 4171 Calgary | locked | Live screenshots show locked messaging and the portal API returns 403 for target QFU tables. |",
  "| 4172 Lethbridge | locked | Approved shell remains intentionally locked in this phase. |",
  "| 4173 Medicine Hat | locked | Approved shell remains intentionally locked in this phase. |",
  "| Follow-up Queue | locked | No verified target 4171 flow family and no working portal read path. |",
  "| Quotes | locked | No verified target 4171 flow family and no working portal read path. |",
  "| Overdue Quotes | locked | No verified target 4171 flow family and no working portal read path. |",
  "| Overdue Backorders | locked | No verified target 4171 flow family and no working portal read path. |",
  "| Team Progress | locked | Explicitly out of live Phase 1 scope. |",
  "| Workload | locked | Explicitly out of live Phase 1 scope. |",
  "| Analytics | locked | Explicitly out of live Phase 1 scope. |"
)
Write-Utf8File -Path (Join-Path $bundleRoot "LIVE_VS_LOCKED_MATRIX.md") -Content (Join-Lines $matrixLines)

$uiNoteLines = @(
  "# No UI Redesign Note",
  "",
  "- Phase 1 review work did not redesign the approved Phase 0 Hub, Region page, or branch page.",
  "- The canonical branch pattern remains the compact 4171 Calgary workbench described in TARGET_DATA_REFERENCE/CANONICAL_BRANCH_PATTERN.md.",
  "- This audit bundle only captures evidence, bindings, flow-migration status, and locked/live truth for the existing approved UI structure."
)
Write-Utf8File -Path (Join-Path $bundleRoot "NO_UI_REDESIGN_NOTE.md") -Content (Join-Lines $uiNoteLines)

$commandsRunLines = @(
  "# Commands Run",
  "",
  "pac solution list --environment $targetEnvironmentUrl",
  "pac solution list --environment $sourceFlowEnvironmentUrl",
  "pac solution export --environment $sourceFlowEnvironmentUrl --name QuoteFollowUpSystemUnmanaged --path .\\results\\QuoteFollowUpSystemUnmanaged_source4171.zip --overwrite",
  "pac solution unpack --zipfile .\\results\\QuoteFollowUpSystemUnmanaged_source4171.zip --folder .\\results\\source4171-solution-unpacked --packagetype Unmanaged",
  "& $nodeExe $captureScript <target-url> <out-file> $storageStatePath 3000",
  "Archive/playwright/scripts/probe-portal-api.js with PLAYWRIGHT_BASE_URL=$($targetSiteUrl.TrimEnd('/'))"
)
Write-Utf8File -Path (Join-Path $logsRoot "commands_run.txt") -Content (Join-Lines $commandsRunLines)

$buildNotesLines = @(
  "# Build Notes",
  "",
  "- Date: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss zzz")",
  "- Bundle purpose: honest Calgary Phase 1 audit state against the target environment",
  "- Target environment result: no QFU solution verified",
  "- Source flow environment result: QuoteFollowUpSystemUnmanaged 1.0.0.26 exported/unpacked locally and treated as read-only",
  "- Portal API probe summary:",
  ""
)
$buildNotesLines += $probeSummaryLines
$buildNotesLines += @(
  "",
  "- Practical conclusion: prototype target data exists, but Calgary is still not truly functional on the target site."
)
Write-Utf8File -Path (Join-Path $logsRoot "build_notes.md") -Content (Join-Lines $buildNotesLines)

Compress-Archive -Path $bundleRoot -DestinationPath $zipPath -Force

Ensure-Directory $verifyRoot
Expand-Archive -LiteralPath $zipPath -DestinationPath $verifyRoot -Force

$verifyBundleRoot = Join-Path $verifyRoot $bundleName
if (-not (Test-Path -LiteralPath $verifyBundleRoot)) {
  throw "Expanded bundle root missing: $verifyBundleRoot"
}

foreach ($file in $requiredRootFiles) {
  $path = Join-Path $verifyBundleRoot $file
  if (-not (Test-Path -LiteralPath $path)) {
    throw "Required bundle file missing after zip verification: $file"
  }
}

foreach ($shot in $screenshotTargets) {
  $path = Join-Path (Join-Path $verifyBundleRoot "SCREENSHOTS") $shot.Name
  if (-not (Test-Path -LiteralPath $path)) {
    throw "Required screenshot missing after zip verification: $($shot.Name)"
  }
}

Write-Host "BUNDLE_ROOT=$bundleRoot"
Write-Host "ZIP_PATH=$zipPath"
