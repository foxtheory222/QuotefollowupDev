param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$TargetEnvironmentName = "9f2e54c6-c349-e7e1-ac7c-010d3adf3c03",
  [string]$Username = "smcfarlane@applied.com",
  [string]$TemplateWorkflowId = "a5a911cc-1d2d-4e5a-b0ab-da6f52def8b0",
  [string]$OutputJson = "results\\southern-alberta-flow-repair-summary.json",
  [string[]]$WorkflowIds = @(),
  [switch]$Activate = $true
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Import-Module Microsoft.PowerApps.PowerShell
Import-Module Microsoft.PowerApps.Administration.PowerShell

$canonicalFlows = @(
  [pscustomobject]@{ DisplayName = "4171-QuoteFollowUp-Import-Staging"; WorkflowId = "0aff92f1-a8f0-45d7-b05c-3afe5ade9ed1" },
  [pscustomobject]@{ DisplayName = "4171-BackOrder-Update-ZBO"; WorkflowId = "94ae1bae-fe22-455e-bf63-24ba92644dc0" },
  [pscustomobject]@{ DisplayName = "4171-Budget-Update-SA1300"; WorkflowId = "6db19ff3-c313-4db6-9a57-f3335fe55558" },
  [pscustomobject]@{ DisplayName = "4171-GL060-Inbox-Ingress"; WorkflowId = "fd1ec8dc-56ca-4af7-ab8d-49465802b52a" },
  [pscustomobject]@{ DisplayName = "4172-QuoteFollowUp-Import-Staging"; WorkflowId = "3520a9d9-f40d-430b-aec8-56b9f4c5d96c" },
  [pscustomobject]@{ DisplayName = "4172-BackOrder-Update-ZBO"; WorkflowId = "a5a911cc-1d2d-4e5a-b0ab-da6f52def8b0" },
  [pscustomobject]@{ DisplayName = "4172-Budget-Update-SA1300"; WorkflowId = "078cea4c-84f6-4c4f-b73b-62ad838f7cae" },
  [pscustomobject]@{ DisplayName = "4172-GL060-Inbox-Ingress"; WorkflowId = "7447f66d-93d0-44dd-9bf4-449e320190e7" },
  [pscustomobject]@{ DisplayName = "4173-QuoteFollowUp-Import-Staging"; WorkflowId = "490e1685-4623-461e-ba1c-6c0907a60e33" },
  [pscustomobject]@{ DisplayName = "4173-BackOrder-Update-ZBO"; WorkflowId = "3277dd8e-14f6-4e7b-b627-ebc923ba86ef" },
  [pscustomobject]@{ DisplayName = "4173-Budget-Update-SA1300"; WorkflowId = "3c2ebd80-35d9-4e3c-bdbe-70be98a82ae6" },
  [pscustomobject]@{ DisplayName = "4173-GL060-Inbox-Ingress"; WorkflowId = "cb327979-b304-4b7f-9a42-44c01c959666" }
)

$attributeCache = @{}
$workflowIdSet = New-Object "System.Collections.Generic.HashSet[string]" ([System.StringComparer]::OrdinalIgnoreCase)

function Ensure-Directory {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function ConvertTo-JsonCompact {
  param([object]$Object)
  return ($Object | ConvertTo-Json -Depth 100 -Compress)
}

function Write-ReportFile {
  param(
    [string]$Path,
    [string]$TargetEnvironmentUrl,
    [string]$TargetEnvironmentName,
    [string]$TemplateWorkflowId,
    [string]$TemplateSourceWorkflow,
    [bool]$ActivateRequested,
    [System.Collections.Generic.List[object]]$Summary
  )

  $report = [ordered]@{
    captured_at = (Get-Date).ToUniversalTime().ToString("o")
    target_environment_url = $TargetEnvironmentUrl
    target_environment_name = $TargetEnvironmentName
    template_workflow_id = $TemplateWorkflowId
    template_source_workflow = $TemplateSourceWorkflow
    activate_requested = $ActivateRequested
    flows = @($Summary.ToArray())
  }

  [System.IO.File]::WriteAllText($Path, ($report | ConvertTo-Json -Depth 20), [System.Text.UTF8Encoding]::new($false))
}

function Remove-PropertyIfPresent {
  param(
    [object]$Object,
    [string]$Name
  )

  if ($null -eq $Object) {
    return
  }

  if ($Object -is [System.Collections.IDictionary]) {
    if ($Object.Contains($Name)) {
      $Object.Remove($Name)
    }
    return
  }

  if ($Object.PSObject.Properties[$Name]) {
    $Object.PSObject.Properties.Remove($Name)
  }
}

function Connect-Org {
  param([string]$Url)

  $conn = Connect-CrmOnline -ServerUrl $Url -ForceOAuth -Username $Username
  if (-not $conn -or -not $conn.IsReady) {
    throw "Dataverse connection failed for $Url : $($conn.LastCrmError)"
  }

  return $conn
}

function Get-CanonicalWorkflowPath {
  param(
    [string]$DisplayName,
    [string]$WorkflowId
  )

  $relativePath = "{0}-{1}.json" -f $DisplayName, $WorkflowId.ToUpperInvariant()
  $candidatePaths = @(
    (Join-Path $RepoRoot ("results\\sapilotflows\\src\\Workflows\\{0}" -f $relativePath)),
    (Join-Path $RepoRoot ("results\\sagl060flows\\src\\Workflows\\{0}" -f $relativePath))
  )

  foreach ($path in $candidatePaths) {
    if (Test-Path -LiteralPath $path) {
      return $path
    }
  }

  return $candidatePaths[0]
}

function Get-EntityFieldSet {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName
  )

  if (-not $attributeCache.ContainsKey($EntityLogicalName)) {
    $set = New-Object "System.Collections.Generic.HashSet[string]" ([System.StringComparer]::OrdinalIgnoreCase)
    $attributes = @(Get-CrmEntityAttributes -conn $Connection -EntityLogicalName $EntityLogicalName | Select-Object -ExpandProperty LogicalName)
    foreach ($attribute in $attributes) {
      [void]$set.Add([string]$attribute)
    }
    $attributeCache[$EntityLogicalName] = $set
  }

  return $attributeCache[$EntityLogicalName]
}

function Test-FieldSupported {
  param(
    [System.Collections.Generic.HashSet[string]]$FieldSet,
    [string]$FieldName
  )

  $logicalName = if ($FieldName -like "*@*") { $FieldName.Split("@")[0] } else { $FieldName }
  return $FieldSet.Contains($logicalName)
}

function Resolve-MetadataEntityLogicalName {
  param([string]$EntityName)

  $entityMap = @{
    "qfu_quotes" = "qfu_quote"
    "qfu_quotelines" = "qfu_quoteline"
    "qfu_backorders" = "qfu_backorder"
    "qfu_deliverynotpgis" = "qfu_deliverynotpgi"
    "qfu_budgets" = "qfu_budget"
    "qfu_budgetarchives" = "qfu_budgetarchive"
    "qfu_ingestionbatchs" = "qfu_ingestionbatch"
    "qfu_rawdocuments" = "qfu_rawdocument"
  }

  if ($entityMap.ContainsKey($EntityName)) {
    return $entityMap[$EntityName]
  }

  return $EntityName
}

function Get-TemplateConnectionBindings {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$WorkflowId
  )

  $workflow = Get-CrmRecord -conn $Connection -EntityLogicalName workflow -Id $WorkflowId -Fields clientdata, name
  if (-not $workflow.clientdata) {
    throw "Workflow $WorkflowId does not have clientdata."
  }

  $clientData = $workflow.clientdata | ConvertFrom-Json
  $hostConnectionMap = @{}

  function Walk-Hosts {
    param([object]$Node)

    if ($null -eq $Node) {
      return
    }

    if ($Node -is [System.Collections.IEnumerable] -and -not ($Node -is [string])) {
      foreach ($item in $Node) {
        Walk-Hosts -Node $item
      }
      return
    }

    if ($Node -is [System.Management.Automation.PSCustomObject]) {
      if ($Node.PSObject.Properties["inputs"] -and $Node.inputs -and $Node.inputs.PSObject.Properties["host"]) {
        $hostInfo = $Node.inputs.host
        if ($hostInfo.apiId -and $hostInfo.connectionName) {
          $hostConnectionMap[[string]$hostInfo.apiId] = [string]$hostInfo.connectionName
        }
      }

      foreach ($property in $Node.PSObject.Properties) {
        Walk-Hosts -Node $property.Value
      }
    }
  }

  Walk-Hosts -Node $clientData.properties.definition

  return [pscustomobject]@{
    connectionReferences = $clientData.properties.connectionReferences
    hostConnectionMap = $hostConnectionMap
    sourceWorkflowName = $workflow.name
  }
}

function Sync-QfuSharedConnectionReferences {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$TemplateBindings
  )

  $records = @((Get-CrmRecords -conn $Connection -EntityLogicalName connectionreference -Fields connectionreferenceid, connectionreferencelogicalname, connectionid, connectorid -TopCount 200).CrmRecords)
  $recordMap = @{}
  foreach ($record in $records) {
    $recordMap[[string]$record.connectionreferencelogicalname] = $record
  }

  foreach ($reference in $TemplateBindings.connectionReferences.PSObject.Properties) {
    $templateLogicalName = [string]$reference.Value.connection.connectionReferenceLogicalName
    $templateRecord = $recordMap[$templateLogicalName]
    if (-not $templateRecord -or [string]::IsNullOrWhiteSpace([string]$templateRecord.connectionid)) {
      throw "Template connection reference is not bound: $templateLogicalName"
    }

    $targetLogicalName = "qfu_" + [string]$reference.Value.api.name
    $targetRecord = $recordMap[$targetLogicalName]
    if (-not $targetRecord) {
      throw "Target qfu connection reference not found: $targetLogicalName"
    }

    if ([string]$targetRecord.connectionid -ne [string]$templateRecord.connectionid) {
      Set-CrmRecord -conn $Connection -EntityLogicalName connectionreference -Id $targetRecord.connectionreferenceid -Fields @{ connectionid = [string]$templateRecord.connectionid } | Out-Null
      $targetRecord.connectionid = [string]$templateRecord.connectionid
    }
  }
}

function Normalize-Connections {
  param(
    [object]$WorkflowJson,
    [object]$TemplateBindings
  )

  $WorkflowJson.properties.connectionReferences = $TemplateBindings.connectionReferences

  function Walk-Nodes {
    param([object]$Node)

    if ($null -eq $Node) {
      return
    }

    if ($Node -is [System.Collections.IEnumerable] -and -not ($Node -is [string])) {
      foreach ($item in $Node) {
        Walk-Nodes -Node $item
      }
      return
    }

    if ($Node -is [System.Management.Automation.PSCustomObject]) {
      if ($Node.PSObject.Properties["type"] -and [string]$Node.type -eq "OpenApiConnectionNotification") {
        Remove-PropertyIfPresent -Object $Node -Name "recurrence"
      }

      if ($Node.PSObject.Properties["inputs"] -and $Node.inputs -and $Node.inputs.PSObject.Properties["host"]) {
        $hostInfo = $Node.inputs.host
        $apiId = [string]$hostInfo.apiId
        if ($apiId -and $TemplateBindings.hostConnectionMap.ContainsKey($apiId)) {
          $hostInfo.connectionName = $TemplateBindings.hostConnectionMap[$apiId]
        }
      }

      foreach ($property in $Node.PSObject.Properties) {
        Walk-Nodes -Node $property.Value
      }
    }
  }

  Walk-Nodes -Node $WorkflowJson.properties.definition
}

function Sanitize-DataverseActions {
  param(
    [object]$WorkflowJson,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection
  )

  $removedFields = New-Object System.Collections.Generic.List[string]

  function Walk-Nodes {
    param([object]$Node)

    if ($null -eq $Node) {
      return
    }

    if ($Node -is [System.Collections.IEnumerable] -and -not ($Node -is [string])) {
      foreach ($item in $Node) {
        Walk-Nodes -Node $item
      }
      return
    }

    if ($Node -isnot [System.Management.Automation.PSCustomObject]) {
      return
    }

    if (
      $Node.PSObject.Properties["type"] -and
      [string]$Node.type -eq "OpenApiConnection" -and
      $Node.PSObject.Properties["inputs"] -and
      $Node.inputs -and
      $Node.inputs.PSObject.Properties["host"] -and
      [string]$Node.inputs.host.apiId -eq "/providers/Microsoft.PowerApps/apis/shared_commondataserviceforapps" -and
      $Node.inputs.PSObject.Properties["parameters"] -and
      $Node.inputs.parameters -and
      $Node.inputs.parameters.PSObject.Properties["entityName"]
    ) {
      $entityName = [string]$Node.inputs.parameters.entityName
      $metadataEntityLogicalName = Resolve-MetadataEntityLogicalName -EntityName $entityName
      if ($metadataEntityLogicalName -like "qfu_*") {
        $fieldSet = Get-EntityFieldSet -Connection $Connection -EntityLogicalName $metadataEntityLogicalName

        foreach ($propertyName in @($Node.inputs.parameters.PSObject.Properties.Name | Where-Object { $_ -like "item/*" })) {
          $fieldName = $propertyName.Substring(5)
          if (-not (Test-FieldSupported -FieldSet $fieldSet -FieldName $fieldName)) {
            Remove-PropertyIfPresent -Object $Node.inputs.parameters -Name $propertyName
            $removedFields.Add("$metadataEntityLogicalName.$fieldName") | Out-Null
          }
        }

        if ($Node.inputs.parameters.PSObject.Properties["item"] -and $Node.inputs.parameters.item) {
          foreach ($propertyName in @($Node.inputs.parameters.item.PSObject.Properties.Name)) {
            if (($propertyName -like "qfu_*" -or $propertyName -like "*@odata.bind") -and -not (Test-FieldSupported -FieldSet $fieldSet -FieldName $propertyName)) {
              Remove-PropertyIfPresent -Object $Node.inputs.parameters.item -Name $propertyName
              $removedFields.Add("$metadataEntityLogicalName.$propertyName") | Out-Null
            }
          }
        }
      }
    }

    foreach ($property in $Node.PSObject.Properties) {
      Walk-Nodes -Node $property.Value
    }
  }

  Walk-Nodes -Node $WorkflowJson.properties.definition

  return @($removedFields | Sort-Object -Unique)
}

Ensure-Directory -Path (Split-Path -Parent (Join-Path $RepoRoot $OutputJson))

$generatorScript = Join-Path $RepoRoot "scripts\\create-southern-alberta-pilot-flow-solution.ps1"
& $generatorScript -RepoRoot $RepoRoot -ImportToTarget:$false

$gl060GeneratorScript = Join-Path $RepoRoot "scripts\\create-southern-alberta-gl060-flow-solution.ps1"
& $gl060GeneratorScript -RepoRoot $RepoRoot -ImportToTarget:$false

$connection = Connect-Org -Url $TargetEnvironmentUrl
Add-PowerAppsAccount -Endpoint prod -Username $Username | Out-Null

$templateBindings = Get-TemplateConnectionBindings -Connection $connection -WorkflowId $TemplateWorkflowId
Sync-QfuSharedConnectionReferences -Connection $connection -TemplateBindings $templateBindings
$summary = New-Object System.Collections.Generic.List[object]
$outputPath = Join-Path $RepoRoot $OutputJson

foreach ($workflowId in @($WorkflowIds)) {
  foreach ($candidate in @(([string]$workflowId) -split ",")) {
    $trimmed = [string]$candidate
    if (-not [string]::IsNullOrWhiteSpace($trimmed)) {
      [void]$workflowIdSet.Add($trimmed.Trim())
    }
  }
}

$targetFlows = if ($workflowIdSet.Count -gt 0) {
  @($canonicalFlows | Where-Object { $workflowIdSet.Contains([string]$_.WorkflowId) })
} else {
  $canonicalFlows
}

if ($workflowIdSet.Count -gt 0) {
  $resolvedWorkflowIds = @($targetFlows | ForEach-Object { [string]$_.WorkflowId })
  $missing = @($workflowIdSet | Where-Object { $_ -notin $resolvedWorkflowIds })
  if ($missing.Count -gt 0) {
  throw "Workflow IDs not found in canonical flow list: $($missing -join ', ')"
  }
}

foreach ($flow in $targetFlows) {
  $path = Get-CanonicalWorkflowPath -DisplayName $flow.DisplayName -WorkflowId $flow.WorkflowId
  if (-not (Test-Path -LiteralPath $path)) {
    throw "Canonical workflow source not found: $path"
  }

  $workflowJson = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
  Normalize-Connections -WorkflowJson $workflowJson -TemplateBindings $templateBindings
  $removedFields = Sanitize-DataverseActions -WorkflowJson $workflowJson -Connection $connection
  $clientData = ConvertTo-JsonCompact -Object $workflowJson

  $result = [ordered]@{
    display_name = $flow.DisplayName
    workflow_id = $flow.WorkflowId
    source_path = $path
    removed_fields = @($removedFields)
    update = "pending"
    activation = if ($Activate) { "pending" } else { "skipped" }
  }

  try {
    Set-CrmRecord -conn $connection -EntityLogicalName workflow -Id $flow.WorkflowId -Fields @{ clientdata = $clientData } | Out-Null
    $result.update = "updated"
  } catch {
    $result.update = "failed"
    $result.update_error = $_.Exception.Message
  }

  if ($Activate -and $result.update -eq "updated") {
    try {
      Set-CrmRecordState -conn $connection -EntityLogicalName workflow -Id $flow.WorkflowId -StateCode Activated -StatusCode Activated | Out-Null
      $result.activation = "activated"
    } catch {
      $result.activation = "failed"
      $result.activation_error = $_.Exception.Message
    }
  }

  $summary.Add([pscustomobject]$result) | Out-Null
  Write-ReportFile -Path $outputPath -TargetEnvironmentUrl $TargetEnvironmentUrl -TargetEnvironmentName $TargetEnvironmentName -TemplateWorkflowId $TemplateWorkflowId -TemplateSourceWorkflow $templateBindings.sourceWorkflowName -ActivateRequested ([bool]$Activate) -Summary $summary
}

$adminFlowMap = @{}
foreach ($adminFlow in @(Get-AdminFlow -EnvironmentName $TargetEnvironmentName | Where-Object { $_.WorkflowEntityId -in $targetFlows.WorkflowId })) {
  $adminFlowMap[[string]$adminFlow.WorkflowEntityId] = $adminFlow
}

foreach ($result in $summary) {
  if ($adminFlowMap.ContainsKey([string]$result.workflow_id)) {
    $adminFlow = $adminFlowMap[[string]$result.workflow_id]
    $result | Add-Member -NotePropertyName enabled -NotePropertyValue ([bool]$adminFlow.Enabled) -Force
    $result | Add-Member -NotePropertyName last_modified_time -NotePropertyValue $adminFlow.LastModifiedTime -Force
    $result | Add-Member -NotePropertyName flow_name -NotePropertyValue $adminFlow.FlowName -Force
  }
}

Write-ReportFile -Path $outputPath -TargetEnvironmentUrl $TargetEnvironmentUrl -TargetEnvironmentName $TargetEnvironmentName -TemplateWorkflowId $TemplateWorkflowId -TemplateSourceWorkflow $templateBindings.sourceWorkflowName -ActivateRequested ([bool]$Activate) -Summary $summary

$summary | Select-Object display_name, workflow_id, update, activation, enabled | Format-Table -AutoSize
Write-Host "OUTPUT_PATH=$outputPath"
