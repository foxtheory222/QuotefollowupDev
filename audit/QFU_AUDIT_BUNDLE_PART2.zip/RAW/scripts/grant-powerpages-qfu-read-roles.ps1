param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com"
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Add-Type -AssemblyName "Microsoft.Xrm.Sdk"

$permissionIds = @(
  "1b488c88-5727-41ff-a25e-c5785b72d474", # qfu_quote
  "0d108fe0-b734-4108-910b-a99477522552", # qfu_backorder
  "fb62dfc4-53df-4903-b151-0f09da10c77c", # qfu_budget
  "96585e97-fb6f-4b96-a404-72ec233f0fef"  # qfu_branchdailysummary
)

$roleIds = @(
  "0d42a052-4ceb-4d02-bfb1-eea0860bcae9", # Authenticated Users
  "d1681251-ec76-4138-b394-038772b4aa90"  # Administrators
)

$conn = Connect-CrmOnline -ServerUrl $TargetEnvironmentUrl -ForceOAuth -Username $Username
if (-not $conn -or -not $conn.IsReady) {
  throw "Dataverse connection failed for $TargetEnvironmentUrl : $($conn.LastCrmError)"
}

function Add-WebRoleAssociation {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [guid]$PermissionId,
    [guid]$RoleId
  )

  $request = [Microsoft.Xrm.Sdk.Messages.AssociateRequest]::new()
  $request.Target = [Microsoft.Xrm.Sdk.EntityReference]::new("mspp_entitypermission", $PermissionId)
  $request.Relationship = [Microsoft.Xrm.Sdk.Relationship]::new("mspp_entitypermission_webrole")
  $request.RelatedEntities = [Microsoft.Xrm.Sdk.EntityReferenceCollection]::new()
  $request.RelatedEntities.Add([Microsoft.Xrm.Sdk.EntityReference]::new("mspp_webrole", $RoleId))

  try {
    $null = $Connection.Execute($request)
    Write-Host "Associated permission $PermissionId -> role $RoleId"
  } catch {
    $message = $_.Exception.Message
    if ($message -like "*matching key values already exists*" -or $message -like "*Cannot insert duplicate key*" -or $message -like "*already exists*") {
      Write-Host "Association already exists: $PermissionId -> $RoleId"
      return
    }
    throw
  }
}

foreach ($permissionId in $permissionIds) {
  foreach ($roleId in $roleIds) {
    Add-WebRoleAssociation -Connection $conn -PermissionId ([guid]$permissionId) -RoleId ([guid]$roleId)
  }
}
