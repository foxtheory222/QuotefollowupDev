const fs = require("fs");
const path = require("path");

const playwrightRoot = path.resolve(__dirname, "..", "Archive", "playwright", "node_modules", "playwright");
const { chromium } = require(playwrightRoot);

async function main() {
  const [url, outFile, storageStateArg, waitArg] = process.argv.slice(2);

  if (!url || !outFile) {
    console.error("Usage: node capture-portal-screenshot.cjs <url> <outFile> [storageState] [waitMs]");
    process.exit(2);
  }

  const waitMs = Number.parseInt(waitArg || "2500", 10);
  const viewport = { width: 1600, height: 1800 };
  const outPath = path.resolve(outFile);
  const outputDir = path.dirname(outPath);
  const contextOptions = { viewport };

  if (storageStateArg) {
    contextOptions.storageState = path.resolve(storageStateArg);
  }

  fs.mkdirSync(outputDir, { recursive: true });

  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext(contextOptions);
  const page = await context.newPage();

  let response = null;
  let error = null;

  try {
    response = await page.goto(url, {
      waitUntil: "domcontentloaded",
      timeout: 90_000,
    });
    await page.waitForTimeout(Number.isFinite(waitMs) ? waitMs : 2500);
  } catch (caught) {
    error = {
      name: caught && caught.name ? String(caught.name) : "Error",
      message: caught && caught.message ? String(caught.message) : String(caught),
    };
  }

  await page.screenshot({
    path: outPath,
    fullPage: true,
  });

  const title = await page.title().catch(() => "");
  const finalUrl = page.url();
  const bodyStart = await page
    .locator("body")
    .innerText()
    .then((text) => text.slice(0, 700))
    .catch(() => "");

  const payload = {
    requestedUrl: url,
    finalUrl,
    title,
    status: response ? response.status() : null,
    screenshotPath: outPath,
    storageStatePath: storageStateArg ? path.resolve(storageStateArg) : null,
    bodyStart,
    error,
  };

  console.log(JSON.stringify(payload, null, 2));

  await browser.close();

  if (error) {
    process.exit(1);
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
