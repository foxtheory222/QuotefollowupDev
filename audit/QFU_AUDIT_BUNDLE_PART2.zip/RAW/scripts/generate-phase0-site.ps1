param(
  [string]$SiteRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion\powerpages-live\operations-hub---operationhub"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $SiteRoot)) {
  throw "Site root not found: $SiteRoot"
}

$publishedStateId = "0031c8c3-da10-4b08-b964-4307e321a8a1"
$defaultPageTemplateId = "ca36e40b-5708-40c5-a6ec-baade7c21b8b"
$languageId = "ad09fee1-b57b-41f4-9f9f-1d3c64129ffd"
$homeRootId = "87d75475-3ed8-4bd4-b259-bb8d82e0e676"
$homeContentId = "5a5f473d-db6d-4492-bc5e-048cf88b3605"
$defaultWeblinkSetId = "887d62a7-d0ee-496a-b0eb-370b5f59974f"
$homeWeblinkId = "ffdcc09f-04cd-48e0-96ca-84188caa0de0"

$ids = @{
  southernRegionRoot   = "d0e88772-fdf7-434c-9f65-113f07806203"
  southernRegionContent= "6c2b5df5-7e40-4e54-a248-61c974bdb4d3"
  northernRegionRoot   = "bdd5990a-7797-4751-b87a-573a7c30ccf6"
  northernRegionContent= "6f11b891-08cc-46f7-9826-e2e970887844"
  saskRegionRoot       = "55849863-c97d-46d5-b815-617cb8d4e5ed"
  saskRegionContent    = "f650752e-9c1e-4ec8-916f-00cfaec475c6"
  opsRoot              = "df0adbc8-06dd-4026-86e1-8612075a9e6d"
  opsContent           = "4fd17cae-f4a6-43a8-8285-960a156e1efe"
  calgaryRoot          = "5106a8c2-9817-4f3d-a18c-6e6b3a3ecc17"
  calgaryContent       = "fc79cbcf-5d6f-4274-8f13-56bcf20ae34a"
  lethbridgeRoot       = "34d0a2d9-f805-414e-8821-0f955af88768"
  lethbridgeContent    = "34f9a934-22d3-47cc-a3f9-5d28dc673287"
  medicineHatRoot      = "37cbaf0b-a981-47ed-acdd-a2a2c71cb4a2"
  medicineHatContent   = "066ba319-baa9-45e3-8cc6-03ea4d5faea3"
  calgaryDetailRoot    = "e6ec61e6-dd4b-45cc-ad45-6cb787620945"
  calgaryDetailContent = "44e2bfb6-0e69-4b69-b87d-84efe4fbf561"
  lethbridgeDetailRoot = "8bd50ab0-879b-471a-8d94-6f9b74e2d884"
  lethbridgeDetailContent = "3c006a4c-a367-42dc-9d57-4d9d56a07292"
  medicineHatDetailRoot = "23fb4c09-2dc7-4a23-903b-ff6454d59c15"
  medicineHatDetailContent = "5be01078-9ae2-4137-a091-da5dbbdc424f"
  opsWeblink           = "6774d49e-272d-4d23-a81b-d7f3cbd384cb"
  cssWebfile           = "829abec1-7c68-4d3a-a42b-1484dcc2294c"
  cssAnnotation        = "5c4afdeb-52b2-4354-a1d1-a1d48764350d"
  jsWebfile            = "f8d6df73-bb1f-4433-aa46-dbcaedc930f8"
  jsAnnotation         = "9af47507-cd4d-40eb-9fd5-b4d04461129f"
}

function Ensure-Directory {
  param([string]$Path)
  if (-not (Test-Path $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Write-Utf8File {
  param(
    [string]$Path,
    [string]$Content
  )

  $parent = Split-Path -Parent $Path
  if ($parent) {
    Ensure-Directory $parent
  }

  [System.IO.File]::WriteAllText($Path, $Content, (New-Object System.Text.UTF8Encoding($false)))
}

function New-PageCopy {
  param(
    [string]$PageType,
    [string]$Region = "",
    [string]$Branch = ""
  )

  $attrs = @(
    'class="qfu-phase0-root"',
    'data-qfu-phase0',
    ('data-page="{0}"' -f $PageType)
  )

  if ($Region) {
    $attrs += ('data-region="{0}"' -f $Region)
  }

  if ($Branch) {
    $attrs += ('data-branch="{0}"' -f $Branch)
  }

@"
<link rel="stylesheet" href="/qfu-phase0.css">
<script src="/qfu-phase0.js" defer></script>
<section $($attrs -join ' ')>
  <div class="qfu-phase0-loading">Loading Phase 0 shell...</div>
</section>
"@
}

function Write-PageFiles {
  param(
    [hashtable]$Page,
    [string]$Markup
  )

  $folderPath = Join-Path $SiteRoot ("web-pages\" + $Page.Folder)
  $contentFolder = Join-Path $folderPath "content-pages"
  Ensure-Directory $contentFolder

  $rootYml = @"
adx_displayorder: $($Page.DisplayOrder)
adx_enablerating: false
adx_enabletracking: false
adx_excludefromsearch: false
adx_feedbackpolicy: 756150005
adx_hiddenfromsitemap: $($Page.HiddenFromSiteMap.ToString().ToLowerInvariant())
adx_isroot: true
adx_name: $($Page.Name)
adx_pagetemplateid: $defaultPageTemplateId
$($Page.ParentRootIdLine)adx_partialurl: $($Page.PartialUrl)
adx_publishingstateid: $publishedStateId
adx_sharedpageconfiguration: false
adx_title: $($Page.Title)
adx_webpageid: $($Page.RootId)
"@

  $contentYml = @"
adx_displayorder: $($Page.DisplayOrder)
adx_enablerating: false
adx_enabletracking: false
adx_excludefromsearch: false
adx_feedbackpolicy: 756150005
adx_hiddenfromsitemap: $($Page.HiddenFromSiteMap.ToString().ToLowerInvariant())
adx_isroot: false
adx_name: $($Page.Name)
adx_pagetemplateid: $defaultPageTemplateId
adx_partialurl: $($Page.PartialUrl)
adx_publishingstateid: $publishedStateId
adx_rootwebpageid: $($Page.RootId)
adx_sharedpageconfiguration: false
adx_title: $($Page.Title)
adx_webpageid: $($Page.ContentId)
adx_webpagelanguageid: $languageId
"@

  $blank = ""
  $summary = ""

  Write-Utf8File (Join-Path $folderPath ($Page.FileStem + ".webpage.yml")) $rootYml
  Write-Utf8File (Join-Path $folderPath ($Page.FileStem + ".webpage.copy.html")) $Markup
  Write-Utf8File (Join-Path $folderPath ($Page.FileStem + ".webpage.custom_css.css")) $blank
  Write-Utf8File (Join-Path $folderPath ($Page.FileStem + ".webpage.custom_javascript.js")) $blank
  Write-Utf8File (Join-Path $folderPath ($Page.FileStem + ".webpage.summary.html")) $summary

  Write-Utf8File (Join-Path $contentFolder ($Page.FileStem + ".en-US.webpage.yml")) $contentYml
  Write-Utf8File (Join-Path $contentFolder ($Page.FileStem + ".en-US.webpage.copy.html")) $Markup
  Write-Utf8File (Join-Path $contentFolder ($Page.FileStem + ".en-US.webpage.custom_css.css")) $blank
  Write-Utf8File (Join-Path $contentFolder ($Page.FileStem + ".en-US.webpage.custom_javascript.js")) $blank
  Write-Utf8File (Join-Path $contentFolder ($Page.FileStem + ".en-US.webpage.summary.html")) $summary
}

$css = @'
#CSS_PLACEHOLDER
'@

$js = @'
#JS_PLACEHOLDER
'@

$pages = @(
  @{
    Folder = "home"
    FileStem = "Home"
    Name = "Hub"
    Title = "Regional Operations Hub"
    PartialUrl = "/"
    RootId = $homeRootId
    ContentId = $homeContentId
    DisplayOrder = 1
    HiddenFromSiteMap = $false
    ParentRootIdLine = ""
    Markup = (New-PageCopy -PageType "hub")
  },
  @{
    Folder = "southern-alberta"
    FileStem = "Southern-Alberta"
    Name = "Southern Alberta"
    Title = "Southern Alberta Region"
    PartialUrl = "southern-alberta"
    RootId = $ids.southernRegionRoot
    ContentId = $ids.southernRegionContent
    DisplayOrder = 1
    HiddenFromSiteMap = $false
    ParentRootIdLine = "adx_parentpageid: $homeRootId`n"
    Markup = (New-PageCopy -PageType "region" -Region "southern-alberta")
  },
  @{
    Folder = "northern-alberta"
    FileStem = "Northern-Alberta"
    Name = "Northern Alberta"
    Title = "Northern Alberta Region"
    PartialUrl = "northern-alberta"
    RootId = $ids.northernRegionRoot
    ContentId = $ids.northernRegionContent
    DisplayOrder = 2
    HiddenFromSiteMap = $false
    ParentRootIdLine = "adx_parentpageid: $homeRootId`n"
    Markup = (New-PageCopy -PageType "region" -Region "northern-alberta")
  },
  @{
    Folder = "saskatchewan"
    FileStem = "Saskatchewan"
    Name = "Saskatchewan"
    Title = "Saskatchewan Region"
    PartialUrl = "saskatchewan"
    RootId = $ids.saskRegionRoot
    ContentId = $ids.saskRegionContent
    DisplayOrder = 3
    HiddenFromSiteMap = $false
    ParentRootIdLine = "adx_parentpageid: $homeRootId`n"
    Markup = (New-PageCopy -PageType "region" -Region "saskatchewan")
  },
  @{
    Folder = "ops-admin"
    FileStem = "Ops-Admin"
    Name = "Ops / Admin"
    Title = "Ops / Admin"
    PartialUrl = "ops-admin"
    RootId = $ids.opsRoot
    ContentId = $ids.opsContent
    DisplayOrder = 4
    HiddenFromSiteMap = $false
    ParentRootIdLine = "adx_parentpageid: $homeRootId`n"
    Markup = (New-PageCopy -PageType "ops")
  },
  @{
    Folder = "southern-alberta\4171-calgary"
    FileStem = "4171-Calgary"
    Name = "4171 Calgary"
    Title = "4171 Calgary"
    PartialUrl = "4171-calgary"
    RootId = $ids.calgaryRoot
    ContentId = $ids.calgaryContent
    DisplayOrder = 1
    HiddenFromSiteMap = $true
    ParentRootIdLine = "adx_parentpageid: $($ids.southernRegionRoot)`n"
    Markup = (New-PageCopy -PageType "branch" -Branch "4171-calgary")
  },
  @{
    Folder = "southern-alberta\4172-lethbridge"
    FileStem = "4172-Lethbridge"
    Name = "4172 Lethbridge"
    Title = "4172 Lethbridge"
    PartialUrl = "4172-lethbridge"
    RootId = $ids.lethbridgeRoot
    ContentId = $ids.lethbridgeContent
    DisplayOrder = 2
    HiddenFromSiteMap = $true
    ParentRootIdLine = "adx_parentpageid: $($ids.southernRegionRoot)`n"
    Markup = (New-PageCopy -PageType "branch" -Branch "4172-lethbridge")
  },
  @{
    Folder = "southern-alberta\4173-medicine-hat"
    FileStem = "4173-Medicine-Hat"
    Name = "4173 Medicine Hat"
    Title = "4173 Medicine Hat"
    PartialUrl = "4173-medicine-hat"
    RootId = $ids.medicineHatRoot
    ContentId = $ids.medicineHatContent
    DisplayOrder = 3
    HiddenFromSiteMap = $true
    ParentRootIdLine = "adx_parentpageid: $($ids.southernRegionRoot)`n"
    Markup = (New-PageCopy -PageType "branch" -Branch "4173-medicine-hat")
  },
  @{
    Folder = "southern-alberta\4171-calgary\detail"
    FileStem = "Detail-Shell"
    Name = "Detail Shell"
    Title = "4171 Detail Shell"
    PartialUrl = "detail"
    RootId = $ids.calgaryDetailRoot
    ContentId = $ids.calgaryDetailContent
    DisplayOrder = 1
    HiddenFromSiteMap = $true
    ParentRootIdLine = "adx_parentpageid: $($ids.calgaryRoot)`n"
    Markup = (New-PageCopy -PageType "detail" -Branch "4171-calgary")
  },
  @{
    Folder = "southern-alberta\4172-lethbridge\detail"
    FileStem = "Detail-Shell"
    Name = "Detail Shell"
    Title = "4172 Detail Shell"
    PartialUrl = "detail"
    RootId = $ids.lethbridgeDetailRoot
    ContentId = $ids.lethbridgeDetailContent
    DisplayOrder = 1
    HiddenFromSiteMap = $true
    ParentRootIdLine = "adx_parentpageid: $($ids.lethbridgeRoot)`n"
    Markup = (New-PageCopy -PageType "detail" -Branch "4172-lethbridge")
  },
  @{
    Folder = "southern-alberta\4173-medicine-hat\detail"
    FileStem = "Detail-Shell"
    Name = "Detail Shell"
    Title = "4173 Detail Shell"
    PartialUrl = "detail"
    RootId = $ids.medicineHatDetailRoot
    ContentId = $ids.medicineHatDetailContent
    DisplayOrder = 1
    HiddenFromSiteMap = $true
    ParentRootIdLine = "adx_parentpageid: $($ids.medicineHatRoot)`n"
    Markup = (New-PageCopy -PageType "detail" -Branch "4173-medicine-hat")
  }
)

foreach ($page in $pages) {
  Write-PageFiles -Page $page -Markup $page.Markup
}

$cssWebfileYml = @"
adx_displayorder: 7
adx_enabletracking: false
adx_excludefromsearch: true
adx_hiddenfromsitemap: false
adx_name: qfu-phase0.css
adx_parentpageid: $homeRootId
adx_partialurl: qfu-phase0.css
adx_publishingstateid: $publishedStateId
adx_webfileid: $($ids.cssWebfile)
annotationid: $($ids.cssAnnotation)
filename: qfu-phase0.css
isdocument: true
mimetype: text/css
objectid: $($ids.cssWebfile)
objecttypecode: adx_webfile
"@

$jsWebfileYml = @"
adx_displayorder: 8
adx_enabletracking: false
adx_excludefromsearch: true
adx_hiddenfromsitemap: false
adx_name: qfu-phase0.js
adx_parentpageid: $homeRootId
adx_partialurl: qfu-phase0.js
adx_publishingstateid: $publishedStateId
adx_webfileid: $($ids.jsWebfile)
annotationid: $($ids.jsAnnotation)
filename: qfu-phase0.js
isdocument: true
mimetype: application/javascript
objectid: $($ids.jsWebfile)
objecttypecode: adx_webfile
"@

Write-Utf8File (Join-Path $SiteRoot "web-files\qfu-phase0.css") $css
Write-Utf8File (Join-Path $SiteRoot "web-files\qfu-phase0.css.webfile.yml") $cssWebfileYml
Write-Utf8File (Join-Path $SiteRoot "web-files\qfu-phase0.js") $js
Write-Utf8File (Join-Path $SiteRoot "web-files\qfu-phase0.js.webfile.yml") $jsWebfileYml

$weblinks = @"
- adx_disablepagevalidation: false
  adx_displayimageonly: false
  adx_displayorder: 1
  adx_displaypagechildlinks: false
  adx_name: Hub
  adx_openinnewwindow: false
  adx_pageid: $homeRootId
  adx_publishingstateid: $publishedStateId
  adx_robotsfollowlink: true
  adx_weblinkid: $homeWeblinkId
  adx_weblinksetid: $defaultWeblinkSetId
- adx_disablepagevalidation: false
  adx_displayimageonly: false
  adx_displayorder: 2
  adx_displaypagechildlinks: false
  adx_name: Ops / Admin
  adx_openinnewwindow: false
  adx_pageid: $($ids.opsRoot)
  adx_publishingstateid: $publishedStateId
  adx_robotsfollowlink: true
  adx_weblinkid: $($ids.opsWeblink)
  adx_weblinksetid: $defaultWeblinkSetId
"@

Write-Utf8File (Join-Path $SiteRoot "weblink-sets\default\Default.en-US.weblinkset.weblink.yml") $weblinks
Write-Utf8File (Join-Path $SiteRoot "content-snippets\site-name\Site-name.en-US.contentsnippet.value.html") "Quote Follow Up"

Write-Output "Phase 0 site source generated at $SiteRoot"
