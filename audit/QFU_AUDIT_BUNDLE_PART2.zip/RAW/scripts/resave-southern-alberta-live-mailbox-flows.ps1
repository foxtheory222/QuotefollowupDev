param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$LiveRefreshRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion\results\live-refresh-20260407-074015",
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$TargetEnvironmentName = "9f2e54c6-c349-e7e1-ac7c-010d3adf3c03",
  [string]$Username = "smcfarlane@applied.com",
  [string]$TemplateWorkflowId = "0aff92f1-a8f0-45d7-b05c-3afe5ade9ed1",
  [string]$OutputJson = "results\\live-refresh-20260407-074015\\live-mailbox-flow-resave-summary.json",
  [string[]]$WorkflowIds = @(),
  [switch]$ToggleAfterUpdate = $true
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell
Import-Module Microsoft.PowerApps.Administration.PowerShell

$canonicalFlows = @(
  [pscustomobject]@{ DisplayName = "4171-QuoteFollowUp-Import-Staging"; WorkflowId = "0aff92f1-a8f0-45d7-b05c-3afe5ade9ed1" },
  [pscustomobject]@{ DisplayName = "4171-BackOrder-Update-ZBO"; WorkflowId = "94ae1bae-fe22-455e-bf63-24ba92644dc0" },
  [pscustomobject]@{ DisplayName = "4171-Budget-Update-SA1300"; WorkflowId = "6db19ff3-c313-4db6-9a57-f3335fe55558" },
  [pscustomobject]@{ DisplayName = "4171-GL060-Inbox-Ingress"; WorkflowId = "fd1ec8dc-56ca-4af7-ab8d-49465802b52a" },
  [pscustomobject]@{ DisplayName = "4172-QuoteFollowUp-Import-Staging"; WorkflowId = "3520a9d9-f40d-430b-aec8-56b9f4c5d96c" },
  [pscustomobject]@{ DisplayName = "4172-BackOrder-Update-ZBO"; WorkflowId = "a5a911cc-1d2d-4e5a-b0ab-da6f52def8b0" },
  [pscustomobject]@{ DisplayName = "4172-Budget-Update-SA1300"; WorkflowId = "078cea4c-84f6-4c4f-b73b-62ad838f7cae" },
  [pscustomobject]@{ DisplayName = "4172-GL060-Inbox-Ingress"; WorkflowId = "7447f66d-93d0-44dd-9bf4-449e320190e7" },
  [pscustomobject]@{ DisplayName = "4173-QuoteFollowUp-Import-Staging"; WorkflowId = "490e1685-4623-461e-ba1c-6c0907a60e33" },
  [pscustomobject]@{ DisplayName = "4173-BackOrder-Update-ZBO"; WorkflowId = "3277dd8e-14f6-4e7b-b627-ebc923ba86ef" },
  [pscustomobject]@{ DisplayName = "4173-Budget-Update-SA1300"; WorkflowId = "3c2ebd80-35d9-4e3c-bdbe-70be98a82ae6" },
  [pscustomobject]@{ DisplayName = "4173-GL060-Inbox-Ingress"; WorkflowId = "cb327979-b304-4b7f-9a42-44c01c959666" }
)

$attributeCache = @{}
$workflowIdSet = New-Object "System.Collections.Generic.HashSet[string]" ([System.StringComparer]::OrdinalIgnoreCase)

function Ensure-Directory {
  param([string]$Path)

  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Write-Utf8Json {
  param(
    [string]$Path,
    [object]$Object
  )

  $directory = Split-Path -Parent $Path
  if ($directory) {
    Ensure-Directory -Path $directory
  }

  $json = $Object | ConvertTo-Json -Depth 20
  [System.IO.File]::WriteAllText($Path, $json, [System.Text.UTF8Encoding]::new($false))
}

function ConvertTo-JsonCompact {
  param([object]$Object)

  return ($Object | ConvertTo-Json -Depth 100 -Compress)
}

function Remove-PropertyIfPresent {
  param(
    [object]$Object,
    [string]$Name
  )

  if ($null -eq $Object) {
    return
  }

  if ($Object -is [System.Collections.IDictionary]) {
    if ($Object.Contains($Name)) {
      $Object.Remove($Name)
    }
    return
  }

  if ($Object.PSObject.Properties[$Name]) {
    $Object.PSObject.Properties.Remove($Name)
  }
}

function Connect-Org {
  param([string]$Url)

  $conn = Connect-CrmOnline -ServerUrl $Url -ForceOAuth -Username $Username
  if (-not $conn -or -not $conn.IsReady) {
    throw "Dataverse connection failed for $Url : $($conn.LastCrmError)"
  }

  return $conn
}

function Get-CanonicalWorkflowPath {
  param(
    [string]$DisplayName,
    [string]$WorkflowId
  )

  $relativePath = "{0}-{1}.json" -f $DisplayName, $WorkflowId.ToUpperInvariant()
  $candidatePaths = @(
    (Join-Path $LiveRefreshRoot ("solutions\\qfu_sapilotflows\\Workflows\\{0}" -f $relativePath)),
    (Join-Path $LiveRefreshRoot ("solutions\\qfu_sagl060flows\\Workflows\\{0}" -f $relativePath))
  )

  foreach ($path in $candidatePaths) {
    if (Test-Path -LiteralPath $path) {
      return $path
    }
  }

  throw "Canonical workflow source not found for $DisplayName [$WorkflowId]"
}

function Get-EntityFieldSet {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName
  )

  if (-not $attributeCache.ContainsKey($EntityLogicalName)) {
    $set = New-Object "System.Collections.Generic.HashSet[string]" ([System.StringComparer]::OrdinalIgnoreCase)
    $attributes = @(Get-CrmEntityAttributes -conn $Connection -EntityLogicalName $EntityLogicalName | Select-Object -ExpandProperty LogicalName)
    foreach ($attribute in $attributes) {
      [void]$set.Add([string]$attribute)
    }
    $attributeCache[$EntityLogicalName] = $set
  }

  return $attributeCache[$EntityLogicalName]
}

function Test-FieldSupported {
  param(
    [System.Collections.Generic.HashSet[string]]$FieldSet,
    [string]$FieldName
  )

  $logicalName = if ($FieldName -like "*@*") { $FieldName.Split("@")[0] } else { $FieldName }
  return $FieldSet.Contains($logicalName)
}

function Resolve-MetadataEntityLogicalName {
  param([string]$EntityName)

  $entityMap = @{
    "qfu_quotes" = "qfu_quote"
    "qfu_quotelines" = "qfu_quoteline"
    "qfu_backorders" = "qfu_backorder"
    "qfu_deliverynotpgis" = "qfu_deliverynotpgi"
    "qfu_budgets" = "qfu_budget"
    "qfu_budgetarchives" = "qfu_budgetarchive"
    "qfu_ingestionbatchs" = "qfu_ingestionbatch"
    "qfu_rawdocuments" = "qfu_rawdocument"
  }

  if ($entityMap.ContainsKey($EntityName)) {
    return $entityMap[$EntityName]
  }

  return $EntityName
}

function Get-TemplateConnectionBindings {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$WorkflowId
  )

  $workflow = Get-CrmRecord -conn $Connection -EntityLogicalName workflow -Id $WorkflowId -Fields clientdata, name
  if (-not $workflow.clientdata) {
    throw "Workflow $WorkflowId does not have clientdata."
  }

  $clientData = $workflow.clientdata | ConvertFrom-Json
  $hostConnectionMap = @{}

  function Walk-Hosts {
    param([object]$Node)

    if ($null -eq $Node) {
      return
    }

    if ($Node -is [System.Collections.IEnumerable] -and -not ($Node -is [string])) {
      foreach ($item in $Node) {
        Walk-Hosts -Node $item
      }
      return
    }

    if ($Node -is [System.Management.Automation.PSCustomObject]) {
      if ($Node.PSObject.Properties["inputs"] -and $Node.inputs -and $Node.inputs.PSObject.Properties["host"]) {
        $hostInfo = $Node.inputs.host
        if ($hostInfo.apiId -and $hostInfo.connectionName) {
          $hostConnectionMap[[string]$hostInfo.apiId] = [string]$hostInfo.connectionName
        }
      }

      foreach ($property in $Node.PSObject.Properties) {
        Walk-Hosts -Node $property.Value
      }
    }
  }

  Walk-Hosts -Node $clientData.properties.definition

  return [pscustomobject]@{
    connectionReferences = $clientData.properties.connectionReferences
    hostConnectionMap = $hostConnectionMap
    sourceWorkflowName = $workflow.name
  }
}

function Sync-QfuSharedConnectionReferences {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$TemplateBindings
  )

  $records = @((Get-CrmRecords -conn $Connection -EntityLogicalName connectionreference -Fields connectionreferenceid, connectionreferencelogicalname, connectionid, connectorid -TopCount 200).CrmRecords)
  $recordMap = @{}
  foreach ($record in $records) {
    $recordMap[[string]$record.connectionreferencelogicalname] = $record
  }

  foreach ($reference in $TemplateBindings.connectionReferences.PSObject.Properties) {
    $templateLogicalName = [string]$reference.Value.connection.connectionReferenceLogicalName
    $templateRecord = $recordMap[$templateLogicalName]
    if (-not $templateRecord -or [string]::IsNullOrWhiteSpace([string]$templateRecord.connectionid)) {
      throw "Template connection reference is not bound: $templateLogicalName"
    }

    $targetLogicalName = "qfu_" + [string]$reference.Value.api.name
    $targetRecord = $recordMap[$targetLogicalName]
    if (-not $targetRecord) {
      throw "Target qfu connection reference not found: $targetLogicalName"
    }

    if ([string]$targetRecord.connectionid -ne [string]$templateRecord.connectionid) {
      Set-CrmRecord -conn $Connection -EntityLogicalName connectionreference -Id $targetRecord.connectionreferenceid -Fields @{ connectionid = [string]$templateRecord.connectionid } | Out-Null
    }
  }
}

function Normalize-Connections {
  param(
    [object]$WorkflowJson,
    [object]$TemplateBindings
  )

  $WorkflowJson.properties.connectionReferences = $TemplateBindings.connectionReferences

  function Walk-Nodes {
    param([object]$Node)

    if ($null -eq $Node) {
      return
    }

    if ($Node -is [System.Collections.IEnumerable] -and -not ($Node -is [string])) {
      foreach ($item in $Node) {
        Walk-Nodes -Node $item
      }
      return
    }

    if ($Node -is [System.Management.Automation.PSCustomObject]) {
      if ($Node.PSObject.Properties["type"] -and [string]$Node.type -eq "OpenApiConnectionNotification") {
        Remove-PropertyIfPresent -Object $Node -Name "recurrence"
      }

      if ($Node.PSObject.Properties["inputs"] -and $Node.inputs -and $Node.inputs.PSObject.Properties["host"]) {
        $hostInfo = $Node.inputs.host
        $apiId = [string]$hostInfo.apiId
        if ($apiId -and $TemplateBindings.hostConnectionMap.ContainsKey($apiId)) {
          $hostInfo.connectionName = $TemplateBindings.hostConnectionMap[$apiId]
        }
      }

      foreach ($property in $Node.PSObject.Properties) {
        Walk-Nodes -Node $property.Value
      }
    }
  }

  Walk-Nodes -Node $WorkflowJson.properties.definition
}

function Sanitize-DataverseActions {
  param(
    [object]$WorkflowJson,
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection
  )

  $removedFields = New-Object System.Collections.Generic.List[string]

  function Walk-Nodes {
    param([object]$Node)

    if ($null -eq $Node) {
      return
    }

    if ($Node -is [System.Collections.IEnumerable] -and -not ($Node -is [string])) {
      foreach ($item in $Node) {
        Walk-Nodes -Node $item
      }
      return
    }

    if ($Node -isnot [System.Management.Automation.PSCustomObject]) {
      return
    }

    if (
      $Node.PSObject.Properties["type"] -and
      [string]$Node.type -eq "OpenApiConnection" -and
      $Node.PSObject.Properties["inputs"] -and
      $Node.inputs -and
      $Node.inputs.PSObject.Properties["host"] -and
      [string]$Node.inputs.host.apiId -eq "/providers/Microsoft.PowerApps/apis/shared_commondataserviceforapps" -and
      $Node.inputs.PSObject.Properties["parameters"] -and
      $Node.inputs.parameters -and
      $Node.inputs.parameters.PSObject.Properties["entityName"]
    ) {
      $entityName = [string]$Node.inputs.parameters.entityName
      $metadataEntityLogicalName = Resolve-MetadataEntityLogicalName -EntityName $entityName
      if ($metadataEntityLogicalName -like "qfu_*") {
        $fieldSet = Get-EntityFieldSet -Connection $Connection -EntityLogicalName $metadataEntityLogicalName

        foreach ($propertyName in @($Node.inputs.parameters.PSObject.Properties.Name | Where-Object { $_ -like "item/*" })) {
          $fieldName = $propertyName.Substring(5)
          if (-not (Test-FieldSupported -FieldSet $fieldSet -FieldName $fieldName)) {
            Remove-PropertyIfPresent -Object $Node.inputs.parameters -Name $propertyName
            $removedFields.Add("$metadataEntityLogicalName.$fieldName") | Out-Null
          }
        }

        if ($Node.inputs.parameters.PSObject.Properties["item"] -and $Node.inputs.parameters.item) {
          foreach ($propertyName in @($Node.inputs.parameters.item.PSObject.Properties.Name)) {
            if (($propertyName -like "qfu_*" -or $propertyName -like "*@odata.bind") -and -not (Test-FieldSupported -FieldSet $fieldSet -FieldName $propertyName)) {
              Remove-PropertyIfPresent -Object $Node.inputs.parameters.item -Name $propertyName
              $removedFields.Add("$metadataEntityLogicalName.$propertyName") | Out-Null
            }
          }
        }
      }
    }

    foreach ($property in $Node.PSObject.Properties) {
      Walk-Nodes -Node $property.Value
    }
  }

  Walk-Nodes -Node $WorkflowJson.properties.definition

  return @($removedFields | Sort-Object -Unique)
}

function Touch-WorkflowDefinition {
  param([object]$WorkflowJson)

  $stamp = Get-Date -Format "yyyyMMdd.HHmmss"
  $WorkflowJson.properties.definition.contentVersion = "1.0.$stamp"
}

function Get-AdminFlowMap {
  param([string]$EnvironmentName)

  $map = @{}
  foreach ($flow in @(Get-AdminFlow -EnvironmentName $EnvironmentName | Where-Object { $_.WorkflowEntityId -in $canonicalFlows.WorkflowId })) {
    $map[[string]$flow.WorkflowEntityId] = $flow
  }

  return $map
}

foreach ($workflowId in @($WorkflowIds)) {
  foreach ($candidate in @(([string]$workflowId) -split ",")) {
    $trimmed = [string]$candidate
    if (-not [string]::IsNullOrWhiteSpace($trimmed)) {
      [void]$workflowIdSet.Add($trimmed.Trim())
    }
  }
}

$targetFlows = if ($workflowIdSet.Count -gt 0) {
  @($canonicalFlows | Where-Object { $workflowIdSet.Contains([string]$_.WorkflowId) })
} else {
  $canonicalFlows
}

if ($workflowIdSet.Count -gt 0) {
  $resolvedWorkflowIds = @($targetFlows | ForEach-Object { [string]$_.WorkflowId })
  $missing = @($workflowIdSet | Where-Object { $_ -notin $resolvedWorkflowIds })
  if ($missing.Count -gt 0) {
    throw "Workflow IDs not found in canonical flow list: $($missing -join ', ')"
  }
}

$connection = Connect-Org -Url $TargetEnvironmentUrl
Add-PowerAppsAccount -Endpoint prod -Username $Username | Out-Null
$templateBindings = Get-TemplateConnectionBindings -Connection $connection -WorkflowId $TemplateWorkflowId
Sync-QfuSharedConnectionReferences -Connection $connection -TemplateBindings $templateBindings
$beforeAdminMap = Get-AdminFlowMap -EnvironmentName $TargetEnvironmentName

$summary = New-Object System.Collections.Generic.List[object]

foreach ($flow in $targetFlows) {
  $path = Get-CanonicalWorkflowPath -DisplayName $flow.DisplayName -WorkflowId $flow.WorkflowId
  $workflowJson = Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
  Normalize-Connections -WorkflowJson $workflowJson -TemplateBindings $templateBindings
  $removedFields = Sanitize-DataverseActions -WorkflowJson $workflowJson -Connection $connection
  Touch-WorkflowDefinition -WorkflowJson $workflowJson
  $clientData = ConvertTo-JsonCompact -Object $workflowJson

  $beforeAdmin = $beforeAdminMap[[string]$flow.WorkflowId]
  $beforeEnabled = if ($beforeAdmin) { [bool]$beforeAdmin.Enabled } else { $false }
  $flowName = if ($beforeAdmin) { [string]$beforeAdmin.FlowName } else { $null }

  Set-CrmRecord -conn $connection -EntityLogicalName workflow -Id $flow.WorkflowId -Fields @{ clientdata = $clientData } | Out-Null
  Set-CrmRecordState -conn $connection -EntityLogicalName workflow -Id $flow.WorkflowId -StateCode Activated -StatusCode Activated | Out-Null

  if ($ToggleAfterUpdate -and $flowName) {
    if ($beforeEnabled) {
      Disable-AdminFlow -EnvironmentName $TargetEnvironmentName -FlowName $flowName | Out-Null
      Start-Sleep -Seconds 3
    }
    Enable-AdminFlow -EnvironmentName $TargetEnvironmentName -FlowName $flowName | Out-Null
    Start-Sleep -Seconds 3
  } elseif ($flowName) {
    Enable-AdminFlow -EnvironmentName $TargetEnvironmentName -FlowName $flowName | Out-Null
    Start-Sleep -Seconds 3
  }

  $afterAdminMap = Get-AdminFlowMap -EnvironmentName $TargetEnvironmentName
  $afterAdmin = $afterAdminMap[[string]$flow.WorkflowId]
  $afterWorkflow = Get-CrmRecord -conn $connection -EntityLogicalName workflow -Id $flow.WorkflowId -Fields name, statecode, statuscode, modifiedon

  $summary.Add([pscustomobject]@{
    display_name = $flow.DisplayName
    workflow_id = $flow.WorkflowId
    source_path = $path
    removed_fields = @($removedFields)
    before_enabled = $beforeEnabled
    after_enabled = if ($afterAdmin) { [bool]$afterAdmin.Enabled } else { $null }
    flow_name = if ($afterAdmin) { [string]$afterAdmin.FlowName } else { $flowName }
    workflow_state = $afterWorkflow.statecode
    workflow_status = $afterWorkflow.statuscode
    workflow_modifiedon = $afterWorkflow.modifiedon
  }) | Out-Null
}

$report = [pscustomobject]@{
  captured_at = (Get-Date).ToUniversalTime().ToString("o")
  target_environment_url = $TargetEnvironmentUrl
  target_environment_name = $TargetEnvironmentName
  live_refresh_root = $LiveRefreshRoot
  template_workflow_id = $TemplateWorkflowId
  toggle_after_update = [bool]$ToggleAfterUpdate
  flows = @($summary.ToArray())
}

$outputPath = Join-Path $RepoRoot $OutputJson
Write-Utf8Json -Path $outputPath -Object $report

$summary |
  Select-Object display_name, workflow_id, before_enabled, after_enabled, workflow_state, workflow_modifiedon |
  Format-Table -AutoSize

Write-Host "OUTPUT_PATH=$outputPath"
