#!/usr/bin/env python3

import argparse
import json
import re
from datetime import datetime
from pathlib import Path

import pdfplumber


BRANCHES = {
    "4171": {
        "branch_code": "4171",
        "branch_slug": "4171-calgary",
        "branch_name": "Calgary",
        "region_slug": "southern-alberta",
        "region_name": "Southern Alberta",
        "mailbox_address": "4171@applied.com",
        "sort_order": 10,
    },
    "4172": {
        "branch_code": "4172",
        "branch_slug": "4172-lethbridge",
        "branch_name": "Lethbridge",
        "region_slug": "southern-alberta",
        "region_name": "Southern Alberta",
        "mailbox_address": "4172@applied.com",
        "sort_order": 20,
    },
    "4173": {
        "branch_code": "4173",
        "branch_slug": "4173-medicine-hat",
        "branch_name": "Medicine Hat",
        "region_slug": "southern-alberta",
        "region_name": "Southern Alberta",
        "mailbox_address": "4173@applied.com",
        "sort_order": 30,
    },
}

FINANCE_METRICS = {
    "Service Center Sales": "sales",
    "Service Center Gross Profit": "grossprofit",
    "Service Center Gross Profit %": "grossprofitpct",
    "Service Center Operating Expense %": "opexpct",
    "Service Center GAP": "gap",
    "OPERATING PROFIT": "operatingprofit",
}

VARIANCE_LABELS = {
    "Compensation & Benefits": "compensation-benefits",
    "Occupancy Expenses": "occupancy-expenses",
    "Shop Expenses": "shop-expenses",
    "Selling Expense": "selling-expense",
    "Administrative Expense": "administrative-expense",
    "Office Expense": "office-expense",
    "Other SD&A (Income)/ Expense": "other-sda-expense",
}

TOKEN_PATTERN = re.compile(r"\(?\$?-?[0-9,]+(?:\.\d+)?%?\)?|#DIV/0")
WHITESPACE_PATTERN = re.compile(r"\s+")
MONTH_LABEL_PATTERN = re.compile(r"For the Month of ([A-Za-z]+ \d{4})")


def normalize_line(value):
    return WHITESPACE_PATTERN.sub(" ", str(value or "").strip())


def tokenize_values(text):
    return TOKEN_PATTERN.findall(text or "")


def as_float(value):
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if not text or text == "#DIV/0":
        return 0.0
    negative = text.startswith("(") and text.endswith(")")
    cleaned = text.replace("$", "").replace(",", "").replace("%", "").replace("(", "").replace(")", "")
    if not cleaned:
        return 0.0
    number = float(cleaned)
    return -number if negative else number


def parse_metric_line(line, label):
    normalized = normalize_line(line)
    if label not in normalized:
        return None
    left, right = normalized.split(label, 1)
    left_tokens = tokenize_values(left)
    right_tokens = tokenize_values(right)
    if len(left_tokens) < 3 or len(right_tokens) < 3:
        return None
    return {
        "current_month_actual": as_float(left_tokens[0]),
        "prior_year_month_actual": as_float(left_tokens[1]),
        "current_month_plan": as_float(left_tokens[2]),
        "current_ytd_actual": as_float(right_tokens[0]),
        "prior_ytd_actual": as_float(right_tokens[1]),
        "current_ytd_plan": as_float(right_tokens[2]),
    }


def parse_month_label(lines):
    for line in lines:
        match = MONTH_LABEL_PATTERN.search(normalize_line(line))
        if match:
            return match.group(1)
    raise ValueError("GL060 month label could not be proven from the PDF.")


def parse_finance_pdf(path, branch):
    all_lines = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text = page.extract_text() or ""
            all_lines.extend(text.splitlines())

    month_label = parse_month_label(all_lines)
    period = datetime.strptime(month_label, "%B %Y")
    metric_rows = {}

    for label, key in FINANCE_METRICS.items():
        match = None
        for line in all_lines:
            if label not in normalize_line(line):
                continue
            candidate = parse_metric_line(line, label)
            if candidate is not None:
                match = candidate
                break
        if match is None:
            raise ValueError(f"GL060 metric '{label}' could not be proven from {path.name}.")
        metric_rows[key] = match

    captured_on = datetime.fromtimestamp(path.stat().st_mtime).isoformat()
    snapshot = {
        "qfu_name": f"{branch['branch_code']} GL060 {month_label}",
        "qfu_sourceid": f"{branch['branch_code']}|GL060|{period.year}-{period.month:02d}",
        "qfu_branchcode": branch["branch_code"],
        "qfu_branchslug": branch["branch_slug"],
        "qfu_regionslug": branch["region_slug"],
        "qfu_sourcefamily": "GL060",
        "qfu_sourcefile": path.name,
        "qfu_monthlabel": month_label,
        "qfu_month": period.month,
        "qfu_year": period.year,
        "qfu_lastupdated": captured_on,
        "qfu_currentmonthsalesactual": round(metric_rows["sales"]["current_month_actual"], 2),
        "qfu_currentmonthsalesplan": round(metric_rows["sales"]["current_month_plan"], 2),
        "qfu_currentmonthgrossprofitactual": round(metric_rows["grossprofit"]["current_month_actual"], 2),
        "qfu_currentmonthgrossprofitplan": round(metric_rows["grossprofit"]["current_month_plan"], 2),
        "qfu_currentmonthgrossprofitpctactual": round(metric_rows["grossprofitpct"]["current_month_actual"], 4),
        "qfu_currentmonthgrossprofitpctplan": round(metric_rows["grossprofitpct"]["current_month_plan"], 4),
        "qfu_currentmonthopexpctactual": round(metric_rows["opexpct"]["current_month_actual"], 4),
        "qfu_currentmonthopexpctplan": round(metric_rows["opexpct"]["current_month_plan"], 4),
        "qfu_currentmonthgapactual": round(metric_rows["gap"]["current_month_actual"], 4),
        "qfu_currentmonthgapplan": round(metric_rows["gap"]["current_month_plan"], 4),
        "qfu_currentmonthoperatingprofitactual": round(metric_rows["operatingprofit"]["current_month_actual"], 2),
        "qfu_currentmonthoperatingprofitplan": round(metric_rows["operatingprofit"]["current_month_plan"], 2),
        "qfu_ytdsalesactual": round(metric_rows["sales"]["current_ytd_actual"], 2),
        "qfu_ytdsalesplan": round(metric_rows["sales"]["current_ytd_plan"], 2),
        "qfu_ytdgrossprofitactual": round(metric_rows["grossprofit"]["current_ytd_actual"], 2),
        "qfu_ytdgrossprofitplan": round(metric_rows["grossprofit"]["current_ytd_plan"], 2),
        "qfu_ytdoperatingprofitactual": round(metric_rows["operatingprofit"]["current_ytd_actual"], 2),
        "qfu_ytdoperatingprofitplan": round(metric_rows["operatingprofit"]["current_ytd_plan"], 2),
    }

    variances = []
    for sort_order, (label, variance_slug) in enumerate(VARIANCE_LABELS.items(), start=1):
        match = None
        for line in all_lines:
            if label not in normalize_line(line):
                continue
            candidate = parse_metric_line(line, label)
            if candidate is not None:
                match = candidate
                break
        if match is None:
            continue
        variances.append(
            {
                "qfu_name": f"{branch['branch_code']} {month_label} {label}",
                "qfu_sourceid": f"{branch['branch_code']}|GL060VAR|{period.year}-{period.month:02d}|{variance_slug}",
                "qfu_branchcode": branch["branch_code"],
                "qfu_branchslug": branch["branch_slug"],
                "qfu_regionslug": branch["region_slug"],
                "qfu_sourcefamily": "GL060",
                "qfu_sourcefile": path.name,
                "qfu_monthlabel": month_label,
                "qfu_month": period.month,
                "qfu_year": period.year,
                "qfu_variancelabel": label,
                "qfu_varianceslug": variance_slug,
                "qfu_sortorder": sort_order,
                "qfu_currentmonthactual": round(match["current_month_actual"], 2),
                "qfu_currentmonthplan": round(match["current_month_plan"], 2),
                "qfu_currentmonthvariance": round(match["current_month_actual"] - match["current_month_plan"], 2),
                "qfu_ytdactual": round(match["current_ytd_actual"], 2),
                "qfu_ytdplan": round(match["current_ytd_plan"], 2),
                "qfu_ytdvariance": round(match["current_ytd_actual"] - match["current_ytd_plan"], 2),
                "qfu_lastupdated": captured_on,
            }
        )

    return {
        "captured_on": captured_on,
        "snapshot": snapshot,
        "variances": variances,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--branch-code", required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    branch = BRANCHES.get(args.branch_code)
    if branch is None:
        raise ValueError(f"Unsupported branch code: {args.branch_code}")

    input_path = Path(args.input)
    payload = parse_finance_pdf(input_path, branch)

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
