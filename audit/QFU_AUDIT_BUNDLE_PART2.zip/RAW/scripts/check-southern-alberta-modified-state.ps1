param(
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com",
  [string]$CutoffUtc = "2026-03-31T23:00:00Z",
  [string]$OutputPath = "results\southern-alberta-modified-check.json"
)

$ErrorActionPreference = "Stop"

Import-Module Microsoft.Xrm.Data.Powershell

function Get-TargetConnection {
  param(
    [string]$Url,
    [string]$User
  )

  $conn = Connect-CrmOnline -ServerUrl $Url -ForceOAuth -Username $User
  if (-not $conn -or -not $conn.IsReady) {
    throw "Dataverse connection failed for $Url : $($conn.LastCrmError)"
  }

  return $conn
}

function Get-RecordsByBranch {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [string]$EntityLogicalName,
    [string]$BranchCode
  )

  return @((Get-CrmRecords -conn $Connection -EntityLogicalName $EntityLogicalName -FilterAttribute "qfu_branchcode" -FilterOperator eq -FilterValue $BranchCode -Fields @("qfu_sourceid", "createdon", "modifiedon") -TopCount 5000).CrmRecords)
}

$cutoff = [datetime]$CutoffUtc
$connection = Get-TargetConnection -Url $TargetEnvironmentUrl -User $Username
$result = @()

foreach ($branchCode in @("4171", "4172", "4173")) {
  foreach ($entityLogicalName in @("qfu_quote", "qfu_backorder", "qfu_budget", "qfu_branchdailysummary")) {
    $records = Get-RecordsByBranch -Connection $connection -EntityLogicalName $entityLogicalName -BranchCode $branchCode
    $recent = @(
      $records |
        Where-Object { $_.modifiedon -and ([datetime]$_.modifiedon).ToUniversalTime() -ge $cutoff } |
        Sort-Object modifiedon -Descending
    )
    $latest = $records | Sort-Object modifiedon -Descending | Select-Object -First 1

    $result += [pscustomobject]@{
      branch_code = $branchCode
      entity = $entityLogicalName
      row_count = @($records).Count
      modified_since_cutoff = @($recent).Count
      latest_modifiedon = if ($latest) { $latest.modifiedon } else { $null }
      latest_sourceid = if ($latest) { $latest.qfu_sourceid } else { $null }
    }
  }
}

$fullOutputPath = if ([System.IO.Path]::IsPathRooted($OutputPath)) { $OutputPath } else { Join-Path (Get-Location).Path $OutputPath }
$parent = Split-Path -Parent $fullOutputPath
if ($parent -and -not (Test-Path -LiteralPath $parent)) {
  New-Item -ItemType Directory -Path $parent -Force | Out-Null
}

$json = $result | ConvertTo-Json -Depth 10
[System.IO.File]::WriteAllText($fullOutputPath, $json, [System.Text.UTF8Encoding]::new($false))

$result | Format-Table -AutoSize
Write-Host "OUTPUT_PATH=$fullOutputPath"
