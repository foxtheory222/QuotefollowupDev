param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$TaskName = "QFU-GL060-Inbox-Queue-Processor",
  [int]$IntervalMinutes = 5,
  [switch]$AllowLegacyLocalTask
)

$ErrorActionPreference = "Stop"

$message = @"
Local scheduled GL060 processing is retired.

Do not recreate the '$TaskName' Windows task as part of the normal rollout.
The expected shape is mailbox ingress plus downstream hosted GL060 processing.

This script only exists as a guarded legacy fallback. If you intentionally need
the old local scheduled processor for a one-off recovery, rerun with
-AllowLegacyLocalTask and accept that it will launch local PowerShell sessions.
"@

if (-not $AllowLegacyLocalTask) {
  throw $message
}

$processorScript = Join-Path $RepoRoot "scripts\process-gl060-inbox-queue.ps1"
if (-not (Test-Path -LiteralPath $processorScript)) {
  throw "Processor script not found: $processorScript"
}

$taskCommand = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File `"$processorScript`""
$arguments = @(
  "/Create",
  "/SC", "MINUTE",
  "/MO", "$IntervalMinutes",
  "/TN", $TaskName,
  "/TR", $taskCommand,
  "/F"
)

& schtasks.exe @arguments | Out-Null
if ($LASTEXITCODE -ne 0) {
  throw "Failed to register scheduled task: $TaskName"
}

Write-Host "TASK_NAME=$TaskName"
Write-Host "TASK_COMMAND=$taskCommand"
