param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$OutputZip = "phase0_audit_bundle.zip"
)

$ErrorActionPreference = "Stop"

$bundleName = "phase0_audit_bundle"
$bundleRoot = Join-Path $RepoRoot $bundleName
$zipPath = Join-Path $RepoRoot $OutputZip
$verifyRoot = Join-Path $RepoRoot ".phase0_audit_verify"
$tempRoot = Join-Path $RepoRoot ".phase0_audit_temp"

$siteRoot = Join-Path $RepoRoot "powerpages-live\operations-hub---operationhub"
$referenceDashboardSiteRoot = Join-Path $RepoRoot "QFUAUDIT\02_powerpages\dashboard\dashboard---site-f2vhh"
$legacySolutionRoot = Join-Path $RepoRoot "QFUAUDIT\01_solution"
$nodeExe = Join-Path $RepoRoot "Archive\.tools\node-v24.14.0-win-x64\node.exe"
$captureScript = Join-Path $RepoRoot "scripts\capture-portal-screenshot.cjs"
$storageStatePath = Join-Path $RepoRoot ".playwright-auth\operationhub-dev-state.json"
$sourceEnvironmentName = "MainDashBoard"
$sourceEnvironmentUrl = "https://orgd3e6cd10.crm3.dynamics.com/"
$sourceSiteUrl = "https://site-f2vhh.powerappsportals.com/"
$targetEnvironmentName = "Applied Canada Operations Hub"
$targetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com/"
$targetSiteUrl = "https://operationhub.powerappsportals.com/"
$targetWebsiteId = "2b4aca76-9dc1-4628-af07-20f7617d4115"
$screenshotRoot = Join-Path $bundleRoot "SCREENSHOTS"
$siteExportRoot = Join-Path $bundleRoot "SITE_EXPORT"
$solutionExportRoot = Join-Path $bundleRoot "SOLUTION_EXPORT"
$diffRoot = Join-Path $bundleRoot "DIFFS"
$evidenceRoot = Join-Path $bundleRoot "EVIDENCE"
$logsRoot = Join-Path $bundleRoot "OPTIONAL_LOGS"

function Ensure-Directory {
  param([string]$Path)
  if (-not (Test-Path $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Remove-IfExists {
  param([string]$Path)
  if (Test-Path $Path) {
    Remove-Item -LiteralPath $Path -Recurse -Force
  }
}

function Write-Utf8File {
  param(
    [string]$Path,
    [string]$Content
  )

  $parent = Split-Path -Parent $Path
  if ($parent) {
    Ensure-Directory $parent
  }

  [System.IO.File]::WriteAllText($Path, $Content, (New-Object System.Text.UTF8Encoding($false)))
}

function Capture-LiveScreenshot {
  param(
    [string]$Url,
    [string]$OutFile
  )

  if (-not (Test-Path $nodeExe)) {
    throw "Node runtime not found: $nodeExe"
  }
  if (-not (Test-Path $captureScript)) {
    throw "Capture script not found: $captureScript"
  }
  if (-not (Test-Path $storageStatePath)) {
    throw "Authenticated Playwright storage state not found: $storageStatePath"
  }

  $captureOutput = & $nodeExe $captureScript $Url $OutFile $storageStatePath "3000"
  if ($LASTEXITCODE -ne 0) {
    throw "Live screenshot command failed for $OutFile"
  }

  if (-not (Test-Path $OutFile)) {
    throw "Expected screenshot was not created: $OutFile"
  }

  $payload = $captureOutput | ConvertFrom-Json
  $requestedHost = ([System.Uri]$Url).Host
  $finalHost = if ($payload.finalUrl) { ([System.Uri]$payload.finalUrl).Host } else { "" }
  $signInMarkers = @(
    "Sign in",
    "Stay signed in",
    "Pick an account",
    "Use another account"
  )
  $looksLikeSignIn = $signInMarkers | Where-Object {
    ($payload.title -like "*$_*") -or ($payload.bodyStart -like "*$_*")
  }

  if ($finalHost -ne $requestedHost) {
    throw "Screenshot capture redirected away from target host for $Url. Final host: $finalHost"
  }

  if ($looksLikeSignIn.Count -gt 0) {
    throw "Screenshot capture for $Url appears to be on an authentication page: $($looksLikeSignIn -join ', ')"
  }
}

function New-RelativeFileMap {
  param([string]$Root)

  $items = @{}
  Get-ChildItem -Path $Root -Recurse -File | ForEach-Object {
    $relative = $_.FullName.Substring($Root.Length).TrimStart("\")
    $items[$relative] = @{
      FullName = $_.FullName
      Hash = (Get-FileHash -Algorithm SHA256 -Path $_.FullName).Hash
    }
  }
  return $items
}

function Write-ListFile {
  param(
    [string]$Path,
    [string]$Header,
    [string[]]$Items
  )

  $content = @($Header, "")
  if ($Items.Count -eq 0) {
    $content += "(none)"
  } else {
    $content += $Items
  }

  Write-Utf8File -Path $Path -Content (($content -join [Environment]::NewLine) + [Environment]::NewLine)
}

Remove-IfExists $bundleRoot
Remove-IfExists $zipPath
Remove-IfExists $verifyRoot
Remove-IfExists $tempRoot

Ensure-Directory $bundleRoot
Ensure-Directory $screenshotRoot
Ensure-Directory $siteExportRoot
Ensure-Directory $solutionExportRoot
Ensure-Directory $diffRoot
Ensure-Directory $evidenceRoot
Ensure-Directory $logsRoot

Copy-Item -LiteralPath $siteRoot -Destination (Join-Path $siteExportRoot "operations-hub---operationhub") -Recurse -Force
Copy-Item -LiteralPath $legacySolutionRoot -Destination (Join-Path $solutionExportRoot "legacy-qfu-reference-solution") -Recurse -Force
Write-Utf8File -Path (Join-Path $solutionExportRoot "README_NO_DEPLOYED_QFU_SOLUTION.md") -Content @"
# Solution Export Note

- Environment reviewed: $targetEnvironmentName
- Environment URL: $targetEnvironmentUrl
- Public site URL: $targetSiteUrl
- As of March 31, 2026, `pac solution list` in this environment returns only:
  - `Cr8cdfe` / `Common Data Services Default Solution`
  - `Default` / `Default Solution`
- No QFU Dataverse / Power Automate solution is currently deployed in this environment.
- Phase 0 in this dev environment is therefore a Power Pages shell-only build.
- `legacy-qfu-reference-solution/` contains historical source-controlled QFU solution artifacts from this repo so reviewers can inspect the prior table/flow foundation that informed the Phase 0 shell.
- Those legacy artifacts are reference material only. They are not deployed in the reviewed target environment and must not be read as proof of live backend readiness in regionaloperationshub.
"@

Capture-LiveScreenshot -Url $targetSiteUrl -OutFile (Join-Path $screenshotRoot "01_hub.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta") -OutFile (Join-Path $screenshotRoot "02_region_southern_alberta.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary") -OutFile (Join-Path $screenshotRoot "03_branch_4171_calgary_home.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=follow-up-queue") -OutFile (Join-Path $screenshotRoot "04_branch_4171_calgary_followup_queue.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=quotes") -OutFile (Join-Path $screenshotRoot "05_branch_4171_calgary_quotes.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=overdue-quotes") -OutFile (Join-Path $screenshotRoot "06_branch_4171_calgary_overdue_quotes.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=overdue-backorders") -OutFile (Join-Path $screenshotRoot "07_branch_4171_calgary_overdue_backorders.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=team-progress") -OutFile (Join-Path $screenshotRoot "08_branch_4171_calgary_team_progress.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=workload") -OutFile (Join-Path $screenshotRoot "09_branch_4171_calgary_workload.png")
Capture-LiveScreenshot -Url ($targetSiteUrl + "southern-alberta/4171-calgary/detail?view=analytics") -OutFile (Join-Path $screenshotRoot "10_branch_4171_calgary_analytics.png")

$newMap = New-RelativeFileMap -Root $siteRoot
$referenceMap = New-RelativeFileMap -Root $referenceDashboardSiteRoot

$created = @($newMap.Keys | Where-Object { -not $referenceMap.ContainsKey($_) } | Sort-Object)
$deleted = @($referenceMap.Keys | Where-Object { -not $newMap.ContainsKey($_) } | Sort-Object)
$changed = @(
  $newMap.Keys |
    Where-Object { $referenceMap.ContainsKey($_) -and $newMap[$_].Hash -ne $referenceMap[$_].Hash } |
    Sort-Object
)

$diffHeader = "Baseline for these lists: QFUAUDIT/02_powerpages/dashboard/dashboard---site-f2vhh compared against powerpages-live/operations-hub---operationhub. This is a reference-site diff, not git history."
Write-ListFile -Path (Join-Path $diffRoot "created_files.txt") -Header $diffHeader -Items $created
Write-ListFile -Path (Join-Path $diffRoot "changed_files.txt") -Header $diffHeader -Items $changed
Write-ListFile -Path (Join-Path $diffRoot "deleted_files.txt") -Header $diffHeader -Items $deleted

$readme = @"
# Phase 0 Review Bundle

- Project name: Quote Follow Up Regional Rollout
- Source environment: MainDashBoard
- Source environment URL: https://orgd3e6cd10.crm3.dynamics.com/
- Source site URL: https://site-f2vhh.powerappsportals.com/
- Target environment: Applied Canada Operations Hub
- Target environment URL: https://regionaloperationshub.crm.dynamics.com/
- Target site URL: https://operationhub.powerappsportals.com/
- Phase being reviewed: Phase 0

## Exact statement of what Phase 0 was supposed to achieve

From [AGENTS.md]: "Architecture freeze and foundation decisions."

From [CURRENT_STATE_NOTES.md], Phase 0 must lock:
- the page hierarchy
- the final KPI inventory
- the branch-region model
- the security model
- the ingestion/source inventory
- the summary-table strategy
- the rollout pilot scope
- the definition of done for Phase 1

## Exact statement of what was intentionally NOT part of Phase 0

The Phase 0 source itself says:
- "No QFU solution, summary tables, or live monitoring data are installed in this environment as of March 30, 2026."
- "Phase 0 stops at shell validation."
- "Operational tooling is intentionally excluded from Phase 0."

For review purposes, that means the following were intentionally out of scope:
- live regional KPI wiring
- Dataverse / Power Automate deployment into regionaloperationshub
- live branch queue actions in the new shell
- admin tooling beyond a locked placeholder
- northern Alberta and Saskatchewan rollout
- live Calgary detail data sources
- live 4172 / 4173 data onboarding
- production workload, team progress, and analytics implementation

## One-paragraph direction summary

This bundle reflects the real approved Phase 0 build running in `Applied Canada Operations Hub`, not the earlier stale local export. The target site is verified, screenshots are captured from the live authenticated environment, and the compact 4171 branch workbench pattern is now the canonical shell across 4171, 4172, and 4173. Phase 0 should still be read honestly as a shell-only milestone: the branch pattern is approved and frozen, but the environment has no deployed QFU solution, no Dataverse-backed monitoring tables, and no live branch data wiring yet.
"@
Write-Utf8File -Path (Join-Path $bundleRoot "README_PHASE0_REVIEW.md") -Content $readme

$status = @"
# Phase 0 Status

## Complete

- The reviewed target environment is verified as `Applied Canada Operations Hub` at `https://regionaloperationshub.crm.dynamics.com/`.
- The reviewed public site is verified as `https://operationhub.powerappsportals.com/`, website id `2b4aca76-9dc1-4628-af07-20f7617d4115`.
- The repo site export was refreshed from the real target environment using `pac pages download -mv Enhanced`.
- Actual authenticated screenshots were captured from the target environment for Hub, region, branch home, and every Calgary detail route required by the audit bundle.
- The compact table-first Calgary branch workbench is the approved live branch-page pattern.
- The same branch shell and information hierarchy are live for 4172 Lethbridge and 4173 Medicine Hat, with honest not-live states.
- Locked and not-live states are labeled openly in the live renderer instead of being hidden behind fake KPIs.

## Partial

- Southern Alberta exists as a live regional shell, but its KPI strip and branch cards are not bound to live region summary tables.
- 4171 Calgary is partially wired through archived live snapshot content: queue, budget, quote summary, and backorder modules are populated from archived 4171 values, not from live OperationHub backend tables.
- 4172 and 4173 use the canonical branch shell, but they remain shell-only with no archived branch snapshots loaded.
- The diff set is useful for review, but it is based on the legacy dashboard site export, not on git history.

## Locked

- Northern Alberta region
- Saskatchewan region
- Ops / Admin surface
- Calgary detail routes remain locked even though the routes exist:
  - Follow-up Queue
  - Quotes
  - Overdue Quotes
  - Overdue Backorders
  - Team Progress
  - Workload
  - Analytics
- 4172 Lethbridge live data rollout
- 4173 Medicine Hat live data rollout

## Missing

- A deployed QFU Dataverse / Power Automate solution in regionaloperationshub
- Live region summary data in OperationHub
- Live Calgary queue state, follow-up scheduling, ownership logic, and row actions
- Live Calgary detail datasets behind the locked routes
- Live team progress, workload, and analytics implementation
- Live 4172 / 4173 branch data onboarding
- Standalone security, ingestion, and configuration artifacts for the new dev environment

## Codex judgment

- Ready for Phase 0 approval: Yes
- Ready for Phase 1: Yes, for Calgary-only functional work inside the frozen branch pattern
- Ready for multi-branch rollout beyond Calgary: No

## Why Codex says yes for Phase 0 and limited Phase 1

Phase 0, as implemented here, is a real deployed shell-validation milestone. The approved branch-page pattern is live, verified, and frozen in the new dev environment. What is not ready is the backend rollout. Phase 1 can start for Calgary because the layout decision is closed; the next work should be functional wiring inside this exact shell, not further UI redesign.
"@
Write-Utf8File -Path (Join-Path $bundleRoot "PHASE0_STATUS.md") -Content $status

$pageInventory = @"
# Page Inventory

| Page / surface | Route | Purpose | Status | Shell or wired |
| --- | --- | --- | --- | --- |
| Hub | `/` | Regional landing page for drill-down into regions and Ops / Admin | Live | Deployed shell; no live region data |
| Southern Alberta | `/southern-alberta` | Pilot region shell with branch card layout | Live | Deployed shell; no live region data |
| Northern Alberta | `/northern-alberta` | Reserved future region route | Locked | Shell only |
| Saskatchewan | `/saskatchewan` | Reserved future region route | Locked | Shell only |
| Ops / Admin | `/ops-admin` | Placeholder for branch config / replay / support tooling | Locked | Shell only |
| 4171 Calgary | `/southern-alberta/4171-calgary` | Approved canonical branch workbench for operational rollout | Live | Wired to archived 4171 snapshot values; not live backend data |
| 4172 Lethbridge | `/southern-alberta/4172-lethbridge` | Canonical branch workbench shell for future rollout | Live | Same approved shell as 4171, but no live or archived branch data loaded |
| 4173 Medicine Hat | `/southern-alberta/4173-medicine-hat` | Canonical branch workbench shell for future rollout | Live | Same approved shell as 4171, but no live or archived branch data loaded |
| 4171 detail shell | `/southern-alberta/4171-calgary/detail?view=follow-up-queue|quotes|overdue-quotes|overdue-backorders|team-progress|workload|analytics` | Locked drill-through targets that preserve the final Calgary tool hierarchy | Locked | Route family is deployed; no live list binding |
| 4172 detail shell | `/southern-alberta/4172-lethbridge/detail?...` | Locked drill-through target for future branch rollout | Locked | Route family is deployed; no live list binding |
| 4173 detail shell | `/southern-alberta/4173-medicine-hat/detail?...` | Locked drill-through target for future branch rollout | Locked | Route family is deployed; no live list binding |
| Access Denied | `/access-denied` | Platform carry-forward page | Live | Standard platform page |
| Page Not Found | `/page-not-found` | Platform carry-forward page | Live | Standard platform page |
| Search | `/search` | Platform carry-forward page | Live | Standard platform page |
| Profile | `/profile` | Platform carry-forward page | Live | Standard platform page |

## Reviewer note

The approved Phase 0 decision is now visible directly in the dev environment: 4171, 4172, and 4173 all share the same compact branch workbench hierarchy. Calgary is the only branch with archived live snapshot content loaded into that shell.
"@
Write-Utf8File -Path (Join-Path $bundleRoot "PAGE_INVENTORY.md") -Content $pageInventory

$navMap = @"
# Navigation Map

Top navigation visible in source:
- Hub
- Ops / Admin

Primary route structure:

Hub -> Southern Alberta -> 4171 Calgary -> Home
Hub -> Southern Alberta -> 4171 Calgary -> Follow-up Queue [locked -> `/detail?view=follow-up-queue`]
Hub -> Southern Alberta -> 4171 Calgary -> Quotes [locked -> `/detail?view=quotes`]
Hub -> Southern Alberta -> 4171 Calgary -> Overdue Quotes [locked -> `/detail?view=overdue-quotes`]
Hub -> Southern Alberta -> 4171 Calgary -> Overdue Backorders [locked -> `/detail?view=overdue-backorders`]
Hub -> Southern Alberta -> 4171 Calgary -> Team Progress [locked -> `/detail?view=team-progress`]
Hub -> Southern Alberta -> 4171 Calgary -> Workload [locked -> `/detail?view=workload`]
Hub -> Southern Alberta -> 4171 Calgary -> Analytics [locked -> `/detail?view=analytics`]

Canonical branch rollout structure now visible in the dev environment:
- Hub -> Southern Alberta -> 4172 Lethbridge -> same branch tab family as 4171, all branch data not live
- Hub -> Southern Alberta -> 4173 Medicine Hat -> same branch tab family as 4171, all branch data not live
- Hub -> Northern Alberta [locked]
- Hub -> Saskatchewan [locked]
- Hub -> Ops / Admin [locked]

Hierarchy in code:
- Hub is the root page.
- Southern Alberta, Northern Alberta, Saskatchewan, and Ops / Admin are children of Hub.
- 4171 Calgary, 4172 Lethbridge, and 4173 Medicine Hat are children of Southern Alberta.
- Each branch has a `detail` child page that is parameterized by `view=`.
- The final Phase 0 branch hierarchy is identical across all three Southern Alberta branches.
"@
Write-Utf8File -Path (Join-Path $bundleRoot "NAVIGATION_MAP.md") -Content $navMap

$kpiMap = @"
# KPI / Source Map

| Widget / KPI | Appears on | Source table / data source | State | Honest label / note |
| --- | --- | --- | --- | --- |
| Southern Alberta branch count | Hub card | None in target environment | Not live | Shown as `Awaiting Integration` |
| Southern Alberta overdue quotes | Hub card | None in target environment | Not live | Shown as `Awaiting Integration` |
| Southern Alberta overdue backorders | Hub card | None in target environment | Not live | Shown as `Awaiting Integration` |
| Southern Alberta budget pace | Hub card | None in target environment | Not live | Shown as `Awaiting Integration` |
| Northern Alberta and Saskatchewan hub metrics | Hub cards | None in target environment | Locked | Explicitly labeled `Locked` / `Awaiting Integration` |
| Southern Alberta region KPI strip | Southern Alberta region | None in target environment | Not live | All six regional KPIs remain `Awaiting Integration` / `No Live Data Yet` |
| Southern Alberta branch cards | Southern Alberta region | Static renderer values | Not live | Branch routing is live, but region card metrics are not wired |
| 4171 Quotes in Queue | 4171 branch callout | Archived live 4171 snapshot embedded in renderer | Snapshot | Value `45` |
| 4171 Overdue Follow-ups | 4171 branch callout | Archived live 4171 snapshot embedded in renderer | Snapshot | Value `6` |
| 4171 Due Today | 4171 branch callout | Archived live 4171 snapshot embedded in renderer | Snapshot | Value `0` |
| 4171 Unscheduled (Old) | 4171 branch callout | Archived live 4171 snapshot embedded in renderer | Snapshot | Value `509`; explicitly called out as needing live queue wiring |
| 4171 Top 5 Highest Unfollowed-up Quotes table | 4171 branch home | Archived live 4171 quote rows embedded in renderer | Snapshot | Quote number, customer, value, days overdue, next follow-up, last touched, and owner all come from archived snapshot content |
| 4171 Monthly Budget Progress | 4171 branch sidebar | Archived live 4171 budget snapshot | Snapshot | Actual `$780,470.98`, target `$901,760.00`, pace `86.5%`, remaining, needed per workday, trending, CAD, USD, and FX are all archived live snapshot values |
| 4171 CSSR Overdue Back Orders | 4171 branch sidebar | Archived live 4171 CSSR overdue counts | Snapshot | People/count list is archived live snapshot content |
| 4171 Quotes - Last 30 Days | 4171 branch support module | Archived live 4171 quote snapshot | Snapshot | Total Quotes `294`, Quotes Won `49`, Quotes Lost `0`, Open Quotes `245`, Win Rate `16.7%`, Avg Quote Value `$2,361.27` |
| 4171 March Forecast | 4171 branch backorder summary cards | Archived live 4171 backorder snapshot | Snapshot | `$136,933.18` |
| 4171 March Late | 4171 branch backorder summary cards | Archived live 4171 backorder snapshot | Snapshot | `$70,449.35` |
| 4171 All Backorders | 4171 branch backorder summary cards | Archived live 4171 backorder snapshot | Snapshot | `$717,343.62` |
| 4171 All Late Backorders | 4171 branch backorder summary cards | Archived live 4171 backorder snapshot | Snapshot | `$76,392.89` |
| 4171 Overdue Backorders grid | 4171 branch backorder surface | Archived live 4171 backorder rows | Snapshot | The table rows shown in the Phase 0 shell are archived live snapshot rows, not live OperationHub data |
| 4171 branch source labels | 4171 branch home | Static renderer values | Shell only | `Stale Snapshot`, `Awaiting Integration`, `Phase 0 honesty`, and source notes are shell messaging, not backend data |
| 4172 branch callouts, queue, budget, quote metrics, and backorders | 4172 branch | None in target environment | Not live | Same approved shell as 4171, but all data surfaces render explicit placeholder / awaiting-integration states |
| 4173 branch callouts, queue, budget, quote metrics, and backorders | 4173 branch | None in target environment | Not live | Same approved shell as 4171, but all data surfaces render explicit placeholder / awaiting-integration states |
| 4171 Follow-up Queue detail route | 4171 detail | None in target environment | Locked | Route is live and visible, but no real queue list or actions are wired |
| 4171 Quotes detail route | 4171 detail | None in target environment | Locked | No live quote list binding |
| 4171 Overdue Quotes detail route | 4171 detail | None in target environment | Locked | No live overdue quote binding |
| 4171 Overdue Backorders detail route | 4171 detail | None in target environment | Locked | No live overdue backorder binding |
| 4171 Team Progress detail route | 4171 detail | None in target environment | Locked | No live team summary binding |
| 4171 Workload detail route | 4171 detail | None in target environment | Locked | No live workload binding |
| 4171 Analytics detail route | 4171 detail | None in target environment | Locked | Route exists to preserve the final navigation family only |
"@
Write-Utf8File -Path (Join-Path $bundleRoot "KPI_SOURCE_MAP.md") -Content $kpiMap

$outOfScope = @"
# Out Of Scope

- Deploying the QFU Dataverse / Power Automate solution into regionaloperationshub
- Live rollout of Northern Alberta
- Live rollout of Saskatchewan
- Live 4172 Lethbridge data onboarding
- Live 4173 Medicine Hat data onboarding
- Live queue-state logic and next-action scheduling in OperationHub
- Live Calgary detail lists for Follow-up Queue, Quotes, Overdue Quotes, Overdue Backorders, Team Progress, Workload, and Analytics
- Ops / Admin tooling beyond a locked placeholder
- Replay / rerun tools
- Import failure review UI
- Full branch / region / HQ access model validation in the new site
- Broader rollout beyond Calgary-focused Phase 1 wiring
"@
Write-Utf8File -Path (Join-Path $bundleRoot "OUT_OF_SCOPE.md") -Content $outOfScope

$knownGaps = @"
# Known Gaps

- regionaloperationshub currently has no deployed QFU solution; `pac solution list` shows only the two default solutions.
- Southern Alberta region KPIs are still not live.
- The Southern Alberta region card summary remains `Awaiting Integration`, while the Calgary branch shell shows archived snapshot values. That mismatch is still real.
- Calgary detail routes exist, but they remain locked shells with no live dataset or actions behind them.
- 4172 and 4173 share the approved branch shell, but they have no archived branch snapshot loaded and no live backend data.
- Northern Alberta and Saskatchewan are still locked shells.
- Ops / Admin is still a placeholder only.
- The current Phase 0 build is site-only; there is no Dataverse schema, flow, or summary-table deployment in the reviewed environment yet.
- The repo still needs explicit Phase 1 implementation artifacts for security, source inventory, and ingestion mapping against regionaloperationshub.
- The diff files in this bundle are based on a reference export of the legacy dashboard site, because this workspace is not a git repository.
"@
Write-Utf8File -Path (Join-Path $bundleRoot "KNOWN_GAPS.md") -Content $knownGaps

$dataBindings = @"
# Data Bindings Summary

| Major visible section | Binding state | Evidence / note |
| --- | --- | --- |
| Hub regional cards | Static shell only | All KPI values are renderer text such as `Awaiting Integration` or `Locked` |
| Southern Alberta region KPI strip | Structurally present but not live | No live region summary tables are bound into the shell |
| Southern Alberta branch cards | Static shell only | Route links are real, but branch card metrics are not live |
| 4171 Calgary callout cards | Bound to archived live snapshot | Values are from archived live 4171 snapshot content |
| 4171 Calgary top-5 queue table | Bound to archived live snapshot | Table rows are derived from archived live 4171 quote rows |
| 4171 Calgary budget module | Bound to archived live snapshot | All visible values come from archived live 4171 budget snapshot content |
| 4171 Calgary CSSR overdue module | Bound to archived live snapshot | CSSR/count list comes from archived live 4171 snapshot content |
| 4171 Calgary Quotes - Last 30 Days | Bound to archived live snapshot | Metrics come from archived live 4171 quote snapshot content |
| 4171 Calgary backorder summary cards | Bound to archived live snapshot | Forecast, late, all-backorders, and all-late values come from archived live 4171 snapshot content |
| 4171 Calgary overdue backorders grid | Bound to archived live snapshot | Rows come from archived live 4171 backorder snapshot content |
| 4171 Calgary detail routes | Structurally present but locked | Routes are deployed and navigable, but no live detail datasets are bound |
| 4172 Lethbridge branch route | Structurally present but locked | Same approved shell as 4171, but every data surface remains placeholder-only |
| 4173 Medicine Hat branch route | Structurally present but locked | Same approved shell as 4171, but every data surface remains placeholder-only |
| Northern Alberta region | Static shell only | Locked route only |
| Saskatchewan region | Static shell only | Locked route only |
| Ops / Admin | Static shell only | Locked placeholder |
"@
Write-Utf8File -Path (Join-Path $evidenceRoot "data_bindings_summary.md") -Content $dataBindings

$lockedStates = @"
# Locked States Summary

| Surface | Status | Why it is locked |
| --- | --- | --- |
| Northern Alberta region page | Locked | Phase 0 did not include region rollout beyond the Southern Alberta pilot shell |
| Saskatchewan region page | Locked | Phase 0 did not include region rollout beyond the Southern Alberta pilot shell |
| Ops / Admin page | Locked | Admin tooling is intentionally deferred beyond Phase 0 shell validation |
| 4172 Lethbridge branch data surfaces | Not live | The canonical shell is deployed, but branch onboarding was not part of Phase 0 delivery |
| 4173 Medicine Hat branch data surfaces | Not live | The canonical shell is deployed, but branch onboarding was not part of Phase 0 delivery |
| 4171 Follow-up Queue route | Locked | Route exists to preserve the tool hierarchy, but no live list/action wiring is implemented |
| 4171 Quotes route | Locked | Route exists, but no live quote list wiring is implemented |
| 4171 Overdue Quotes route | Locked | Route exists, but no live overdue quote wiring is implemented |
| 4171 Overdue Backorders route | Locked | Route exists, but no live overdue backorder wiring is implemented |
| 4171 Team Progress route | Locked | Route exists, but no live team summary wiring is implemented |
| 4171 Workload route | Locked | Route exists, but no live workload wiring is implemented |
| 4171 Analytics route | Locked | Route exists, but no analytics source or chart wiring is implemented |
"@
Write-Utf8File -Path (Join-Path $evidenceRoot "locked_states_summary.md") -Content $lockedStates

$liveVsLocked = @"
# Live vs Locked Matrix

| Scope | Status | Reviewer note |
| --- | --- | --- |
| Hub | Live | Deployed and viewable in the target environment; KPI content is still shell-only |
| Southern Alberta region | Live | Deployed and viewable in the target environment; regional metrics are still not live |
| 4171 Calgary branch | Partial | Deployed canonical branch shell with archived live snapshot content, but no live backend wiring |
| 4172 Lethbridge branch | Partial | Deployed canonical branch shell with no live or archived branch data |
| 4173 Medicine Hat branch | Partial | Deployed canonical branch shell with no live or archived branch data |
"@
Write-Utf8File -Path (Join-Path $evidenceRoot "live_vs_locked_matrix.md") -Content $liveVsLocked

$environmentTruth = @"
# Environment Truth

- This review is for a new development environment: `Applied Canada Operations Hub` at `https://regionaloperationshub.crm.dynamics.com/`.
- The reviewed public Power Pages site is `https://operationhub.powerappsportals.com/`, website id `2b4aca76-9dc1-4628-af07-20f7617d4115`.
- The source environment used as reference for the approved Phase 0 direction is `MainDashBoard` at `https://orgd3e6cd10.crm3.dynamics.com/`.
- The source site used as reference is `https://site-f2vhh.powerappsportals.com/`, represented in this repo by `QFUAUDIT/02_powerpages/dashboard/dashboard---site-f2vhh`.
- The repo's current `powerpages-live/operations-hub---operationhub` export was refreshed directly from the target dev environment using `pac pages download --environment https://regionaloperationshub.crm.dynamics.com/ --webSiteId 2b4aca76-9dc1-4628-af07-20f7617d4115 -mv Enhanced`.
- What was copied conceptually:
  - the Quote Follow Up monitoring domain
  - the branch operations monitoring workflow and drill-down model
  - the approved compact 4171 Calgary operator workbench pattern
  - archived 4171 Calgary evidence used to ground the Phase 0 shell in real branch data
- What was not copied literally:
  - the old dashboard site was not simply cloned, zipped, or relabeled into the new environment
  - the old environment's code and data were not copied into regionaloperationshub as a live backend deployment
  - the new Hub -> Region -> Branch hierarchy and locked-state messaging were rebuilt for the regional rollout
  - the branch shell now exposes honest `Locked`, `Awaiting Integration`, `Stale Snapshot`, and `Not Live` states instead of implying false production readiness
- Old code reuse assessment:
  - legacy QFU solution artifacts and the old dashboard export were referenced as inputs
  - the OperationHub site in source control now reflects a fresh export from the target dev environment, not a stale local reconstruction
  - archived 4171 values were reused as evidence and snapshot content, not as proof of live backend deployment
  - no live QFU Dataverse / Power Automate solution is deployed in regionaloperationshub as of March 31, 2026
"@
Write-Utf8File -Path (Join-Path $evidenceRoot "environment_truth.md") -Content $environmentTruth

$buildNotes = @"
# Build Notes

- Screenshot basis: all screenshots in this bundle are captured from the authenticated live target site `https://operationhub.powerappsportals.com/` using Playwright storage state from `.playwright-auth/operationhub-dev-state.json`.
- Screenshot guardrail: the capture routine now fails if navigation redirects away from the target host or appears to land on a Microsoft sign-in page.
- Site export basis: `SITE_EXPORT/operations-hub---operationhub` is a fresh `pac pages download` from the reviewed target environment using the Enhanced data model.
- Solution export basis: `SOLUTION_EXPORT/legacy-qfu-reference-solution` contains historical QFU solution artifacts for review context only; the target environment itself has no deployed QFU solution.
- Diff basis: `DIFFS/` compares `powerpages-live/operations-hub---operationhub` against `QFUAUDIT/02_powerpages/dashboard/dashboard---site-f2vhh`. It is not a git history diff because this workspace has no `.git` repository.
- Review stance: this bundle is intentionally reviewer-facing and gap-forward. It shows the approved live branch shell honestly, while documenting that backend Phase 1 wiring has not yet been deployed into the target environment.
"@
Write-Utf8File -Path (Join-Path $logsRoot "build_notes.md") -Content $buildNotes

$commandsRun = @'
Bundle review and build commands used:

- `pac pages list --environment https://regionaloperationshub.crm.dynamics.com/`
- `pac solution list --environment https://regionaloperationshub.crm.dynamics.com/`
- `pac pages download --environment https://regionaloperationshub.crm.dynamics.com/ --path .live-site-download --webSiteId 2b4aca76-9dc1-4628-af07-20f7617d4115 --overwrite -mv Enhanced`
- `Get-Content -Raw scripts/build-phase0-audit-bundle.ps1`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/ phase0_audit_bundle/SCREENSHOTS/01_hub.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta phase0_audit_bundle/SCREENSHOTS/02_region_southern_alberta.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary phase0_audit_bundle/SCREENSHOTS/03_branch_4171_calgary_home.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary/detail?view=follow-up-queue phase0_audit_bundle/SCREENSHOTS/04_branch_4171_calgary_followup_queue.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary/detail?view=quotes phase0_audit_bundle/SCREENSHOTS/05_branch_4171_calgary_quotes.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary/detail?view=overdue-quotes phase0_audit_bundle/SCREENSHOTS/06_branch_4171_calgary_overdue_quotes.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary/detail?view=overdue-backorders phase0_audit_bundle/SCREENSHOTS/07_branch_4171_calgary_overdue_backorders.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary/detail?view=team-progress phase0_audit_bundle/SCREENSHOTS/08_branch_4171_calgary_team_progress.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary/detail?view=workload phase0_audit_bundle/SCREENSHOTS/09_branch_4171_calgary_workload.png .playwright-auth/operationhub-dev-state.json 3000`
- `node scripts/capture-portal-screenshot.cjs https://operationhub.powerappsportals.com/southern-alberta/4171-calgary/detail?view=analytics phase0_audit_bundle/SCREENSHOTS/10_branch_4171_calgary_analytics.png .playwright-auth/operationhub-dev-state.json 3000`
- `Compress-Archive -Path phase0_audit_bundle -DestinationPath phase0_audit_bundle.zip`
- `Expand-Archive -LiteralPath phase0_audit_bundle.zip -DestinationPath .phase0_audit_verify`
'@
Write-Utf8File -Path (Join-Path $logsRoot "commands_run.txt") -Content $commandsRun

Compress-Archive -Path $bundleRoot -DestinationPath $zipPath -Force

if (-not (Test-Path $zipPath)) {
  throw "Zip file was not created: $zipPath"
}

Expand-Archive -LiteralPath $zipPath -DestinationPath $verifyRoot -Force
$verifyBundleRoot = Join-Path $verifyRoot $bundleName

if (-not (Test-Path $verifyBundleRoot)) {
  throw "Verified archive did not expand to expected root folder: $verifyBundleRoot"
}

$requiredMarkdown = @(
  "README_PHASE0_REVIEW.md",
  "PHASE0_STATUS.md",
  "PAGE_INVENTORY.md",
  "NAVIGATION_MAP.md",
  "KPI_SOURCE_MAP.md",
  "OUT_OF_SCOPE.md",
  "KNOWN_GAPS.md",
  "EVIDENCE\data_bindings_summary.md",
  "EVIDENCE\locked_states_summary.md",
  "EVIDENCE\live_vs_locked_matrix.md",
  "EVIDENCE\environment_truth.md"
)

$requiredScreenshots = @(
  "SCREENSHOTS\01_hub.png",
  "SCREENSHOTS\02_region_southern_alberta.png",
  "SCREENSHOTS\03_branch_4171_calgary_home.png",
  "SCREENSHOTS\04_branch_4171_calgary_followup_queue.png",
  "SCREENSHOTS\05_branch_4171_calgary_quotes.png",
  "SCREENSHOTS\06_branch_4171_calgary_overdue_quotes.png",
  "SCREENSHOTS\07_branch_4171_calgary_overdue_backorders.png",
  "SCREENSHOTS\08_branch_4171_calgary_team_progress.png",
  "SCREENSHOTS\09_branch_4171_calgary_workload.png",
  "SCREENSHOTS\10_branch_4171_calgary_analytics.png"
)

foreach ($relativePath in $requiredMarkdown) {
  $fullPath = Join-Path $verifyBundleRoot $relativePath
  if (-not (Test-Path $fullPath)) {
    throw "Missing required markdown file in verified archive: $relativePath"
  }
}

foreach ($relativePath in $requiredScreenshots) {
  $fullPath = Join-Path $verifyBundleRoot $relativePath
  if (-not (Test-Path $fullPath)) {
    throw "Missing required screenshot in verified archive: $relativePath"
  }
}

if ([System.IO.Path]::GetFileName($zipPath) -ne "phase0_audit_bundle.zip") {
  throw "Zip filename is incorrect: $zipPath"
}

Write-Host "phase0_audit_bundle.zip created and verified at: $zipPath"
