param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$SolutionUniqueName = "qfu_tempmailboxcapture",
  [string]$SolutionDisplayName = "QFU Temp Mailbox Capture",
  [string]$SolutionVersion = "1.0.0.1",
  [string[]]$BranchCodes = @("4171", "4172", "4173"),
  [switch]$ImportToTarget = $true
)

$ErrorActionPreference = "Stop"

$solutionRoot = Join-Path $RepoRoot "results\tempmailboxcapture"
$sourceRoot = Join-Path $solutionRoot "src"
$otherRoot = Join-Path $sourceRoot "Other"
$workflowRoot = Join-Path $sourceRoot "Workflows"
$zipPath = Join-Path $RepoRoot "results\qfu-tempmailboxcapture.zip"

$flowSpecs = @(
  [pscustomobject]@{
    BranchCode = "4171"
    BranchSlug = "4171-calgary"
    BranchName = "Calgary"
    FlowName = "4171-Temp-Mailbox-Capture"
    WorkflowId = "7b4e2b57-a83d-4d1f-b23c-82f6037e7217"
    TriggerMetadataId = "79910cb6-1efd-4ece-8d21-b7b17c4029a8"
    ActionMetadataId = "9a085309-f71d-4444-9c14-52f337a79be6"
  },
  [pscustomobject]@{
    BranchCode = "4172"
    BranchSlug = "4172-lethbridge"
    BranchName = "Lethbridge"
    FlowName = "4172-Temp-Mailbox-Capture"
    WorkflowId = "d496a7b4-be51-40e0-b20a-b4112fdc252f"
    TriggerMetadataId = "3b85f3c3-bfad-4a0f-8f1c-382322c99150"
    ActionMetadataId = "c2d16fa4-beb1-4c20-9e8b-2e3a10045021"
  },
  [pscustomobject]@{
    BranchCode = "4173"
    BranchSlug = "4173-medicine-hat"
    BranchName = "Medicine Hat"
    FlowName = "4173-Temp-Mailbox-Capture"
    WorkflowId = "7d935f14-85c6-4b10-8d37-99c9b3bfc6e8"
    TriggerMetadataId = "f21f9118-ec1d-43f4-b484-5fdfe2ce1be7"
    ActionMetadataId = "ca23754a-530d-493c-9953-337dd9e036d3"
  }
)

$flowSpecs = @($flowSpecs | Where-Object { $_.BranchCode -in $BranchCodes })
if ($flowSpecs.Count -eq 0) {
  throw "No mailbox capture flows matched BranchCodes: $($BranchCodes -join ', ')"
}

function Ensure-Directory {
  param([string]$Path)
  if (-not (Test-Path -LiteralPath $Path)) {
    New-Item -ItemType Directory -Path $Path -Force | Out-Null
  }
}

function Remove-IfExists {
  param([string]$Path)
  if (Test-Path -LiteralPath $Path) {
    Remove-Item -LiteralPath $Path -Recurse -Force
  }
}

function Write-Utf8File {
  param(
    [string]$Path,
    [string]$Content
  )

  $parent = Split-Path -Parent $Path
  if ($parent) {
    Ensure-Directory $parent
  }

  [System.IO.File]::WriteAllText($Path, $Content, (New-Object System.Text.UTF8Encoding($false)))
}

function Get-UpperGuid {
  param([string]$Value)
  return $Value.ToUpperInvariant()
}

function New-WorkflowJson {
  param([object]$Flow)

  $jsonObject = [ordered]@{
    properties = [ordered]@{
      connectionReferences = [ordered]@{
        shared_office365 = [ordered]@{
          api = [ordered]@{
            name = "shared_office365"
          }
          connection = [ordered]@{
            connectionReferenceLogicalName = "qfu_shared_office365"
          }
          runtimeSource = "embedded"
        }
      }
      definition = [ordered]@{
        '$schema' = "https://schema.management.azure.com/providers/Microsoft.Logic/schemas/2016-06-01/workflowdefinition.json#"
        contentVersion = "1.0.0.0"
        parameters = [ordered]@{
          '$authentication' = [ordered]@{
            defaultValue = [ordered]@{}
            type = "SecureObject"
          }
          '$connections' = [ordered]@{
            defaultValue = [ordered]@{}
            type = "Object"
          }
          qfu_Temp_SharedMailboxAddress = [ordered]@{
            defaultValue = "$($Flow.BranchCode)@applied.com"
            type = "String"
          }
          qfu_Temp_SharedMailboxFolderId = [ordered]@{
            defaultValue = "Inbox"
            type = "String"
          }
        }
        triggers = [ordered]@{
          'When_a_new_email_arrives_in_a_shared_mailbox_(V2)' = [ordered]@{
            type = "OpenApiConnectionNotification"
            description = "Temporary helper flow used only to select the shared mailbox identity and folder for $($Flow.BranchCode) $($Flow.BranchName) in the target environment."
            inputs = [ordered]@{
              parameters = [ordered]@{
                mailboxAddress = "@parameters('qfu_Temp_SharedMailboxAddress')"
                folderId = "@parameters('qfu_Temp_SharedMailboxFolderId')"
                includeAttachments = $true
                importance = "Any"
              }
              host = [ordered]@{
                apiId = "/providers/Microsoft.PowerApps/apis/shared_office365"
                operationId = "SharedMailboxOnNewEmailV2"
                connectionName = "shared_office365"
              }
            }
            splitOn = "@triggerOutputs()?['body/value']"
            metadata = [ordered]@{
              operationMetadataId = $Flow.TriggerMetadataId
            }
          }
        }
        actions = [ordered]@{
          Compose_Branch_Context = [ordered]@{
            type = "Compose"
            inputs = [ordered]@{
              branch_code = $Flow.BranchCode
              branch_slug = $Flow.BranchSlug
              branch_name = $Flow.BranchName
              purpose = "Temporary mailbox identity capture only"
            }
            runAfter = [ordered]@{}
            metadata = [ordered]@{
              operationMetadataId = $Flow.ActionMetadataId
            }
          }
        }
        outputs = [ordered]@{}
      }
      templateName = $null
    }
    schemaVersion = "1.0.0.0"
  }

  return ($jsonObject | ConvertTo-Json -Depth 20)
}

function New-WorkflowDataXml {
  param([object]$Flow)

  $workflowIdUpper = Get-UpperGuid $Flow.WorkflowId
  return @"
<?xml version="1.0" encoding="utf-8"?>
<Workflow WorkflowId="{$workflowIdUpper}" Name="$($Flow.FlowName)" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
  <JsonFileName>/Workflows/$($Flow.FlowName)-$workflowIdUpper.json</JsonFileName>
  <Type>1</Type>
  <Subprocess>0</Subprocess>
  <Category>5</Category>
  <Mode>0</Mode>
  <Scope>4</Scope>
  <OnDemand>0</OnDemand>
  <TriggerOnCreate>0</TriggerOnCreate>
  <TriggerOnDelete>0</TriggerOnDelete>
  <AsyncAutodelete>0</AsyncAutodelete>
  <SyncWorkflowLogOnFailure>0</SyncWorkflowLogOnFailure>
  <StateCode>0</StateCode>
  <StatusCode>1</StatusCode>
  <RunAs>1</RunAs>
  <IsTransacted>1</IsTransacted>
  <IntroducedVersion>1.0</IntroducedVersion>
  <IsCustomizable>1</IsCustomizable>
  <RendererObjectTypeCode>0</RendererObjectTypeCode>
  <IsCustomProcessingStepAllowedForOtherPublishers>1</IsCustomProcessingStepAllowedForOtherPublishers>
  <ModernFlowType>0</ModernFlowType>
  <PrimaryEntity>none</PrimaryEntity>
  <LocalizedNames>
    <LocalizedName languagecode="1033" description="$($Flow.FlowName)" />
  </LocalizedNames>
</Workflow>
"@
}

Remove-IfExists $solutionRoot
Remove-IfExists $zipPath

Ensure-Directory $otherRoot
Ensure-Directory $workflowRoot

$solutionXml = @"
<?xml version="1.0" encoding="utf-8"?>
<ImportExportXml version="9.2.26033.148" SolutionPackageVersion="9.2" languagecode="1033" generatedBy="CrmLive" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" OrganizationVersion="9.2.26033.148" OrganizationSchemaType="Standard" CRMServerServiceabilityVersion="9.2.26033.00148">
  <SolutionManifest>
    <UniqueName>$SolutionUniqueName</UniqueName>
    <LocalizedNames>
      <LocalizedName description="$SolutionDisplayName" languagecode="1033" />
    </LocalizedNames>
    <Descriptions />
    <Version>$SolutionVersion</Version>
    <Managed>0</Managed>
    <Publisher>
      <UniqueName>qfu</UniqueName>
      <LocalizedNames>
        <LocalizedName description="qfu" languagecode="1033" />
      </LocalizedNames>
      <Descriptions />
      <EMailAddress xsi:nil="true"></EMailAddress>
      <SupportingWebsiteUrl xsi:nil="true"></SupportingWebsiteUrl>
      <CustomizationPrefix>qfu</CustomizationPrefix>
      <CustomizationOptionValuePrefix>98501</CustomizationOptionValuePrefix>
      <Addresses>
        <Address>
          <AddressNumber>1</AddressNumber>
          <AddressTypeCode xsi:nil="true"></AddressTypeCode>
          <City xsi:nil="true"></City>
          <County xsi:nil="true"></County>
          <Country xsi:nil="true"></Country>
          <Fax xsi:nil="true"></Fax>
          <FreightTermsCode xsi:nil="true"></FreightTermsCode>
          <ImportSequenceNumber xsi:nil="true"></ImportSequenceNumber>
          <Latitude xsi:nil="true"></Latitude>
          <Line1 xsi:nil="true"></Line1>
          <Line2 xsi:nil="true"></Line2>
          <Line3 xsi:nil="true"></Line3>
          <Longitude xsi:nil="true"></Longitude>
          <Name xsi:nil="true"></Name>
          <PostalCode xsi:nil="true"></PostalCode>
          <PostOfficeBox xsi:nil="true"></PostOfficeBox>
          <PrimaryContactName xsi:nil="true"></PrimaryContactName>
          <ShippingMethodCode xsi:nil="true"></ShippingMethodCode>
          <StateOrProvince xsi:nil="true"></StateOrProvince>
          <Telephone1 xsi:nil="true"></Telephone1>
          <Telephone2 xsi:nil="true"></Telephone2>
          <Telephone3 xsi:nil="true"></Telephone3>
          <TimeZoneRuleVersionNumber xsi:nil="true"></TimeZoneRuleVersionNumber>
          <UPSZone xsi:nil="true"></UPSZone>
          <UTCOffset xsi:nil="true"></UTCOffset>
          <UTCConversionTimeZoneCode xsi:nil="true"></UTCConversionTimeZoneCode>
        </Address>
        <Address>
          <AddressNumber>2</AddressNumber>
          <AddressTypeCode xsi:nil="true"></AddressTypeCode>
          <City xsi:nil="true"></City>
          <County xsi:nil="true"></County>
          <Country xsi:nil="true"></Country>
          <Fax xsi:nil="true"></Fax>
          <FreightTermsCode xsi:nil="true"></FreightTermsCode>
          <ImportSequenceNumber xsi:nil="true"></ImportSequenceNumber>
          <Latitude xsi:nil="true"></Latitude>
          <Line1 xsi:nil="true"></Line1>
          <Line2 xsi:nil="true"></Line2>
          <Line3 xsi:nil="true"></Line3>
          <Longitude xsi:nil="true"></Longitude>
          <Name xsi:nil="true"></Name>
          <PostalCode xsi:nil="true"></PostalCode>
          <PostOfficeBox xsi:nil="true"></PostOfficeBox>
          <PrimaryContactName xsi:nil="true"></PrimaryContactName>
          <ShippingMethodCode xsi:nil="true"></ShippingMethodCode>
          <StateOrProvince xsi:nil="true"></StateOrProvince>
          <Telephone1 xsi:nil="true"></Telephone1>
          <Telephone2 xsi:nil="true"></Telephone2>
          <Telephone3 xsi:nil="true"></Telephone3>
          <TimeZoneRuleVersionNumber xsi:nil="true"></TimeZoneRuleVersionNumber>
          <UPSZone xsi:nil="true"></UPSZone>
          <UTCOffset xsi:nil="true"></UTCOffset>
          <UTCConversionTimeZoneCode xsi:nil="true"></UTCConversionTimeZoneCode>
        </Address>
      </Addresses>
    </Publisher>
    <RootComponents>
$(
  ($flowSpecs | ForEach-Object { '      <RootComponent type="29" id="{' + $_.WorkflowId + '}" behavior="0" />' }) -join "`r`n"
)
    </RootComponents>
    <MissingDependencies />
  </SolutionManifest>
</ImportExportXml>
"@

$customizationsXml = @"
<?xml version="1.0" encoding="utf-8"?>
<ImportExportXml xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" OrganizationVersion="9.2.26033.148" OrganizationSchemaType="Standard" CRMServerServiceabilityVersion="9.2.26033.00148">
  <Entities />
  <Roles />
  <Workflows />
  <FieldSecurityProfiles />
  <Templates />
  <EntityMaps />
  <EntityRelationships />
  <OrganizationSettings />
  <optionsets />
  <CustomControls />
  <EntityDataProviders />
  <connectionreferences>
    <connectionreference connectionreferencelogicalname="qfu_shared_office365">
      <connectionreferencedisplayname>qfu_shared_office365</connectionreferencedisplayname>
      <connectorid>/providers/Microsoft.PowerApps/apis/shared_office365</connectorid>
      <iscustomizable>1</iscustomizable>
      <promptingbehavior>0</promptingbehavior>
      <statecode>0</statecode>
      <statuscode>1</statuscode>
    </connectionreference>
  </connectionreferences>
  <Languages>
    <Language>1033</Language>
  </Languages>
</ImportExportXml>
"@

$relationshipsXml = @"
<?xml version="1.0" encoding="utf-8"?>
<EntityRelationships xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" />
"@

Write-Utf8File -Path (Join-Path $otherRoot "Solution.xml") -Content $solutionXml
Write-Utf8File -Path (Join-Path $otherRoot "Customizations.xml") -Content $customizationsXml
Write-Utf8File -Path (Join-Path $otherRoot "Relationships.xml") -Content $relationshipsXml

foreach ($flow in $flowSpecs) {
  $upperGuid = Get-UpperGuid $flow.WorkflowId
  $jsonName = "$($flow.FlowName)-$upperGuid.json"
  $dataXmlName = "$jsonName.data.xml"

  Write-Utf8File -Path (Join-Path $workflowRoot $jsonName) -Content (New-WorkflowJson -Flow $flow)
  Write-Utf8File -Path (Join-Path $workflowRoot $dataXmlName) -Content (New-WorkflowDataXml -Flow $flow)
}

& pac solution pack --folder $sourceRoot --zipfile $zipPath --packagetype Unmanaged
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $zipPath)) {
  throw "pac solution pack failed for $zipPath"
}

if ($ImportToTarget) {
  & pac solution import --environment $TargetEnvironmentUrl --path $zipPath --force-overwrite --publish-changes
  if ($LASTEXITCODE -ne 0) {
    throw "pac solution import failed for $zipPath"
  }
}

Write-Host "SOLUTION_ROOT=$solutionRoot"
Write-Host "ZIP_PATH=$zipPath"
Write-Host "FLOWS=$($flowSpecs.FlowName -join ', ')"
