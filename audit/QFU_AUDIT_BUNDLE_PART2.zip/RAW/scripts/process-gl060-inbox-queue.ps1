param(
  [string]$RepoRoot = "C:\Users\smcfarlane\Desktop\WorkBench\QuoteFollowUpRegion",
  [string]$TargetEnvironmentUrl = "https://regionaloperationshub.crm.dynamics.com",
  [string]$Username = "smcfarlane@applied.com",
  [string]$OutputJson = "results\gl060-inbox-queue-summary.json",
  [int]$TopCount = 25
)

$ErrorActionPreference = "Stop"

. (Join-Path $RepoRoot "scripts\deploy-southern-alberta-pilot.ps1")

function Ensure-ProcessorSchema {
  param([Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection)

  Ensure-MinimalSchema -Connection $Connection

  foreach ($entityName in @("qfu_financesnapshot", "qfu_financevariance")) {
    if (-not (Test-EntityExists -Connection $Connection -LogicalName $entityName)) {
      throw "Required dashboard entity is missing: $entityName. Run scripts\\sync-southern-alberta-dashboard-spine.ps1 first."
    }
  }
}

function Get-QueuedRawDocuments {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [int]$MaxRows
  )

  $scanCount = [Math]::Max(($MaxRows * 10), 500)
  $rows = @((Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_rawdocument" -FilterAttribute "qfu_status" -FilterOperator eq -FilterValue "queued" -Fields @(
        "qfu_rawdocumentid",
        "qfu_name",
        "qfu_sourceid",
        "qfu_branchcode",
        "qfu_branchslug",
        "qfu_regionslug",
        "qfu_sourcefamily",
        "qfu_sourcefile",
        "qfu_contenthash",
        "qfu_monthlabel",
        "qfu_month",
        "qfu_year",
        "qfu_receivedon",
        "qfu_rawcontentbase64",
        "qfu_status"
      ) -TopCount $scanCount).CrmRecords)

  return @($rows |
      Where-Object { $_.qfu_sourcefamily -eq "GL060" } |
      Sort-Object { [datetime]($_.qfu_receivedon | ForEach-Object { if ($_){ $_ } else { [datetime]::MinValue } }) } -Descending |
      Select-Object -First $MaxRows)
}

function Set-RawDocumentState {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$Document,
    [string]$Status,
    [string]$Notes = $null,
    [string]$ContentHash = $null,
    [string]$MonthLabel = $null,
    [int]$Month = 0,
    [int]$Year = 0,
    [Nullable[datetime]]$ProcessedOn = $null
  )

  $fields = @{
    qfu_status = $Status
    qfu_processingnotes = $Notes
  }
  if ($ContentHash) { $fields.qfu_contenthash = $ContentHash }
  if ($MonthLabel) { $fields.qfu_monthlabel = $MonthLabel }
  if ($Month -gt 0) { $fields.qfu_month = $Month }
  if ($Year -gt 0) { $fields.qfu_year = $Year }
  if ($ProcessedOn) { $fields.qfu_processedon = $ProcessedOn }

  Set-CrmRecord -conn $Connection -EntityLogicalName "qfu_rawdocument" -Id $Document.qfu_rawdocumentid -Fields $fields | Out-Null
}

function Get-ContentHash {
  param([object]$Document)

  if ($Document.qfu_contenthash) {
    return [string]$Document.qfu_contenthash
  }

  $bytes = [Convert]::FromBase64String([string]$Document.qfu_rawcontentbase64)
  $hashBytes = [System.Security.Cryptography.SHA256]::Create().ComputeHash($bytes)
  return ([System.BitConverter]::ToString($hashBytes) -replace "-", "").ToLowerInvariant()
}

function Get-ExistingDuplicateDocument {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$Document,
    [string]$ContentHash
  )

  $existingRows = @((Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_rawdocument" -FilterAttribute "qfu_branchcode" -FilterOperator eq -FilterValue $Document.qfu_branchcode -Fields @(
        "qfu_rawdocumentid",
        "qfu_sourceid",
        "qfu_sourcefamily",
        "qfu_sourcefile",
        "qfu_status",
        "qfu_contenthash",
        "qfu_monthlabel",
        "qfu_month",
        "qfu_year",
        "qfu_processedon",
        "qfu_rawcontentbase64"
      ) -TopCount 250).CrmRecords)

  foreach ($row in $existingRows) {
    if ([string]$row.qfu_rawdocumentid -eq [string]$Document.qfu_rawdocumentid) {
      continue
    }
    if ([string]$row.qfu_sourcefamily -ne "GL060") {
      continue
    }
    if (@("processed", "duplicate") -notcontains [string]$row.qfu_status) {
      continue
    }

    $rowHash = [string]$row.qfu_contenthash
    if (-not $rowHash -and $row.qfu_rawcontentbase64) {
      $rowHash = Get-ContentHash -Document $row
      Set-CrmRecord -conn $Connection -EntityLogicalName "qfu_rawdocument" -Id $row.qfu_rawdocumentid -Fields @{ qfu_contenthash = $rowHash } | Out-Null
    }

    if ($rowHash -and $rowHash -eq $ContentHash) {
      return $row
    }
  }

  return $null
}

function Upsert-IngestionBatch {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$Document,
    [string]$Status,
    [int]$InsertedCount = 0,
    [int]$UpdatedCount = 0,
    [string]$Notes = $null,
    [Nullable[datetime]]$CompletedOn = $null
  )

  $existing = @(Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_ingestionbatch" -FilterAttribute "qfu_sourceid" -FilterOperator eq -FilterValue $Document.qfu_sourceid -Fields @("qfu_ingestionbatchid") -TopCount 1).CrmRecords | Select-Object -First 1
  $fields = @{
    qfu_name = "$($Document.qfu_branchcode) GL060 Inbox Import"
    qfu_sourceid = [string]$Document.qfu_sourceid
    qfu_branchcode = [string]$Document.qfu_branchcode
    qfu_branchslug = [string]$Document.qfu_branchslug
    qfu_regionslug = [string]$Document.qfu_regionslug
    qfu_sourcefamily = "GL060"
    qfu_sourcefilename = [string]$Document.qfu_sourcefile
    qfu_status = $Status
    qfu_insertedcount = $InsertedCount
    qfu_updatedcount = $UpdatedCount
    qfu_triggerflow = "GL060 Inbox PDF Ingress"
    qfu_notes = $Notes
  }
  if (-not $existing) {
    $fields.qfu_startedon = [datetime]::UtcNow
  }
  if ($CompletedOn) {
    $fields.qfu_completedon = $CompletedOn
  }

  if ($existing) {
    Set-CrmRecord -conn $Connection -EntityLogicalName "qfu_ingestionbatch" -Id $existing.qfu_ingestionbatchid -Fields $fields | Out-Null
    return "updated"
  }

  New-CrmRecord -conn $Connection -EntityLogicalName "qfu_ingestionbatch" -Fields $fields | Out-Null
  return "created"
}

function New-TempPdfFromRawDocument {
  param(
    [object]$Document,
    [string]$RepoRootPath
  )

  $stagingRoot = Join-Path $RepoRootPath "results\gl060-queue-staging"
  Ensure-Directory $stagingRoot
  $safeName = [IO.Path]::GetFileName(($Document.qfu_sourcefile | ForEach-Object { if ($_){$_} else {"GL060.pdf"} }))
  $fileName = "{0}-{1}-{2}" -f $Document.qfu_branchcode, ([guid]::NewGuid().Guid), $safeName
  $path = Join-Path $stagingRoot $fileName
  [IO.File]::WriteAllBytes($path, [Convert]::FromBase64String([string]$Document.qfu_rawcontentbase64))
  return $path
}

function Invoke-Gl060Parser {
  param(
    [string]$RepoRootPath,
    [string]$BranchCode,
    [string]$InputPdfPath
  )

  $python = Get-Command python -ErrorAction SilentlyContinue
  if (-not $python) {
    throw "python is required to process queued GL060 PDFs."
  }

  $outputPath = Join-Path $RepoRootPath ("results\gl060-queue-staging\parsed-{0}.json" -f ([guid]::NewGuid().Guid))
  $scriptPath = Join-Path $RepoRootPath "scripts\parse-gl060-pdf.py"
  & $python.Source $scriptPath --branch-code $BranchCode --input $InputPdfPath --output $outputPath
  if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $outputPath)) {
    throw "GL060 parser failed for $InputPdfPath"
  }

  return (Get-Content -LiteralPath $outputPath -Raw | ConvertFrom-Json)
}

function Upsert-FinanceSnapshot {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$Snapshot
  )

  $fields = Convert-RecordToFields -EntityLogicalName "qfu_financesnapshot" -Record $Snapshot
  $existing = @(Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_financesnapshot" -FilterAttribute "qfu_sourceid" -FilterOperator eq -FilterValue $Snapshot.qfu_sourceid -Fields @("qfu_financesnapshotid") -TopCount 1).CrmRecords | Select-Object -First 1
  if ($existing) {
    Set-CrmRecord -conn $Connection -EntityLogicalName "qfu_financesnapshot" -Id $existing.qfu_financesnapshotid -Fields $fields | Out-Null
    return "updated"
  }

  New-CrmRecord -conn $Connection -EntityLogicalName "qfu_financesnapshot" -Fields $fields | Out-Null
  return "created"
}

function Replace-FinanceVariances {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object[]]$Variances,
    [string]$BranchCode,
    [int]$Month,
    [int]$Year
  )

  $deleted = 0
  $created = 0
  $updated = 0

  $existingRows = @((Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_financevariance" -FilterAttribute "qfu_branchcode" -FilterOperator eq -FilterValue $BranchCode -Fields @("qfu_financevarianceid", "qfu_month", "qfu_year") -TopCount 500).CrmRecords)
  foreach ($row in @($existingRows | Where-Object { $_.qfu_month -eq $Month -and $_.qfu_year -eq $Year })) {
    $Connection.Delete("qfu_financevariance", [guid]$row.qfu_financevarianceid)
    $deleted += 1
  }

  foreach ($variance in @($Variances)) {
    $fields = Convert-RecordToFields -EntityLogicalName "qfu_financevariance" -Record $variance
    $existing = @(Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_financevariance" -FilterAttribute "qfu_sourceid" -FilterOperator eq -FilterValue $variance.qfu_sourceid -Fields @("qfu_financevarianceid") -TopCount 1).CrmRecords | Select-Object -First 1
    if ($existing) {
      Set-CrmRecord -conn $Connection -EntityLogicalName "qfu_financevariance" -Id $existing.qfu_financevarianceid -Fields $fields | Out-Null
      $updated += 1
    } else {
      New-CrmRecord -conn $Connection -EntityLogicalName "qfu_financevariance" -Fields $fields | Out-Null
      $created += 1
    }
  }

  return [ordered]@{
    deleted = $deleted
    created = $created
    updated = $updated
  }
}

function Update-BudgetArchiveActual {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$Snapshot
  )

  $fiscalYearNumber = if ([int]$Snapshot.qfu_month -ge 7) { ([int]$Snapshot.qfu_year - 1999) } else { ([int]$Snapshot.qfu_year - 2000) }
  $budgetSourceId = "{0}|budgetarchive|FY{1}|{2}" -f $Snapshot.qfu_branchcode, ('{0:d2}' -f $fiscalYearNumber), ('{0:d2}' -f [int]$Snapshot.qfu_month)
  $existing = @(Get-CrmRecords -conn $Connection -EntityLogicalName "qfu_budgetarchive" -FilterAttribute "qfu_sourceid" -FilterOperator eq -FilterValue $budgetSourceId -Fields @("qfu_budgetarchiveid") -TopCount 1).CrmRecords | Select-Object -First 1
  if (-not $existing) {
    return [ordered]@{
      updated = $false
      note = "Budget archive row not found for $budgetSourceId."
    }
  }

  Set-CrmRecord -conn $Connection -EntityLogicalName "qfu_budgetarchive" -Id $existing.qfu_budgetarchiveid -Fields @{
    qfu_actualsales = [decimal]$Snapshot.qfu_currentmonthsalesactual
    qfu_lastupdated = [datetime]$Snapshot.qfu_lastupdated
    qfu_sourcefile = [string]$Snapshot.qfu_sourcefile
  } | Out-Null

  return [ordered]@{
    updated = $true
    note = "Budget archive actual updated."
  }
}

function Process-QueuedDocument {
  param(
    [Microsoft.Xrm.Tooling.Connector.CrmServiceClient]$Connection,
    [object]$Document,
    [string]$RepoRootPath
  )

  $result = [ordered]@{
    source_id = [string]$Document.qfu_sourceid
    branch_code = [string]$Document.qfu_branchcode
    file_name = [string]$Document.qfu_sourcefile
    status = "failed"
    snapshot = $null
    variances = $null
    budget_archive = $null
    message = $null
  }

  $contentHash = Get-ContentHash -Document $Document
  Set-RawDocumentState -Connection $Connection -Document $Document -Status "processing" -Notes "GL060 processor started." -ContentHash $contentHash
  $null = Upsert-IngestionBatch -Connection $Connection -Document $Document -Status "processing" -Notes "GL060 processor started."

  $tempPdf = $null
  try {
    $duplicate = Get-ExistingDuplicateDocument -Connection $Connection -Document $Document -ContentHash $contentHash
    if ($duplicate) {
      $processedOn = [datetime]::UtcNow
      $duplicateMonthLabel = [string]($duplicate.qfu_monthlabel | ForEach-Object { if ($_){ $_ } else { "Existing GL060 month" } })
      $duplicateNote = "Duplicate GL060 PDF content matched existing source $($duplicate.qfu_sourceid) for $duplicateMonthLabel. No reprocess required."
      Set-RawDocumentState -Connection $Connection -Document $Document -Status "duplicate" -Notes $duplicateNote -ContentHash $contentHash -MonthLabel ([string]$duplicate.qfu_monthlabel) -Month ([int]$duplicate.qfu_month) -Year ([int]$duplicate.qfu_year) -ProcessedOn $processedOn
      $null = Upsert-IngestionBatch -Connection $Connection -Document $Document -Status "duplicate" -InsertedCount 0 -UpdatedCount 0 -Notes $duplicateNote -CompletedOn $processedOn
      $result.status = "duplicate"
      $result.message = $duplicateNote
      return $result
    }

    $tempPdf = New-TempPdfFromRawDocument -Document $Document -RepoRootPath $RepoRootPath
    $parsed = Invoke-Gl060Parser -RepoRootPath $RepoRootPath -BranchCode ([string]$Document.qfu_branchcode) -InputPdfPath $tempPdf
    $snapshot = $parsed.snapshot
    $varianceResult = Replace-FinanceVariances -Connection $Connection -Variances @($parsed.variances) -BranchCode ([string]$Document.qfu_branchcode) -Month ([int]$snapshot.qfu_month) -Year ([int]$snapshot.qfu_year)
    $snapshotResult = Upsert-FinanceSnapshot -Connection $Connection -Snapshot $snapshot
    $budgetResult = Update-BudgetArchiveActual -Connection $Connection -Snapshot $snapshot
    $processedOn = [datetime]::UtcNow
    $snapshotInserted = if ($snapshotResult -eq "created") { 1 } else { 0 }
    $snapshotUpdated = if ($snapshotResult -eq "updated") { 1 } else { 0 }
    $insertedCount = $snapshotInserted + [int]$varianceResult.created
    $updatedCount = $snapshotUpdated + [int]$varianceResult.updated
    $notes = "Processed $($snapshot.qfu_monthlabel) from $($Document.qfu_sourcefile). Variances created: $($varianceResult.created), updated: $($varianceResult.updated), deleted: $($varianceResult.deleted). $($budgetResult.note)"

    Set-RawDocumentState -Connection $Connection -Document $Document -Status "processed" -Notes $notes -ContentHash $contentHash -MonthLabel ([string]$snapshot.qfu_monthlabel) -Month ([int]$snapshot.qfu_month) -Year ([int]$snapshot.qfu_year) -ProcessedOn $processedOn
    $null = Upsert-IngestionBatch -Connection $Connection -Document $Document -Status "ready" -InsertedCount $insertedCount -UpdatedCount $updatedCount -Notes $notes -CompletedOn $processedOn

    $result.status = "processed"
    $result.snapshot = $snapshotResult
    $result.variances = $varianceResult
    $result.budget_archive = $budgetResult
    $result.message = $notes
  } catch {
    $message = $_.Exception.Message
    Set-RawDocumentState -Connection $Connection -Document $Document -Status "failed" -Notes $message -ContentHash $contentHash -ProcessedOn ([datetime]::UtcNow)
    $null = Upsert-IngestionBatch -Connection $Connection -Document $Document -Status "failed" -Notes $message -CompletedOn ([datetime]::UtcNow)
    $result.message = $message
    throw
  } finally {
    if ($tempPdf -and (Test-Path -LiteralPath $tempPdf)) {
      Remove-Item -LiteralPath $tempPdf -Force
    }
  }

  return $result
}

$target = Connect-Org -Url $TargetEnvironmentUrl
Write-Host "Connected target: $($target.ConnectedOrgFriendlyName)"

Ensure-ProcessorSchema -Connection $target
$queued = Get-QueuedRawDocuments -Connection $target -MaxRows $TopCount

$processed = New-Object System.Collections.Generic.List[object]
$failed = New-Object System.Collections.Generic.List[object]

foreach ($document in $queued) {
  try {
    $processed.Add((Process-QueuedDocument -Connection $target -Document $document -RepoRootPath $RepoRoot)) | Out-Null
  } catch {
    $failed.Add([pscustomobject]@{
        source_id = [string]$document.qfu_sourceid
        branch_code = [string]$document.qfu_branchcode
        file_name = [string]$document.qfu_sourcefile
        message = $_.Exception.Message
      }) | Out-Null
  }
}

$result = [ordered]@{
  target_environment = $TargetEnvironmentUrl
  queued_count = @($queued).Count
  processed = @($processed.ToArray())
  failed = @($failed.ToArray())
}

Write-Utf8Json -Path (Join-Path $RepoRoot $OutputJson) -Object $result
Write-Output ($result | ConvertTo-Json -Depth 10)
