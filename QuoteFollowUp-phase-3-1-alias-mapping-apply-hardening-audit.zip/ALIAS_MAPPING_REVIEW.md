# Alias Mapping Review

No mappings were guessed.

| Item | Count |
| --- | ---: |
| Unresolved alias rows requiring human mapping | 26 |
| Unresolved AM Number rows | 10 |
| Unresolved CSSR Number rows | 16 |
| Invalid alias rows requiring source/manager review | 9 |
| Guessed mappings | 0 |

Generated templates:

- ALIAS_MAPPING_TEMPLATES/unresolved-staff-alias-review.csv
- ALIAS_MAPPING_TEMPLATES/invalid-alias-exceptions-review.csv
- ALIAS_MAPPING_TEMPLATES/qfu_staff-import-template.csv
- ALIAS_MAPPING_TEMPLATES/qfu_staffalias-import-template.csv
- ALIAS_MAPPING_TEMPLATES/qfu_branchmembership-import-template.csv

Invalid aliases are excluded from staff mapping suggestions. Names are included only as display/fallback review context and are not trusted for automatic routing.
