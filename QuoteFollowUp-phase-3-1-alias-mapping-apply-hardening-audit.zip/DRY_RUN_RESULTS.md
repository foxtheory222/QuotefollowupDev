# Dry-Run Results

Dry-run completed: yes

Apply mode was not run.

Alerts sent: 0

Apply-mode hardening changed write safety only. It did not change dry-run selection counts.

## Counts

| Metric | Count |
| --- | ---: |
| quoteSourceRecordsScanned | 521 |
| quoteLineRecordsScanned | 1559 |
| quoteGroupsFound | 521 |
| quoteGroupsAtOrAboveThreshold | 109 |
| workItemsWouldBeCreated | 109 |
| workItemsWouldBeUpdated | 0 |
| workItemsCreated | 0 |
| workItemsUpdated | 0 |
| lowValueQuoteGroupsSkipped | 412 |
| tsrAliasesResolved | 0 |
| cssrAliasesResolved | 0 |
| tsrExceptions | 109 |
| cssrExceptions | 109 |
| missingBranchExceptions | 0 |
| missingPolicyExceptions | 0 |
| ambiguousAliasExceptions | 0 |
| assignmentExceptionsWouldBeCreated | 218 |
| assignmentExceptionsWouldBeUpdated | 0 |
| assignmentExceptionsCreated | 0 |
| assignmentExceptionsUpdated | 0 |
| alertsSent | 0 |

## Sanitized Sample Work Items

~~~json
[
    {
        "sampleId":  "c8cda2c22098",
        "sourceExternalKeyHash":  "c8cda2c22098",
        "sourceDocumentHash":  "b767302230d6",
        "branchCode":  "4171",
        "workType":  "Quote",
        "sourceSystem":  "SP830CA",
        "totalValue":  5189.05,
        "requiredAttempts":  3,
        "completedAttemptsActionRollup":  null,
        "nextFollowUpOn":  "2026-04-03",
        "assignmentStatus":  "Unmapped",
        "tsrResolution":  "unmapped",
        "cssrResolution":  "unmapped",
        "existingWorkItem":  false,
        "preservation":  "Does not overwrite sticky note, sticky note timestamps, action history, last followed-up/action dates, or non-empty manual owners."
    },
    {
        "sampleId":  "0dd6567c4d9f",
        "sourceExternalKeyHash":  "0dd6567c4d9f",
        "sourceDocumentHash":  "e9058bbc532f",
        "branchCode":  "4171",
        "workType":  "Quote",
        "sourceSystem":  "SP830CA",
        "totalValue":  3070.57,
        "requiredAttempts":  3,
        "completedAttemptsActionRollup":  null,
        "nextFollowUpOn":  "2026-04-03",
        "assignmentStatus":  "Unmapped",
        "tsrResolution":  "unmapped",
        "cssrResolution":  "unmapped",
        "existingWorkItem":  false,
        "preservation":  "Does not overwrite sticky note, sticky note timestamps, action history, last followed-up/action dates, or non-empty manual owners."
    },
    {
        "sampleId":  "33e17d55c46f",
        "sourceExternalKeyHash":  "33e17d55c46f",
        "sourceDocumentHash":  "edadd345e835",
        "branchCode":  "4171",
        "workType":  "Quote",
        "sourceSystem":  "SP830CA",
        "totalValue":  4178.86,
        "requiredAttempts":  3,
        "completedAttemptsActionRollup":  null,
        "nextFollowUpOn":  "2026-04-03",
        "assignmentStatus":  "Unmapped",
        "tsrResolution":  "unmapped",
        "cssrResolution":  "unmapped",
        "existingWorkItem":  false,
        "preservation":  "Does not overwrite sticky note, sticky note timestamps, action history, last followed-up/action dates, or non-empty manual owners."
    },
    {
        "sampleId":  "700ab127c1e9",
        "sourceExternalKeyHash":  "700ab127c1e9",
        "sourceDocumentHash":  "6d008de868d1",
        "branchCode":  "4171",
        "workType":  "Quote",
        "sourceSystem":  "SP830CA",
        "totalValue":  9568.57,
        "requiredAttempts":  3,
        "completedAttemptsActionRollup":  null,
        "nextFollowUpOn":  "2026-04-03",
        "assignmentStatus":  "Unmapped",
        "tsrResolution":  "unmapped",
        "cssrResolution":  "unmapped",
        "existingWorkItem":  false,
        "preservation":  "Does not overwrite sticky note, sticky note timestamps, action history, last followed-up/action dates, or non-empty manual owners."
    },
    {
        "sampleId":  "1c1138ac5bfd",
        "sourceExternalKeyHash":  "1c1138ac5bfd",
        "sourceDocumentHash":  "8129df9c3d07",
        "branchCode":  "4171",
        "workType":  "Quote",
        "sourceSystem":  "SP830CA",
        "totalValue":  9968.58,
        "requiredAttempts":  3,
        "completedAttemptsActionRollup":  null,
        "nextFollowUpOn":  "2026-04-14",
        "assignmentStatus":  "Unmapped",
        "tsrResolution":  "unmapped",
        "cssrResolution":  "unmapped",
        "existingWorkItem":  false,
        "preservation":  "Does not overwrite sticky note, sticky note timestamps, action history, last followed-up/action dates, or non-empty manual owners."
    }
]
~~~

## Sanitized Sample Assignment Exceptions

~~~json
[
    {
        "sampleId":  "fcd165b2b9ba",
        "sourceDocumentHash":  "b767302230d6",
        "exceptionType":  "Missing TSR Alias",
        "sourceField":  "qfu_tsr",
        "normalizedValue":  "7003309",
        "existingException":  false
    },
    {
        "sampleId":  "55e30cc62dc4",
        "sourceDocumentHash":  "b767302230d6",
        "exceptionType":  "Missing CSSR Alias",
        "sourceField":  "qfu_cssr",
        "normalizedValue":  "7002464",
        "existingException":  false
    },
    {
        "sampleId":  "85f455efc457",
        "sourceDocumentHash":  "e9058bbc532f",
        "exceptionType":  "Missing TSR Alias",
        "sourceField":  "qfu_tsr",
        "normalizedValue":  "7003309",
        "existingException":  false
    },
    {
        "sampleId":  "6fc787247f41",
        "sourceDocumentHash":  "e9058bbc532f",
        "exceptionType":  "Missing CSSR Alias",
        "sourceField":  "qfu_cssr",
        "normalizedValue":  "7003771",
        "existingException":  false
    },
    {
        "sampleId":  "1ff123fbec29",
        "sourceDocumentHash":  "edadd345e835",
        "exceptionType":  "Missing TSR Alias",
        "sourceField":  "qfu_tsr",
        "normalizedValue":  "7001634",
        "existingException":  false
    }
]
~~~

No customer names are included in the sample payloads. Source document values are represented as hashes.
