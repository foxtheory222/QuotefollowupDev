# Header Line Completeness Review

| Item | Count |
| --- | ---: |
| Quote header groups | 521 |
| Quote line groups | 566 |
| Line groups without header | 45 |
| Header groups without lines | 0 |

Recommendation: Do not guess. Later resolver design should explicitly decide whether to process the union of header and line groups.
