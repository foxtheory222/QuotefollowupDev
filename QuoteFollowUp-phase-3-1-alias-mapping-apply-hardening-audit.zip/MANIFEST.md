# Manifest

| File | Why It Matters |
| --- | --- |
| ADMIN_EXCEPTION_WORKFLOW_REVIEW.md | Admin workflow for templates and exceptions. |
| ALIAS_MAPPING_REVIEW.md | Alias review summary. |
| ALIAS_MAPPING_TEMPLATES/invalid-alias-exceptions-review.csv | Generated alias/staff/membership review template. |
| ALIAS_MAPPING_TEMPLATES/qfu_branchmembership-import-template.csv | Generated alias/staff/membership review template. |
| ALIAS_MAPPING_TEMPLATES/qfu_staffalias-import-template.csv | Generated alias/staff/membership review template. |
| ALIAS_MAPPING_TEMPLATES/qfu_staff-import-template.csv | Generated alias/staff/membership review template. |
| ALIAS_MAPPING_TEMPLATES/unresolved-staff-alias-review.csv | Generated alias/staff/membership review template. |
| APPLY_MODE_HARDENING_REVIEW.md | Resolver apply-mode safety evidence. |
| APPLY_MODE_RESULTS.md | Confirms apply mode was not run. |
| CURRENT_REPO_STATE.md | Repo and workspace state at audit time. |
| DRY_RUN_RESULTS.md | Updated dry-run counts and sanitized samples. |
| HEADER_LINE_COMPLETENESS_REVIEW.md | Quote header/line completeness audit. |
| LIVE_STATE_RECHECK.md | Live Dataverse state and key recheck. |
| OPEN_DECISIONS.md | Remaining human decisions. |
| PHASE_STATUS.md | Phase 3.1 status and next steps. |
| SAFE_SOURCE_FILES/docs/revenue-follow-up-admin-exception-workflow.md | Changed documentation included for source review. |
| SAFE_SOURCE_FILES/docs/revenue-follow-up-phase-3-1-alias-mapping-and-apply-hardening.md | Changed documentation included for source review. |
| SAFE_SOURCE_FILES/docs/revenue-follow-up-resolver-apply-safety.md | Changed documentation included for source review. |
| SAFE_SOURCE_FILES/results/phase3-1-alias-mapping/header-line-completeness.json | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-alias-mapping/invalid-alias-exceptions-review.csv | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-alias-mapping/phase3-1-alias-mapping-summary.json | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-alias-mapping/qfu_branchmembership-import-template.csv | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-alias-mapping/qfu_staffalias-import-template.csv | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-alias-mapping/qfu_staff-import-template.csv | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-alias-mapping/unresolved-staff-alias-review.csv | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-resolver-dryrun-20260427.json | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/results/phase3-1-resolver-dryrun-20260427.md | Safe generated result/template artifact. |
| SAFE_SOURCE_FILES/scripts/Create-RevenueFollowUpPhase3_1Audit.ps1 | Changed script included for source review. |
| SAFE_SOURCE_FILES/scripts/Invoke-RevenueFollowUpPhase3Resolver.ps1 | Changed script included for source review. |
| SAFE_SOURCE_FILES/scripts/New-RevenueFollowUpPhase3_1AliasMappingPrep.ps1 | Changed script included for source review. |
