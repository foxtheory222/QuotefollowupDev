# Admin Exception Workflow Review

Admins should use the generated templates and the Admin Panel MVP together.

1. Review unresolved-staff-alias-review.csv.
2. Confirm staff identity outside the resolver.
3. Create or import staff records only for confirmed staff.
4. Create or import staff alias rows only after confirming the staff record.
5. Create branch memberships only after confirming branch and role.
6. Do not create mappings for invalid aliases from invalid-alias-exceptions-review.csv.
7. Rerun dry-run after mappings are entered.
8. Confirm TSR/CSSR resolved counts improve before any apply mode.

Missing TSR Alias uses AM Number and maps to a TSR staff identity. Missing CSSR Alias uses CSSR Number and maps to a CSSR staff identity. There is no SSR role.

No alerts or daily digests are sent in Phase 3.1.
