# Open Decisions

- Confirm actual staff for each unresolved AM Number.
- Confirm actual staff for each unresolved CSSR Number.
- Decide whether branch-scoped aliases should remain branch-scoped or whether any should intentionally become global.
- Decide how to handle the 45 quote line groups without matching quote headers in a later resolver design.
- Choose first controlled dev apply scope.
- Choose later action rollup implementation pattern.
- Confirm future alert/digest modes before the alert phase.
