# Apply Mode Hardening Review

Apply mode was not run.

| Hardening Item | Status |
| --- | --- |
| Assignment exceptions include source document number | implemented |
| Assignment exceptions include source external key | already implemented |
| Assignment exceptions link source quote when available | implemented |
| Assignment exceptions link representative source quote line when available | implemented |
| Assignment exceptions link newly created work item where possible | implemented |
| Existing work item status preserved | implemented |
| Existing owners preserved | implemented |
| Sticky notes preserved | implemented |
| Action history preserved | implemented |
| Existing next follow-up preserved | implemented |
| Existing last followed up / last action preserved | implemented |
| Existing completed attempts preserved | implemented |

If Dataverse ever creates a work item but does not return qfu_workitemid in apply mode, the resolver throws and stops rather than writing unlinked assignment exceptions.
