# Live State Recheck

Environment: https://orga632edd5.crm3.dynamics.com

| Check | Result |
| --- | --- |
| Solution found | yes |
| App found | yes |
| Required tables found | yes |
| Alternate/replacement keys active | yes |
| Active staff records | 0 |
| Active staff alias records | 0 |
| Active AM Number aliases | 0 |
| Active CSSR Number aliases | 0 |
| Active branch memberships | 0 |
| Duplicate alias mapping groups | 0 |
| Multi-staff same-scope alias groups | 0 |
| Active staff missing primary email | 0 |
| Active staff missing Dataverse systemuser | 0 |

## Key Status

| Table | Key | Found | Index Status | Attributes |
| --- | --- | --- | --- | --- |
| qfu_staffalias | qfu_key_staffalias_source_type_alias_scope | yes | Active | qfu_aliastype, qfu_normalizedalias, qfu_scopekey, qfu_sourcesystem |
| qfu_branchmembership | qfu_key_branchmembership_branch_staff_role | yes | Active | qfu_branch, qfu_role, qfu_staff |
| qfu_policy | qfu_key_policy_scope_worktype_activekey | yes | Active | qfu_policykey |
| qfu_workitem | qfu_key_workitem_type_sourcekey | yes | Active | qfu_sourceexternalkey, qfu_worktype |
| qfu_alertlog | qfu_key_alertlog_dedupekey | yes | Active | qfu_dedupekey |
| qfu_assignmentexception | qfu_key_assignmentexception_sourcekey_type_field_value | yes | Active | qfu_exceptionkey |
