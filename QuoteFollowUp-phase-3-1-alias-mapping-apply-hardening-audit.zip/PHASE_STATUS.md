# Phase Status

Current phase: Phase 3.1 - alias mapping prep and apply-mode hardening before controlled resolver apply.

Execution mode: dry-run only. Apply mode was not run.

## Functional Now

- Live dev solution, app, required tables, and Phase 3 keys were rechecked.
- Current staff, staff alias, and branch membership counts were audited.
- Alias review and import templates were generated.
- Resolver apply mode was hardened for source links, status preservation, owner preservation, next follow-up preservation, sticky note preservation, and action history preservation.
- Resolver dry-run still returns the same selection counts after hardening.
- No solution export was required because Phase 3.1 changed scripts, docs, templates, and dry-run evidence only; no Dataverse metadata changed.

## Not Functional Yet

- No staff or alias mappings exist yet.
- Apply mode has not created work items or assignment exceptions.
- No broad apply run has been performed.
- No alerts, daily digests, My Work page, Manager Panel, GM Review, or security roles are active.

## Next

- Human review of alias templates.
- Enter or import confirmed staff, alias, and branch membership data.
- Rerun dry-run and confirm resolved owner counts improve.
- Pick one small dev apply scope only after mapping review.

## Still Left

- Controlled apply-mode validation.
- Resolver automation trigger design.
- Work item action rollup automation.
- Alert and digest phase.
- Security roles and access model.

## Blocking Questions

- Which unresolved AM Number aliases map to which staff records.
- Which unresolved CSSR Number aliases map to which staff records.
- Whether the 45 line-only quote groups should be included by a later union-of-header-and-line resolver design.
- Which branch or quote group should be used for first controlled apply.
