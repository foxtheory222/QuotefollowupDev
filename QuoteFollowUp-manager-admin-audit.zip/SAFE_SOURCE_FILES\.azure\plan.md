# Azure Deployment Plan

> **Status:** Ready for Validation

Generated: 2026-04-21T16:30:00-06:00

---

## 1. Project Overview

**Goal:** Replace the missing local freight queue consumer with a hosted freight parser path so Southern Alberta freight emails complete unattended from Power Automate ingress through `qfu_freightworkitem` upsert.

**Path:** Add Components

---

## 2. Requirements

| Attribute | Value |
|-----------|-------|
| Classification | Production |
| Scale | Small |
| Budget | Balanced |
| **Subscription** | Existing Applied internal production Azure subscription hosting QFU shared services. Must be confirmed before deployment. |
| **Location** | Same Azure geography used for internal QFU integration services. Must be confirmed before deployment. |

---

## 3. Components Detected

| Component | Type | Technology | Path |
|-----------|------|------------|------|
| Southern Alberta freight ingress flows | Workflow | Power Automate / Dataverse | `scripts/create-southern-alberta-freight-flow-solution.ps1` |
| Freight parser | Worker logic | Python (`openpyxl`, `xlrd`) | `scripts/freight_parser.py` |
| Local freight queue consumer | Worker | PowerShell + Dataverse | `scripts/process-freight-inbox-queue.ps1` |
| Freight schema/source feed seed | Data/ops | PowerShell + Dataverse | `scripts/deploy-freight-worklist.ps1` |

---

## 4. Recipe Selection

**Selected:** AZD (Bicep)

**Rationale:** The hosted component is a small Azure Functions workload that fits the existing internal Azure direction. The current local environment does not have `azd` installed, so this change will prepare the hosted app and plan artifacts now, with final infra generation/deployment still requiring Azure toolchain validation before go-live.

---

## 5. Architecture

**Stack:** Serverless

### Service Mapping

| Component | Azure Service | SKU |
|-----------|---------------|-----|
| Freight hosted parser | Azure Functions | Consumption or Flex Consumption, to be confirmed before deployment |

### Supporting Services

| Service | Purpose |
|---------|---------|
| Application Insights | Hosted parser telemetry and failure traces |
| Log Analytics | Centralized operational logging |
| Key Vault | Hosted parser secrets if client-secret auth is used |
| Managed Identity | Preferred Dataverse authentication path for the hosted parser |

### Runtime Contract

1. Existing freight inbox ingress flow remains the first step and keeps mailbox logic thin.
2. The ingress flow still creates `qfu_rawdocument` and `qfu_ingestionbatch` rows immediately.
3. The ingress flow then calls a hosted Azure Function over HTTP with branch metadata plus attachment content.
4. The hosted parser reuses the same Python freight parsing rules that currently process `.xlsx` and legacy `.xls` carrier files.
5. The hosted parser upserts `qfu_freightworkitem` rows in Dataverse and returns inserted/updated counts plus warnings.
6. The ingress flow marks `qfu_rawdocument` and `qfu_ingestionbatch` as `processed` or `error` based on the hosted parser response.

---

## 6. Execution Checklist

### Phase 1: Planning
- [x] Analyze workspace
- [x] Gather requirements
- [ ] Confirm subscription and location with user
- [x] Scan codebase
- [x] Select recipe
- [x] Plan architecture
- [x] **User approved this plan**

### Phase 2: Execution
- [x] Research components (load references, inspect current freight parser/flow generator)
- [x] Prepare hosted Azure Functions app scaffold
- [x] Refactor freight parser into a shared hosted-compatible module
- [x] Update freight flow generator for hosted parser invocation and status handling
- [x] Add local tests for hosted parser and flow contract
- [x] Update ops documentation and durable repo mirror
- [x] Update plan status to "Ready for Validation"

### Phase 3: Validation
- [ ] Invoke azure-validate skill
- [ ] All validation checks pass
- [ ] Update plan status to "Validated"
- [ ] Record validation proof below

### Phase 4: Deployment
- [ ] Invoke azure-deploy skill
- [ ] Deployment successful
- [ ] Update plan status to "Deployed"

---

## 7. Validation Proof

> **Required before status can move to `Validated`.**

| Check | Command Run | Result | Timestamp |
|-------|-------------|--------|-----------|

**Validated by:** Pending
**Validation timestamp:** Pending

---

## 8. Files to Generate

| File | Purpose | Status |
|------|---------|--------|
| `.azure/plan.md` | Azure preparation plan | âœ… |
| `src/freight_parser_host/*` | Hosted freight parser app | â³ |
| `tests/test_freight_hosted_parser_contracts.py` | Hosted parser and flow contract validation | â³ |
| `docs/ops/freight-hosted-parser-20260421.md` | Durable implementation notes | â³ |

---

## 9. Next Steps

> Current: Phase 2 execution

1. Create the hosted Azure Functions scaffold and shared parser module.
2. Wire the freight flow generator to call the hosted parser and stamp Dataverse statuses from the response.
3. Validate locally with parser contract tests, then prepare deployment follow-up for Azure tooling and live rollout.
